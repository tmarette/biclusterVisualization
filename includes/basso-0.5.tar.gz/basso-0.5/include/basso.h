/*
 * basso.h
 * 
 * Declarations of the algorithms used for Boolean matrix factorization 
 * in libbasso.
 */

/*
 * Copyright (c) 2016 Pauli Miettinen
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to
 * deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

#ifndef _BASSO_H
#define _BASSO_H

#include "bassodata.h"

#include <signal.h> // For sig_atomic_t


/* C++ safety */
#ifdef __cplusplus
#  define BEGIN_C_DECL extern "C" {
#  define END_C_DECL   }
#else
#  define BEGIN_C_DECL
#  define END_C_DECL
#endif

BEGIN_C_DECL

/*
 * DATA TYPES
 */

/*
 * struct _basso_opt_s is a private struct that shuld only be accessed with getters and setters below
 */
typedef struct _basso_opt_s basso_option_t;

/*
 * MAIN ALGORITHMS
 */

/*
 * basso_association_matrix returns the candidate matrix Cand. Assumes A to be in row-major and
 * returns Cand in row-major.
 */
BASSO_ATTRIBUTE_MALLOC
basso_matrix_t *restrict
basso_association_matrix(const basso_matrix_t *restrict A,
                         const uint64_t *restrict ones_per_row,
                         const basso_option_t *restrict opt);



/*
 * basso_select_basis selects k basis vectors from the candidates in matrix Cand
 * to best cover the data matrix A. The resulting factorization is stored in 
 * (*B) and (*C).
 *
 * Assumes A and Cand to be in column-major format.
 *
 * Returns non-zero on error and sets *B and *C to NULL.
 *
 * basso_select_basis can be interrupted by setting basso_stop_select_basis to non-zero.
 */
int
basso_select_basis(const basso_matrix_t  *restrict A,
                   const basso_matrix_t  *restrict Cand,
                   const basso_option_t  *restrict opt,
                         basso_matrix_t **restrict B,
                         basso_matrix_t **restrict C);

extern volatile sig_atomic_t basso_stop_select_basis;

/*
 * Computes the Boolean matrix factorization of A. The result is stored in matrices (*B) and (*C).
 *
 * Assumes A to be in row-major format. 
 *
 * Resulting (*B) is in column-major and (*C) is in row-major format.
 */
int
basso(const basso_matrix_t  *restrict A,
      const basso_option_t  *restrict opt,
            basso_matrix_t **restrict B,
            basso_matrix_t **restrict C);
  

/*
 * INTIALIZE, FREE, AND GETTERS AND SETTERS FOR THE OPTION STRUCTURE
 */

/*
 * basso_opt_init returns an option struct with default values.
 *
 * Returns NULL on error and sets the errno.
 */
BASSO_ATTRIBUTE_MALLOC
basso_option_t *
basso_opt_init();

/*
 * basso_opt_free frees option struct allocated with basso_opt_init.
 */
void
basso_opt_free(basso_option_t *opt);



/*
 * basso_opt_set_rank sets the rank of the factorization, which must be non-zero.
 *
 * Returns non-zero on error.
 */
int
basso_opt_set_rank(basso_option_t *opt, const uint64_t rank);

/*
 * basso_opt_set_threshold sets the threshold for rounding the association matrix.
 * The threshold must be between 0 and 1.
 *
 * Returns non-zero on error.
 */
int
basso_opt_set_threshold(basso_option_t *opt, const double threshold);


/*
 * basso_opt_set_thresholds_list sets the thresholds list for rounding the association matrix.
 * The thresholds must be between 0 and 1.
 *
 * Returns non-zero on error.
 */
int
basso_opt_set_thresholds_list(basso_option_t *opt, const double* thresholds, const uint64_t thresholds_len);

/*
 * basso_opt_set_weight sets the bias for covering 1s.
 *
 * Returns non-zero on error.
 */
int
basso_opt_set_weight(basso_option_t *opt, const uint64_t weight);


/*
 * basso_opt_set_update_step set the step to update the factors, which must be non-zero.
 *
 * Returns non-zero on error.
 */
int
basso_opt_set_update_step(basso_option_t *opt, const uint64_t update_step);

/*
 * basso_opt_set_update_candidates_step set the step to update the candidates, which must be non-zero.
 *
 * Returns non-zero on error.
 */
int
basso_opt_set_update_candidates_step(basso_option_t *opt, const uint64_t update_candidates_step);

/*
 * basso_opt_set_ext_candidates sets the flag to extend candidates.
 *
 * Returns non-zero on error.
 */
int
basso_opt_set_ext_candidates(basso_option_t *opt, const int ext_candidates);

/*
 * basso_opt_set_remove_duplicate_candidates sets the flag to remove duplicate candidates from assoication matrix
 *
 * Returns non-zero on error.
 */
int
basso_opt_set_remove_duplicate_candidates(basso_option_t *opt, const int remove_duplicate_candidates);



/*
 * basso_opt_set_use_candidates_overlap_alg sets the flag to use candidates-overlap-algorithm
 *
 * Returns non-zero on error.
 */
int
basso_opt_set_use_candidates_overlap_alg(basso_option_t *opt, const int use_candidates_overlap_alg);


/*
 * basso_opt_set_optimized_computation sets the flag to use optimized algorithm for computing factors
 *
 * Returns non-zero on error.
 */
int
basso_opt_set_optimized_computation(basso_option_t *opt, const int optimized_computation);

/*
 * basso_opt_set_iterative_update sets the flag to do iterative update.
 *
 * Returns non-zero on error.
 */
int
basso_opt_set_iterative_update(basso_option_t *opt, const uint64_t iterative_update);

/*
 * basso_opt_set_print_mid_error sets the flag to print reconstruction error after finding each factor.
 *
 * Returns non-zero on error.
 */
int
basso_opt_set_print_mid_error(basso_option_t *opt, const int print_mid_error);

/*
 * basso_opt_set_zero_cover_weight sets the current zero_cover_weight which penalizes the score of covering 0s.
 *
 * Returns non-zero on error.
 */
int
basso_opt_set_zero_cover_weight(basso_option_t *opt, const uint64_t zero_cover_weight);


/*
 * basso_opt_set_ext_candidates sets the flag to decompose matrix symmetrically.
 *
 * Returns non-zero on error.
 */
int
basso_opt_set_symmetrical_decompose(basso_option_t *opt, const int symmetrical_decompose);

/*
 * basso_opt_set_zcw_modify_step sets the current value of zcw_modify_step used to modify zero_cover_weight.
 *
 * Returns non-zero on error.
 */
int
basso_opt_set_zcw_modify_step(basso_option_t *opt, const double zcw_modify_step);

/*
 * basso_opt_ger_rank gets the current rank of the factorization.
 *
 * Returns 0 on error.
 */
uint64_t
basso_opt_get_rank(const basso_option_t *opt);

/*
 * basso_opt_get_threshold gets the first threshold for rounding the association matrix.
 *
 * Returns -1.0 on error.
 */
double
basso_opt_get_threshold(const basso_option_t *opt);

/*
 * basso_opt_get_threshold_list_len returns the length of thresholds list.
 *
 * Returns 0 on error.
 */
uint64_t
basso_opt_get_threshold_list_len(const basso_option_t *opt);

/*
 * basso_opt_get_threshold_list returns a pointer to the list of thresholds.
 *
 * Returns NULL on error.
 */
double *
basso_opt_get_threshold_list(const basso_option_t *opt);


/*
 * basso_opt_get_weight gets the current bias for covering 1s.
 *
 * Returns ULLONG_MAX on error.
 */
uint64_t
basso_opt_get_weight(const basso_option_t *opt);


/*
 * basso_opt_get_update_step gets the current step size to update factors
 *
 * Returns ULLONG_MAX on error.
 */
uint64_t
basso_opt_get_update_step(const basso_option_t *opt);

/*
 * basso_opt_get_update_candidates_step gets the current step size to update candidates
 *
 * Returns ULLONG_MAX on error.
 */
uint64_t
basso_opt_get_update_candidates_step(const basso_option_t *opt);

/*
 * basso_opt_is_ext_candidate_set returns 1 when extend-candidate flag is set and 0 otherwise.
 *
 * Returns -1 on error.
 */
int
basso_opt_is_ext_candidate_set(const basso_option_t *opt);


/*
 * basso_opt_is_optimized_computation_set returns 1 when optimized computation flag is set and 0 otherwise.
 *
 * Returns -1 on error.
 */
int
basso_opt_is_optimized_computation_set(const basso_option_t *opt);

/*
 * basso_opt_is_remove_duplicate_candidates_set returns 1 when removing duplicate candidates flag is set and 0 otherwise.
 *
 * Returns -1 on error.
 */
int
basso_opt_is_remove_duplicate_candidates_set(const basso_option_t *opt);


/*
 * basso_opt_is_use_candidates_overlap_alg_set returns 1 when use_candidates_overlap_alg flag is set and 0 otherwise.
 *
 * Returns -1 on error.
 */
int
basso_opt_is_use_candidates_overlap_alg_set(const basso_option_t *opt);

/*
 * basso_opt_get_zero_cover_weight gets the current zero_cover_weight which penalizes the score of covering 0s.
 *
 * Returns ULLONG_MAX on error.
 */
uint64_t
basso_opt_get_zero_cover_weight(const basso_option_t *opt);

/*
 * basso_opt_get_zcw_modify_step gets the current value of zcw_modify_step used to modify zero_cover_weight
 *
 * Returns -1 on error.
 */
double
basso_opt_get_zcw_modify_step(const basso_option_t *opt);

/*
 * basso_opt_get_iterative_update gets the number of update iteration on factor matrices at the end of factorization
 *
 * Returns ULLONG_MAX on error.
 */
uint64_t
basso_opt_get_iterative_update(const basso_option_t *opt);

/*
 * basso_opt_is_print_mid_error_set returns 1 when print_mid_error flag is set and 0 otherwise.
 *
 * Returns -1 on error.
 */
int
basso_opt_is_print_mid_error_set(const basso_option_t *opt);


/*
 * basso_opt_is_symmetrical_decompose_set returns 1 when symmetrical_decompose flag is set and 0 otherwise.
 *
 * Returns -1 on error.
 */
int
basso_opt_is_symmetrical_decompose_set(const basso_option_t *opt);

END_C_DECL

#endif /*_BASSO_H */

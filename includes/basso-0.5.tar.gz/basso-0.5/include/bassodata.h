/* 
 * bassodata.h
 *
 * Declarations of the functions to manipulate the bitwise matrices in
 * libbasso. These file should be included by essentially all files in 
 * the libbasso project. Functions declared here should be useful also
 * without the algorithms in basso.h.
 */

/*
 * Copyright (c) 2016 Pauli Miettinen
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to
 * deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

#ifndef _BASSODATA_H
#define _BASSODATA_H

#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#if (defined(HAVE_CONFIG_H) && defined(HAVE_INTTYPES_H)) || !defined(HAVE_CONFIG_H)
#  include <inttypes.h> /* for uint64_t */
#endif

#if defined HAVE_NMMINTRIN_H
#  include <nmmintrin.h>
#elif defined HAVE_X86INTRIN_H
#  include <x86intrin.h>
#elif defined HAVE_INTRIN_H
#  include <intrin.h>
#endif

#include <limits.h>   /* for CHAR_BIT */
#include <stddef.h>   /* for size_t */

//#include "bassopriv.h"

/* Check for non-existing ULLONG_MAX */
#ifndef ULLONG_MAX
#  define ULLONG_MAX (uint64_t)-1;
#endif


/* C++ safety */
#ifdef __cplusplus
#  define BEGIN_C_DECL extern "C" {
#  define END_C_DECL   }
#else
#  define BEGIN_C_DECL
#  define END_C_DECL
#endif

/* Some function attributes if using gcc or clang */
/* clang */
#if defined(__clang__) && defined(__has_attribute)
#  if __has_attribute(__malloc__) && !defined(BASSO_ATTRIBUTE_MALLOC)
#    define BASSO_ATTRIBUTE_MALLOC __attribute__((__malloc__))
#  endif
#  if __has_attribute(__pure__) && !defined(BASSO_ATTRIBUTE_PURE)
#    define BASSO_ATTRIBUTE_PURE __attribute__((__pure__))
#  endif
/* GCC */
#elif defined(__GNUC__)
#  if __GNUC__ >= 3
/* There attributes are only available in GCC v3.0 or higher */
#    ifndef BASSO_ATTRIBUTE_MALLOC
#      define BASSO_ATTRIBUTE_MALLOC __attribute__((__malloc__))
#    endif
#    ifndef BASSO_ATTRIBUTE_PURE
#      define BASSO_ATTRIBUTE_PURE __attribute__((__pure__))
#    endif
#  endif /* GCC >= v3.0.0 */
/* Microsoft Visual C */
#elif defined (_MSC_VER) && (_MSC_VER >= 1300)
#  if !defined(BASSO_ATTRIBUTE_MALLOC) && (_MSC_VER >= 1400)
#    define BASSO_ATTRIBUTE_MALLOC __declspec(restrict)
#  endif
#endif /* Compilers */

#ifndef BASSO_ATTRIBUTE_MALLOC
#  define BASSO_ATTRIBUTE_MALLOC
#endif
#ifndef BASSO_ATTRIBUTE_PURE
#  define BASSO_ATTRIBUTE_PURE
#endif


BEGIN_C_DECL /* For C++ compilers */

/*
 * DATA TYPES
 */

/*
 * The basso_elem_t the basic element used to store the bits.
 * It is uint64_t unless the user defines BASSO_USER_DATATYPE
 * to some other type (e.g. uint32_t).
 */
#ifndef BASSO_USER_DATATYPE
typedef uint64_t basso_elem_t;
#else
typedef BASSO_USER_DATATYPE basso_elem_t;
#endif

/* FIXME: test if it would be faster to
 *#define BASSO_ELEM_BITS (sizeof(basso_elem_t)*CHAR_BIT)
 */
static const size_t basso_elem_bits = sizeof(basso_elem_t)*CHAR_BIT;

/*
 * The basso_majority_t is an enum that stores if the matrix is 
 * in row or column major format.
 */
typedef enum basso_majority_enum {
  BASSO_COL_MAJ = 0,
  BASSO_ROW_MAJ = 1
} basso_majority_t;

/*
 * The basso_matrix_t is a struct that stores the actual matrix
 * and some other information. majority stores the majority, 
 * and elem_per_vect stores how many basso_elem_t elements are in 
 * the vectors along the major direction. I.e. a column-major matrix
 * with 100 columns and 20 elem_per_vect would have 20*100 elements
 * in array data, and its (i,j) element would be
 * data[j*elem_per_vect + i/basso_elem_bits] & (BASSO_ONE << (i%basso_elem_bits))
 */
typedef struct {
  basso_majority_t       majority;
  uint64_t               rows;
  uint64_t               cols;
  uint64_t               elem_per_vect;
  basso_elem_t *restrict data;
} basso_matrix_t;


/*
 * MACROS
 */

/*
 * BASSO_ONE_AT_IND gives an basso_elem_t with the i % basso_elem_bits bit set to 1 and others to 0
 */
#define BASSO_ONE_AT_IND(i) (((basso_elem_t)1) << (i) % basso_elem_bits)

/*
 * BASSO_VAL_AT gives the value of basso_elem_t x at bit k.
 */
#define BASSO_VAL_AT(x, k) ( ( (x) & BASSO_ONE_AT_IND(k) ) >> ( (k) % basso_elem_bits ) )

/* 
 * BASSO_POPCNT is a macro that extends to the appropriate function that counts the popcount
 * Uses build-in rather than the replacement if available
 * Turn this off by --disable-builtin_popcountll in configure
 */
#ifndef BASSO_POPCNT /* Test for user-defined BASSO_POPCNT */
#  if defined HAVE_NMMINTRIN_H
#    define BASSO_POPCNT(x) _mm_popcnt_u64(x)
#  elif defined HAVE_X86INTRIN_H
#    define BASSO_POPCNT(x) _mm_popcnt_u64(x)
#  elif defined HAVE_INTRIN_H
#    define BASSO_POPCNT(x) _mm_popcnt_u64(x)
#  elif defined HAVE___BUILTIN_POPCOUNTLL
#    define BASSO_POPCNT(x) __builtin_popcountll(x)
#  else
#    define BASSO_POPCNT(x) basso_popcnt64_r(x)
#  endif /* No support for ARM or PowerPC */
#endif

/*
 * POPCOUNT
 */

/*
 * basso_popcnt64_t implements a popcout function for uint64_t. It returns the number of bits set on the input.
 * The implementation does not use any multiplications.
 */
int
basso_popcnt64_r(uint64_t x);


/*
 * MEMORY MANAGEMENT
 */

/*
 * basso_m_alloc allocates memory to rows-by-cols bitwise matrix that is row or column major depending
 * on the value of majority. The allocated memory is initialized to all-zeroes and elem_per_vect is set
 * to correct value.
 *
 * Returns a pointer to the allocated matrix, or NULL on error. Sets errno in case of error.
 */
BASSO_ATTRIBUTE_MALLOC
basso_matrix_t *
basso_m_alloc(const size_t rows, const size_t cols, const basso_majority_t majority);

/*
 * basso_m_free free the memory taken by A.
 */
void
basso_m_free(basso_matrix_t *A);


/*
 * BASIC MATRIX OPERATIONS
 */


/*
 * basso_m_copy copies the matrix src to the dest
 *
 * Returns 1 on error and sets the errno.
 */
int
basso_m_copy(basso_matrix_t *dest, const basso_matrix_t *src);


/*
 * basso_m_transpose transpose the matrix src and copy it to the dest
 *
 * Returns 1 on error and sets the errno.
 */
int
basso_m_transpose(basso_matrix_t *dest, const basso_matrix_t *src);


/*
 * basso_m_hor_concat concatenates matrix B to the end of A horizontally and return a new matrix on new_mat
 *
 * Returns 1 on error and sets the errno.
 */
int
basso_m_hor_concat(const basso_matrix_t *restrict A,const basso_matrix_t *restrict B,basso_matrix_t *new_mat);


/*
 * basso_m_duplicate copies the matrix A
 *
 * Returns NULL on error and sets the errno.
 */
BASSO_ATTRIBUTE_MALLOC
basso_matrix_t *
basso_m_duplicate(const basso_matrix_t *A);

/*
 * basso_m_swap_duplicate returns a new matrix that is same as A but with the majority swapped.
 *
 * Returns NULL on error and sets errno.
 */
BASSO_ATTRIBUTE_MALLOC
basso_matrix_t *
basso_m_swap_duplicate(const basso_matrix_t *A);

/*
 * basso_m_nnz returns the number of non-zeroes in the matrix.
 *
 * Returns ULLONG_MAX on error and sets errno to EINVAL if A is not a valid matrix.
 */
BASSO_ATTRIBUTE_PURE
uint64_t
basso_m_nnz(const basso_matrix_t *A);

/*
 * basso_m_row_sums stores the row sums of A to vector sums, which must be
 * of length A->rows.
 *
 * Returns non-zero on error and sets the errno.
 */
int
basso_m_row_sums(const basso_matrix_t *restrict A,
                 uint64_t *sums);

/*
 * basso_m_col_sums stores the column sums of A to vector sums, which must be
 * of length A->colss.
 *
 * Returns non-zero on error and sets the errno.
 */
int
basso_m_col_sums(const basso_matrix_t *restrict A,
                 uint64_t *sums);


/*
 * basso_m_XOR returns C = XOR(A,B)
 *
 * Returns NULL on error and sets the errno.
 */
basso_matrix_t *
basso_m_XOR(const basso_matrix_t *restrict A,
			const basso_matrix_t *restrict B);
/* 
 * basso_m_bprod computes Boolean product of A and B and stores it to C. 
 * Best used with row-major A and column-major B.
 *
 * A, B, and C must be distinct, and their dimensions must agree.
 *
 * Returns non-zero on error and sets errno:
 *   - EINVAL  the inner dimensions of the matrices do not agree or any of the 
 *     input is NULL
 *   - other   problems when allocating the memory
 */
int
basso_m_bprod(const basso_matrix_t *restrict A,
              const basso_matrix_t *restrict B,
                    basso_matrix_t *restrict C);

/* 
 * basso_m_diff computes the sum-of-absolute-differences between matrices A and B.
 * Best used with A and B having the same majority.
 *
 * A and B must be distinct, and their dimensions must agree.
 *
 * Returns ULLONG_MAX on error and sets ERRNO:
 *   - EINVAL  matrices are not of the same size or A or B is NULL
 */
BASSO_ATTRIBUTE_PURE
uint64_t
basso_m_diff(const basso_matrix_t *restrict A,
             const basso_matrix_t *restrict B);


/*
 * basso_m_diff_ignore_diagonal computes the sum-of-absolute-differences between matrices A and B without considering the diagonal values.
 * Best used with A and B having the same majority.
 *
 * A and B must be distinct, and their dimensions must agree.
 *
 * Returns ULLONG_MAX on error and sets ERRNO:
 *   - EINVAL  matrices are not of the same size or A or B is NULL
 */
uint64_t
basso_m_diff_ignore_diagonal(const basso_matrix_t *restrict A,
             	 	 	 	 const basso_matrix_t *restrict origB);

/* 
 * basso_m_bnorm returns the Boolean norm |A - (B o C)|.
 * Same as basso_m_bprod(B, C, D); basso_m_diff(A, D).
 *
 * All matrices A, B, C must be distinct. Behavior is undefined if they overlap.
 *
 * Returns ULLONG_MAX on error and sets ERRNO:
 *    - EINVAL  matrix dimensions do not match
 *    - other   problems with allocating the memory
 */
BASSO_ATTRIBUTE_PURE
uint64_t
basso_m_bnorm(const basso_matrix_t *restrict A,
              const basso_matrix_t *restrict B,
              const basso_matrix_t *restrict C);



/*
 * SPECIAL MATRICES
 */

/*
 * basso_m_zeros returns an empty matrix. 
 *
 * Returns NULL on error and sets the errno.
 */
#define basso_m_zeros(rows, cols, maj) basso_m_alloc(rows, cols, maj)

/*
 * basso_m_eye returns the identity matrix.
 *
 * Returns NULL on error and sets the errno.
 */
BASSO_ATTRIBUTE_MALLOC
basso_matrix_t *
basso_m_eye(const uint64_t dim, const basso_majority_t maj);


/*
 * GETTERS AND SETTERS FOR INDIVIDUAL ELEMENTS
 */

/*
 * basso_m_get_val returns the value of A(row, col)
 */
static inline int
basso_m_get_val(const basso_matrix_t *restrict A,
                const uint64_t row,
                const uint64_t col)
{
  const uint64_t epv = A->elem_per_vect;
  uint64_t val;
  int rval;
# ifdef BASSO_ENABLE_BOUNDARY_TESTS
  if (row > A->rows || col > A->cols) {
    fprintf(stderr, "basso_m_get_val: ERROR: Index (%llu, %llu) out of bounds\n",
            row, col);
    return -1;
  }
# endif
  if (A->majority == BASSO_ROW_MAJ) {
    val = A->data[row*epv + col/basso_elem_bits] & BASSO_ONE_AT_IND(col);
    rval = (int)(val >> col % basso_elem_bits);
  } else {
    val = A->data[col*epv + row/basso_elem_bits] & BASSO_ONE_AT_IND(row);
    rval = (int)(val >> row % basso_elem_bits);
  }
  return rval;
}

/*
 * basso_m_set_val sets A(row, col) = value
 *
 * Returns value on success and -1 on error.
 */
static inline int
basso_m_set_val(basso_matrix_t *restrict A,
                const uint64_t row,
                const uint64_t col,
                const int value)
{
  const uint64_t epv = A->elem_per_vect;
# ifdef BASSO_ENABLE_BOUNDARY_TESTS
  if (row > A->rows || col > A->cols) {
    fprintf(stderr, "basso_m_set_val: ERROR: Index (%llu, %llu) out of bounds\n",
            row, col);
    return -1;
  }
# endif
  if (A->majority == BASSO_ROW_MAJ) {
    if (value) {
      A->data[row*epv + col/basso_elem_bits] |=  BASSO_ONE_AT_IND(col);
    } else {
      A->data[row*epv + col/basso_elem_bits] &= ~BASSO_ONE_AT_IND(col);
    }
  } else {
    if (value) {
      A->data[col*epv + row/basso_elem_bits] |=  BASSO_ONE_AT_IND(row);
    } else {
      A->data[col*epv + row/basso_elem_bits] &= ~BASSO_ONE_AT_IND(row);
    }
  }
  return value;
}

/*
 * basso_m_set_all_zeros sets all values of A to zero.
 *
 * Returns non-zero on error and sets errno to EINVAL if A is NULL.
 */
int
basso_m_set_all_zeros(basso_matrix_t *A);

/*
 * basso_m_set_all_ones sets all values of A to 1.
 *
 * Returns non-zero on error and sets errno to EINVAL if A is NULL
 */
int
basso_m_set_all_ones(basso_matrix_t *A);

/*
 * basso_m_set_nth_row_zero sets all values of n_th row of A to 0.
 *
 * Returns non-zero on error and sets errno to EINVAL if A is NULL
 */
int
basso_m_set_nth_row_zero(basso_matrix_t *restrict A,const uint64_t i);

/*
 * basso_m_set_nth_col_zero sets all values of j_th column of A to 0.
 *
 * Returns non-zero on error and sets errno to EINVAL if A is NULL
 */
int
basso_m_set_nth_col_zero(basso_matrix_t *restrict A,const uint64_t j);



/*
 * basso_m_remove_duplicate_column removes duplicate columns of A.
 *
 * Returns NULL on error.
 */
basso_matrix_t *
basso_m_remove_duplicate_column(const basso_matrix_t *restrict A);


END_C_DECL /* For C++ compilers */

#endif /* _BASSODATA_H */


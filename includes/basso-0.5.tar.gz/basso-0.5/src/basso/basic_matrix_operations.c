/*
 * basic_matrix_operations.c
 *
 * This file contains the implementations of the basic functions used to 
 * operate with the bitwise matrices of libbasso. These functions are
 * declared in bassodata.h.
 */

/*
 * Copyright (c) 2016 Pauli Miettinen
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to
 * deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

#ifdef HAVE_CONFIG_H
# include "config.h"
#endif

#include <string.h>
#include <errno.h>
#include <limits.h>

#include <stdio.h>


#include "bassodata.h"
#include "bassopriv.h"

extern size_t
elem_per_vect(size_t n);

/*
 * basso_popcnt64_r is the replacement 64-bit popcount function used if the CPU or compiler doesn't support any.
 * This implementation is fast with slow multiplication. We assume systems with fast multiplication also have build-in
 * SOURCE: https://en.wikipedia.org/wiki/Hamming_weight
 */
int
basso_popcnt64_r(uint64_t x)
{
  const uint64_t m1  = 0x5555555555555555; //binary: 0101...
  const uint64_t m2  = 0x3333333333333333; //binary: 00110011...
  const uint64_t m4  = 0x0f0f0f0f0f0f0f0f; //binary: 0000111100001111...
  x -= (x >> 1) & m1;             //put count of each 2 bits into those 2 bits
  x = (x & m2) + ((x >> 2) & m2); //put count of each 4 bits into those 4 bits
  x = (x + (x >> 4)) & m4;        //put count of each 8 bits into those 8 bits
  x += x >>  8;  //put count of each 16 bits into their lowest 8 bits
  x += x >> 16;  //put count of each 32 bits into their lowest 8 bits
  x += x >> 32;  //put count of each 64 bits into their lowest 8 bits
  return x & 0x7f;
}

int
basso_m_swap(basso_matrix_t *A)
{
  if (A == NULL) {
    errno = EINVAL;
    return 1;
  }
  // FIXME: not implemented yet!
  fprintf(stderr, "%s (%s:%d): NOT IMPLEMENTED\n", __func__, __FILE__, __LINE__);
  return 1;
}

int
basso_m_copy(basso_matrix_t *dest, const basso_matrix_t *src)
{
	if (dest == NULL) {
		BASSO_ERRMSG("Destination matrix cannot be NULL");
		errno = EINVAL;
		return 1;
	}

	if (src == NULL) {
		BASSO_ERRMSG("Source matrix cannot be NULL");
		errno = EINVAL;
		return 1;
	}

	if(src->rows != dest->rows || src->cols != dest->cols)
	{
		BASSO_ERRMSG("The dimensions of source and destination matrices are not matched");
		return 1;
	}

	if(src->majority == dest->majority)
	{
		const uint64_t maj_dim = (src->majority == BASSO_ROW_MAJ) ? src->rows : src->cols;
		memcpy(dest->data, src->data, maj_dim * src->elem_per_vect * sizeof(basso_elem_t));
	}
	else
	{
		const uint64_t rows = src->rows;
		const uint64_t cols = src->cols;
		const uint64_t epv  = src->elem_per_vect;
		const basso_majority_t s_maj = src->majority;
		const basso_majority_t t_maj = dest->majority;
		/* Copy data; make sure the reading is cache-optimal */
		if (s_maj == BASSO_ROW_MAJ) {
			for (uint64_t i=0; i<rows; i++) {
				/* The last columns need to be dealt separately */
				for (uint64_t j=0; j<epv-1; j++) {
					const basso_elem_t x = src->data[i*epv + j];
					for (size_t k=0; k < basso_elem_bits; k++) {
						int val = BASSO_VAL_AT(x, k);
						uint64_t colid = j*basso_elem_bits + k;
						basso_m_set_val(dest, i, colid, val);
					}
				}
				{
					/* The last columns */
					const basso_elem_t x = src->data[i*epv + epv - 1];
					for (size_t l=0; (epv-1) * basso_elem_bits + l < cols; l++) {
						size_t k = l % basso_elem_bits;
						int val = BASSO_VAL_AT(x, k);
						uint64_t colid = (epv - 1)*basso_elem_bits + k;
						basso_m_set_val(dest, i, colid, val);
					}
				}
			}
		}
		else { /* if s_maj != BASSO_ROW_MAJ */
			for (uint64_t j=0; j < cols; j++) {
				for (uint64_t i=0; i  < epv-1; i++) {
					/* All except the last rows */
					const basso_elem_t x = src->data[j*epv + i];
					for (size_t k=0; k < basso_elem_bits; k++) {
						int val = BASSO_VAL_AT(x, k);
						uint64_t rowid = i*basso_elem_bits + k;
						basso_m_set_val(dest, rowid, j, val);
					}
				}
				{
					/* The last rows */
					const basso_elem_t x = src->data[j*epv + epv - 1];
					for (size_t l=0; (epv-1) * basso_elem_bits + l < rows; l++) {
						size_t k = l % basso_elem_bits;
						int val = BASSO_VAL_AT(x, k);
						uint64_t rowid = (epv - 1)*basso_elem_bits + k;
						basso_m_set_val(dest, rowid, j, val);
					}
				}
			}
		}
	}
	return 0;
}

int
basso_m_transpose(basso_matrix_t *dest, const basso_matrix_t *src)
{
	if(dest == NULL || src == NULL){
		BASSO_ERRMSG("Source or destination matrix is null");
		errno = EINVAL;
		return 1;
	}

	if(src->cols != dest->rows || src->rows != dest->cols)
	{
		BASSO_ERRMSG("The dimensions of matrices are not compatible");
		errno = EINVAL;
		return 1;
	}

	if(src->majority != dest->majority)
	{
		size_t size = (src->majority == BASSO_ROW_MAJ ? src->rows : src->cols) * src->elem_per_vect * sizeof(basso_elem_t);
		memcpy(dest->data,src->data,size);
	}
	else
	{
		const uint64_t rows = src->rows;
		const uint64_t cols = src->cols;
		const uint64_t epv  = src->elem_per_vect;
		const basso_majority_t s_maj = src->majority;
		const basso_majority_t t_maj = dest->majority;
		/* Copy data; make sure the reading is cache-optimal */
		if (s_maj == BASSO_ROW_MAJ) {
			for (uint64_t i=0; i<rows; i++) {
				/* The last columns need to be dealt separately */
				for (uint64_t j=0; j<epv-1; j++) {
					const basso_elem_t x = src->data[i*epv + j];
					for (size_t k=0; k < basso_elem_bits; k++) {
						int val = BASSO_VAL_AT(x, k);
						uint64_t colid = j*basso_elem_bits + k;
						basso_m_set_val(dest, colid,i, val);
					}
				}
				{
					/* The last columns */
					const basso_elem_t x = src->data[i*epv + epv - 1];
					for (size_t l=0; (epv-1) * basso_elem_bits + l < cols; l++) {
						size_t k = l % basso_elem_bits;
						int val = BASSO_VAL_AT(x, k);
						uint64_t colid = (epv - 1)*basso_elem_bits + k;
						basso_m_set_val(dest, colid, i, val);
					}
				}
			}
		}
		else { /* if s_maj != BASSO_ROW_MAJ */
			for (uint64_t j=0; j < cols; j++) {
				for (uint64_t i=0; i  < epv-1; i++) {
					/* All except the last rows */
					const basso_elem_t x = src->data[j*epv + i];
					for (size_t k=0; k < basso_elem_bits; k++) {
						int val = BASSO_VAL_AT(x, k);
						uint64_t rowid = i*basso_elem_bits + k;
						basso_m_set_val(dest, j, rowid, val);
					}
				}
				{
					/* The last rows */
					const basso_elem_t x = src->data[j*epv + epv - 1];
					for (size_t l=0; (epv-1) * basso_elem_bits + l < rows; l++) {
						size_t k = l % basso_elem_bits;
						int val = BASSO_VAL_AT(x, k);
						uint64_t rowid = (epv - 1)*basso_elem_bits + k;
						basso_m_set_val(dest, j, rowid, val);
					}
				}
			}
		}
	}
	return 0;
}


int
basso_m_hor_concat(const basso_matrix_t *restrict A,const basso_matrix_t *restrict B,basso_matrix_t *new_mat)
{
	if(A == NULL || B == NULL)
	{
		BASSO_ERRMSG("Input matrices cannot be NULL");
		errno = EINVAL;
		return 1;
	}

	if(A->majority == BASSO_COL_MAJ && B->majority == BASSO_COL_MAJ)
	{
		if(A->rows != B->rows)
		{
			BASSO_ERRMSG("The number of rows of the matrices are not compatible");
			errno = EINVAL;
			return 1;
		}

		memcpy(new_mat->data, A->data, A->cols * A->elem_per_vect * sizeof(basso_elem_t));
		memcpy(new_mat->data + A->cols * A->elem_per_vect, B->data,B->cols * B->elem_per_vect * sizeof(basso_elem_t));
		return 0;
	}
	else
	{
		//fixme: horizontal concatenation on row major matrix has not been implemented.
		BASSO_ERRMSG("horizontal concatenation on row major matrix has not been implemented");
		return 1;
	}
}

basso_matrix_t *
basso_m_duplicate(const basso_matrix_t *A)
{
  if (A == NULL) {
    BASSO_ERRMSG("Input matrix cannot be NULL");
    errno = EINVAL;
    return NULL;
  }
  const uint64_t rows = A->rows;
  const uint64_t cols = A->cols;
  const uint64_t epv  = A->elem_per_vect;
  const basso_majority_t maj = A->majority;
  
  basso_matrix_t *B = basso_m_alloc(rows, cols, maj);
  if (B == NULL) {
    BASSO_ERRMSG("Out of memory");
    return NULL;
  }

  const uint64_t maj_dim = (A->majority == BASSO_ROW_MAJ) ? rows : cols;
  memcpy(B->data, A->data, maj_dim*epv*sizeof(basso_elem_t));
  
  return B;
}

basso_matrix_t *
basso_m_swap_duplicate(const basso_matrix_t *A)
{
  if (A == NULL) {
    errno = EINVAL;
    return NULL;
  }
  const uint64_t rows = A->rows;
  const uint64_t cols = A->cols;
  const uint64_t epv  = A->elem_per_vect;
  const basso_majority_t s_maj = A->majority;
  const basso_majority_t t_maj = (s_maj == BASSO_ROW_MAJ) ? BASSO_COL_MAJ : BASSO_ROW_MAJ;
  
  basso_matrix_t *B = basso_m_alloc(rows, cols, t_maj);
  if (B == NULL) return NULL;
  
  /* Copy data; make sure the reading is cache-optimal */
  if (s_maj == BASSO_ROW_MAJ) {
    for (uint64_t i=0; i<rows; i++) {
      /* The last columns need to be dealt separately */
      for (uint64_t j=0; j<epv-1; j++) {
        const basso_elem_t x = A->data[i*epv + j];
        for (size_t k=0; k < basso_elem_bits; k++) {
          int val = BASSO_VAL_AT(x, k);
          uint64_t colid = j*basso_elem_bits + k;
          basso_m_set_val(B, i, colid, val);
        }
      }
      {
        /* The last columns */
        const basso_elem_t x = A->data[i*epv + epv - 1];
        for (size_t l=0; (epv-1) * basso_elem_bits + l < cols; l++) {
          size_t k = l % basso_elem_bits;
          int val = BASSO_VAL_AT(x, k);
          uint64_t colid = (epv - 1)*basso_elem_bits + k;
          basso_m_set_val(B, i, colid, val);
        }
      }
    }
  } else { /* if s_maj == BASSO_ROW_MAJ */
    for (uint64_t j=0; j < cols; j++) {
      for (uint64_t i=0; i  < epv-1; i++) {
        /* All except the last rows */
        const basso_elem_t x = A->data[j*epv + i];
        for (size_t k=0; k < basso_elem_bits; k++) {
          int val = BASSO_VAL_AT(x, k);
          uint64_t rowid = i*basso_elem_bits + k;
          basso_m_set_val(B, rowid, j, val);
        }
      }
      {
        /* The last rows */
        const basso_elem_t x = A->data[j*epv + epv - 1];
        for (size_t l=0; (epv-1) * basso_elem_bits + l < rows; l++) {
          size_t k = l % basso_elem_bits;
          int val = BASSO_VAL_AT(x, k);
          uint64_t rowid = (epv - 1)*basso_elem_bits + k;
          basso_m_set_val(B, rowid, j, val);
        }
      }
    }
  }
  
  return B;
}

uint64_t
basso_m_nnz(const basso_matrix_t *A)
{
  if (A == NULL) {
    errno = EINVAL;
    return ULLONG_MAX;
  }
  const uint64_t rows = A->rows;
  const uint64_t cols = A->cols;
  const uint64_t epv  = A->elem_per_vect;
  uint64_t nnz = 0;
  
  /* Make sure the reading is cache-optimal */
  if (A->majority == BASSO_ROW_MAJ) {
    for (uint64_t i=0; i < rows; i++) {
#     pragma omp parallel for reduction(+:nnz)
      for (uint64_t j=0; j < epv; j++) {
        const basso_elem_t x = A->data[i*epv + j];
        nnz += BASSO_POPCNT(x);
      }
    }
  } else {
    for (uint64_t j=0; j < cols; j++) {
#     pragma omp parallel for reduction(+:nnz)
      for (uint64_t i=0; i < epv; i++) {
        const basso_elem_t x = A->data[j*epv + i];
        nnz += BASSO_POPCNT(x);
      }
    }
  }
  return nnz;
}

int
basso_m_row_sums(const basso_matrix_t *restrict A,
                 uint64_t *row_sums)
{
  int retval = 0;
  if (A == NULL || row_sums == NULL) {
    errno = EINVAL;
    return 1;
  }
  const uint64_t rows = A->rows;
  const uint64_t cols = A->cols;
  const uint64_t epv  = A->elem_per_vect;
  
  // Make sure row_sums starts from all-zeros
  memset(row_sums, 0, rows*sizeof(uint64_t));
  
  if (A->majority == BASSO_ROW_MAJ) {
    /* For row-major matrices, we sum each row separately */
    for (uint64_t i = 0; i < rows; i++) {
      uint64_t sum = 0;
#     pragma omp parallel for reduction(+:sum)
      for (uint64_t j = 0; j < epv; j++) {
        const basso_elem_t x = A->data[i*epv + j];
        sum += BASSO_POPCNT(x);
      }
      row_sums[i] = sum;
    }
  } else {
    /* For column-major, each thread takes basso_elem_bits rows and updates them */
    for (uint64_t j = 0; j < cols; j++) {
#     pragma omp parallel for
      /* Deal with the last rows separately */
      for (uint64_t i = 0; i < epv-1; i++) {
        const basso_elem_t x = A->data[j*epv + i];
        for (size_t k = 0; k < basso_elem_bits; k++) {
          row_sums[i*basso_elem_bits + k] += BASSO_VAL_AT(x, k);
        }
      }
      /* The last rows of column j */
      const basso_elem_t y = A->data[j*epv + epv-1]; // The last element of this column
      for (size_t k = 0; k < rows%basso_elem_bits; k++) {
        row_sums[(epv - 1)*basso_elem_bits + k] += BASSO_VAL_AT(y, k);
      }
    }
  } /* if majority == BASSO_ROW_MAJ */
  
  return retval;
}

int
basso_m_col_sums(const basso_matrix_t *restrict A,
                 uint64_t *col_sums)
{
  int retval = 0;
  if (A == NULL || col_sums == NULL) {
    errno = EINVAL;
    return 1;
  }
  const uint64_t rows = A->rows;
  const uint64_t cols = A->cols;
  const uint64_t epv  = A->elem_per_vect;

  // Make sure col_sums starts with all-zeros
  memset(col_sums, 0, cols*sizeof(uint64_t));
  
  if (A->majority == BASSO_COL_MAJ) {
    for (uint64_t j = 0; j < cols; j++) {
      uint64_t sum = 0;
#     pragma omp parallel for reduction(+:sum)
      for (uint64_t i = 0; i < epv; i++) {
        const basso_elem_t x = A->data[j*epv + i];
        sum += BASSO_POPCNT(x);
      }
      col_sums[j] = sum;
    }
  } else { /* row-major */
    for (uint64_t i = 0; i < rows; i++) {
#     pragma omp parallel for
      for (uint64_t j = 0; j < epv - 1; j++) {
        const basso_elem_t x = A->data[i*epv + j];
        for (size_t k = 0; k < basso_elem_bits; k++) {
          col_sums[j*basso_elem_bits + k] += BASSO_VAL_AT(x, k);
        }
      }
      /* The last columns of row i we need to deal separately */
      const basso_elem_t y = A->data[i*epv + epv - 1]; // The last element of this row
      for (size_t k = 0; k < cols%basso_elem_bits; k++) {
        col_sums[(epv - 1)*basso_elem_bits + k] += BASSO_VAL_AT(y, k);
      }
    }
  } /* if majority == BASSO_COL_MAJOR */
  
  return retval;
}

int
basso_m_bprod(const basso_matrix_t *restrict origA,
              const basso_matrix_t *restrict origB,
                    basso_matrix_t *restrict C)
{
  int retval = 0;
  basso_matrix_t *restrict tmpA = NULL; // If we need to swap A
  basso_matrix_t *restrict tmpB = NULL; // If we need to swap B
  if (origA == NULL || origB == NULL) {
    errno = EINVAL;
    retval = 1;
    goto cleanup;
  }
  /* Start by making sure A is row-major and B is col-major */
  errno = 0;
  if (origA->majority != BASSO_ROW_MAJ) {
    tmpA = basso_m_swap_duplicate(origA);
    if (tmpA == NULL) goto cleanup;
  }
  if (origB->majority != BASSO_COL_MAJ) {
    tmpB = basso_m_swap_duplicate(origB);
    if (tmpB == NULL) goto cleanup;
  }

  /* Copy the potentially swapped matrix pointer to const working pointers */
  const basso_matrix_t *A = (tmpA == NULL) ? origA : tmpA;
  const basso_matrix_t *B = (tmpB == NULL) ? origB : tmpB;
  
  const uint64_t rows = A->rows;
  const uint64_t cols = B->cols;

  const uint64_t elem_per_vect = A->elem_per_vect; // same as B->elem_per_vect
  if (B->elem_per_vect != elem_per_vect) {
    errno = EINVAL;
    retval = 1;
    goto cleanup;
  }
  
  
  const uint64_t C_elem_per_col = C->elem_per_vect;
  
  for(uint64_t j = 0; j < cols; j++) {
    // b is the j-th column of B
    const basso_elem_t *restrict b = B->data + j*elem_per_vect;
    // c is the j-th column of C - FIXME: not used
    //basso_elem_t *restrict c = C->data + j*C_elem_per_col;
    // The for-loop is over the basso_elem_t's in C's columns to avoid race to write
#   pragma omp parallel for
    for (uint64_t row_i = 0; row_i < C_elem_per_col; row_i++) {
      /* We need to make basso_elem_bits steps except perhaps in the last integer */
      const uint64_t max_i = ((row_i + 1)*basso_elem_bits < rows) ? (row_i+1)*basso_elem_bits : rows;
      for (uint64_t i = row_i*basso_elem_bits; i < max_i; i++) {
        int val = 0;
        for (uint64_t k = 0; k < elem_per_vect; k++) {
          // We test the full uint64_t a time and set the result to 1 if any bit is one
          const uint64_t A_and_B = A->data[elem_per_vect*i + k] & b[k];
          val |= (A_and_B > 0); // AB_and is true if any bit is true
        }
        basso_m_set_val(C, i, j, val);
      }
    }
  }
  
cleanup:
  basso_m_free(tmpA);
  basso_m_free(tmpB);
  return retval;
}

uint64_t
basso_m_diff(const basso_matrix_t *restrict A,
             const basso_matrix_t *restrict origB)
{
  if (A == NULL || origB == NULL) {
    BASSO_ERRMSG("Input cannot be NULL");
    errno = EINVAL;
    return ULLONG_MAX;
  }
  const uint64_t rows = A->rows;
  const uint64_t cols = A->cols;
  const uint64_t epv = A->elem_per_vect;
  uint64_t err = 0;
  basso_matrix_t *tmpB = NULL;
  
  if (rows != origB->rows || cols != origB->cols) {
    BASSO_ERRMSG("Matrix dimensions do not agree");
    errno = EINVAL;
    return ULLONG_MAX;
  }

  /* Make sure A and B have the same majority */
  if (A->majority != origB->majority) {
    tmpB = basso_m_swap_duplicate(origB);
    if (tmpB == NULL) {
      BASSO_ERRMSG("Out of memory");
      basso_m_free(tmpB); //We must have tried to swap B
      return ULLONG_MAX;
    }
  }
  /* Make sure B is the potentially swapped matrix */
  const basso_matrix_t *B = (tmpB == NULL) ? origB : tmpB;
  
  const uint64_t maj_dim = (A->majority == BASSO_ROW_MAJ) ? rows : cols;
  for (uint64_t i = 0; i < maj_dim; i++) {
    /* The i-th majority vectors of A and B */
    const basso_elem_t *restrict a = A->data + i*epv;
    const basso_elem_t *restrict b = B->data + i*epv;
#   pragma omp parallel for reduction(+:err)
    for (uint64_t j = 0; j < epv; j++) {
      const basso_elem_t a_xor_b = a[j] ^ b[j];
      err += BASSO_POPCNT(a_xor_b);
    }
  }
  
  basso_m_free(tmpB);
  return err;
}

uint64_t
basso_m_diff_ignore_diagonal(const basso_matrix_t *restrict A,
             	 	 	 	 const basso_matrix_t *restrict origB)
{
  if (A == NULL || origB == NULL) {
    BASSO_ERRMSG("Input cannot be NULL");
    errno = EINVAL;
    return ULLONG_MAX;
  }
  const uint64_t rows = A->rows;
  const uint64_t cols = A->cols;
  const uint64_t epv = A->elem_per_vect;
  uint64_t err = 0;
  basso_matrix_t *tmpB = NULL;

  if (rows != origB->rows || cols != origB->cols) {
    BASSO_ERRMSG("Matrix dimensions do not agree");
    errno = EINVAL;
    return ULLONG_MAX;
  }

  /* Make sure A and B have the same majority */
  if (A->majority != origB->majority) {
    tmpB = basso_m_swap_duplicate(origB);
    if (tmpB == NULL) {
      BASSO_ERRMSG("Out of memory");
      basso_m_free(tmpB); //We must have tried to swap B
      return ULLONG_MAX;
    }
  }
  /* Make sure B is the potentially swapped matrix */
  const basso_matrix_t *B = (tmpB == NULL) ? origB : tmpB;

  const uint64_t maj_dim = (A->majority == BASSO_ROW_MAJ) ? rows : cols;
  for (uint64_t i = 0; i < maj_dim; i++) {
    /* The i-th majority vectors of A and B */
    const basso_elem_t *restrict a = A->data + i*epv;
    const basso_elem_t *restrict b = B->data + i*epv;
#   pragma omp parallel for reduction(+:err)
    for (uint64_t j = 0; j < epv; j++) {
      basso_elem_t a_xor_b = a[j] ^ b[j];

      //set the value on the diagonal of (A_XOR_B) to zero
      if(j == i/basso_elem_bits)
      {
    	  a_xor_b &= ~BASSO_ONE_AT_IND(i % basso_elem_bits);
      }

      err += BASSO_POPCNT(a_xor_b);
    }
  }

  basso_m_free(tmpB);
  return err;
}


uint64_t
basso_m_bnorm(const basso_matrix_t *restrict A,
              const basso_matrix_t *restrict B,
              const basso_matrix_t *restrict C)
{
  uint64_t norm;
  
  if (A == NULL || B == NULL || C == NULL) {
    errno = EINVAL;
    return ULLONG_MAX;
  }
  
  basso_matrix_t *D = basso_m_alloc(B->rows, C->cols, A->majority);
  if (D == NULL) {
    return ULLONG_MAX;
  }
  if (basso_m_bprod(B, C, D)) {
    return ULLONG_MAX;
  }
  
  norm = basso_m_diff(A, D);
  basso_m_free(D);
  
  return norm;
}

basso_matrix_t *
basso_m_eye(const uint64_t dim, const basso_majority_t maj)
{
  basso_matrix_t *A = basso_m_alloc(dim, dim, maj);
  if (A == NULL) {
    BASSO_ERRMSG("Out of memory");
    return NULL;
  }
  
  for (uint64_t i = 0; i < dim; i++) {
    basso_m_set_val(A, i, i, 1);
  }
  
  return A;
}

basso_matrix_t *
basso_m_XOR(const basso_matrix_t *restrict A,
			const basso_matrix_t *restrict B)
{
	if(A == NULL || B == NULL)
	{
		BASSO_ERRMSG("The input matrices cannot be null");
		errno = EINVAL;
		return NULL;
	}

	if(A->rows != B->rows || A->cols != B->cols)
	{
		BASSO_ERRMSG("The input matrices cannot be null");
				errno = EINVAL;
				return NULL;
	}

	if(A->majority != B->majority)
	{
		//Fixme: not implemented
		BASSO_ERRMSG("has not been implemented");
		return NULL;
	}
	else
	{
		basso_matrix_t *C = basso_m_alloc(A->rows,A->cols,A->majority);
		uint64_t elem_count = A->elem_per_vect * (A->majority == BASSO_ROW_MAJ ? A->rows : A->cols);
		for(uint64_t i=0 ; i < elem_count ; i++)
			C->data[i] = A->data[i] ^ B->data[i];
		return C;
	}
}

int
basso_m_set_all_zeros(basso_matrix_t *A)
{
  if (A == NULL) {
    errno = EINVAL;
    return 1;
  }
  if (A->majority == BASSO_ROW_MAJ) {
    memset(A->data, 0, A->rows*A->elem_per_vect*sizeof(basso_elem_t));
  } else {
    memset(A->data, 0, A->cols*A->elem_per_vect*sizeof(basso_elem_t));
  }
  
  return 0;
}

int
basso_m_set_all_ones(basso_matrix_t *A)
{
  /* The padding bits must stay 0, hence we'll set the values 
   * element-by-element.
   */
  if (A == NULL) {
    errno = EINVAL;
    return 1;
  }

  if (A->majority == BASSO_ROW_MAJ) {
    for (uint64_t i = 0; i < A->rows; i++) {
      for (uint64_t j = 0; j < A->cols; j++) {
        basso_m_set_val(A, i, j, 1);
      }
    }
  } else { // majority == BASSO_ROW_MAJ
    for (uint64_t j = 0; j < A->cols; j++) {
      for (uint64_t i = 0; i < A->rows; i++) {
        basso_m_set_val(A, i, j, 1);
      }
    }
  }
  
  return 0;
}

int
basso_m_set_nth_row_zero(basso_matrix_t *restrict A,const uint64_t i)
{
	if(A == NULL)
	{
		errno = EINVAL;
		return 1;
	}

	if(A->majority == BASSO_ROW_MAJ)
	{
		memset(A->data + i * A->elem_per_vect , 0 , A->elem_per_vect * sizeof(basso_elem_t));
	}
	else
	{
		for(uint64_t j=0 ; j < A->cols ; j++)
			basso_m_set_val(A,i,j,0);
	}

	return 0;
}

int
basso_m_set_nth_col_zero(basso_matrix_t *restrict A,const uint64_t j)
{
	if(A == NULL)
	{
		errno = EINVAL;
		return 1;
	}

	if(A->majority == BASSO_COL_MAJ)
	{
		memset(A->data + j * A->elem_per_vect , 0 , A->elem_per_vect * sizeof(basso_elem_t));
	}
	else
	{
		for(uint64_t i=0 ; i < A->rows ; i++)
			basso_m_set_val(A,i,j,0);
	}

	return 0;
}

int
compare_vector(const basso_elem_t *restrict v1,const basso_elem_t *restrict v2,const uint64_t elem_per_vect)
{
	for(uint64_t k=0 ; k < elem_per_vect ; k++)
	{
		if(v1[k] == v2[k])
			continue;
		else
		{
			for(int i=0 ; i < basso_elem_bits ; i++)
			{
				if((BASSO_ONE_AT_IND(i) & v1[k]) == (BASSO_ONE_AT_IND(i) & v2[k]))
					continue;
				else if((BASSO_ONE_AT_IND(i) & v1[k]) > (BASSO_ONE_AT_IND(i) & v2[k]))
					return 1;
				else
					return -1;
			}
			break;
		}
	}
	return 0;
}



int
sort_compare_operator(const void * a, const void * b)
{
	static const basso_matrix_t *mat;
	if(b==NULL)
	{
		mat = (basso_matrix_t *)a;
		return 0;
	}
	else
	{
		uint64_t col1 = *((uint64_t *)a);
		uint64_t col2 = *((uint64_t *)b);
		basso_elem_t *v1 = mat->data + col1 * mat->elem_per_vect;
		basso_elem_t *v2 = mat->data + col2 * mat->elem_per_vect;
		return compare_vector(v1,v2,mat->elem_per_vect);
	}
}

basso_matrix_t *
basso_m_remove_duplicate_column(const basso_matrix_t *restrict mat)
{
	if(mat->majority == BASSO_ROW_MAJ)
	{
		BASSO_ERRMSG("NOT IMPLEMENTED");
		return NULL;
		//not implemented
	}

	uint64_t *column_indexes = (uint64_t *)malloc(mat->cols * sizeof(uint64_t));

#pragma omp parallel for
	for(uint64_t i=0 ; i < mat->cols ; i++)
		column_indexes[i] = i;

	sort_compare_operator(mat,NULL);
	qsort(column_indexes,mat->cols,sizeof(uint64_t),sort_compare_operator);

	basso_matrix_t *M = basso_m_alloc(mat->rows,mat->cols,mat->majority);
	uint64_t last_idx = 0;
	for(uint64_t i=0 ; i < mat->cols; i++)
	{
		if(i == (mat->cols-1))
		{
			memcpy(M->data + last_idx * M->elem_per_vect, mat->data + column_indexes[i] * mat->elem_per_vect , mat->elem_per_vect * sizeof(basso_elem_t));
			last_idx ++;
			break;
		}
		basso_elem_t *v1 = mat->data + column_indexes[i] 	* mat->elem_per_vect;
		basso_elem_t *v2 = mat->data + column_indexes[i+1] 	* mat->elem_per_vect;
		if(compare_vector(v1,v2,mat->elem_per_vect) != 0)
		{

			memcpy(M->data + last_idx * M->elem_per_vect, mat->data + column_indexes[i] * mat->elem_per_vect , mat->elem_per_vect * sizeof(basso_elem_t));
			last_idx ++;
		}
	}

	basso_matrix_t *M_unique = basso_m_alloc(M->rows,last_idx,mat->majority);
	memcpy(M_unique->data,M->data,last_idx * M->elem_per_vect * sizeof(basso_elem_t));

	basso_m_free(M);
	free(column_indexes);
	return M_unique;
}

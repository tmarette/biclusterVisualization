/*
 * basso_cu_device_kernels.h
 *
 *  Created on: May 20, 2016
 *      Author: enadjara
 */

#ifndef BASSO_CU_DEVICE_KERNELS_H_
#define BASSO_CU_DEVICE_KERNELS_H_

#include "basso_cu.h"


BEGIN_C_DECL

//#define MaxThreadsPerBlock 1024
//#define MaxThreadsPerBlockX 4
//#define MaxThreadsPerBlockY	256
//#define WarpSize 32
//#define HALF_WARP_SIZE 16
#define WARP_SIZE 32
//
//#define BLOCKSIZE_WIDTH 	16 // at most warp size = 32
//#define BLOCKSIZE_HEIGHT	16


#define BASSO_CU_BLOCKSIZE	32
#define BASSO_CU_A_VECTOR_PER_STREAM	512

#define BASSO_CU_NUMBER_OF_STREAMS 4 //better to be device count or device_count * memory copy engine

#define BASSO_CU_BASIS_SELECTION_A_VECTOR_PER_STREAM	512//at least 16 , divisible by 16
#define BASSO_CU_BASIS_SELECTION_C_VECTOR_PER_STREAM	512

#define BASSO_CU_B_VECTOR_PER_STREAM	512

__global__ void
basso_cu_get_association_matrix_kernel(const basso_matrix_t A1,const basso_matrix_t A2,const uint64_t C_row_offset,const double thresholds[],const uint64_t thresholds_len,basso_matrix_t C);

__global__ void
basso_cu_get_covered_scores_kernel(const basso_matrix_t A,const basso_matrix_t C,const basso_matrix_t Covered, const uint64_t covering_1s_weight,const uint64_t covering_0s_weight,uint64_t *scores);

__global__ void
basso_cu_update_covered_scores_kernel(const basso_matrix_t A,const basso_matrix_t C,const basso_matrix_t Covered,const basso_elem_t *C_vector,const uint64_t covering_1s_weight,const uint64_t covering_0s_weight,long long *scores);

__global__ void
basso_cu_get_right_factor_vector_kernel(const basso_matrix_t A, const basso_matrix_t Covered, const basso_elem_t *C_vector, const uint64_t covering_1s_weight,const uint64_t covering_0s_weight, basso_elem_t *X_vector);

__global__ void
basso_cu_update_covered_matrix_kernel(const basso_elem_t *C_vector,const basso_elem_t *X_vector,basso_matrix_t Covered);

__global__ void
basso_cu_max_reduction_kernel(uint64_t *arr,const uint64_t N,uint64_t *maximum_value,uint64_t *maximum_index);

__global__ void
basso_cu_update_covered_matrix_without_nth_factor_kernel(const basso_matrix_t B,basso_matrix_t covered_vector);


END_C_DECL

#endif /* BASSO_CU_DEVICE_KERNELS_H_ */

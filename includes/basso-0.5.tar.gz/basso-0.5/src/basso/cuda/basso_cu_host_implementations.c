#ifdef HAVE_CONFIG_H
# include "config.h"
#endif

#include <errno.h>
#include "basso_cu.h"
#include "basso_cu_device_kernels.h"
#include "math.h"
#include "stdio.h"
#include "stdbool.h"
#include "../linked_list.h"
#include "../BinaryHeap.h"
#include "../bassopriv.h"
#include <omp.h>


//These variables are filled in the init
int device_count;

//Each stream has its own plate to copy partial data from host to device
cudaStream_t streams [BASSO_CU_NUMBER_OF_STREAMS];
uint64_t covering_1s_weight;
uint64_t covering_0s_weight;



basso_matrix_t *restrict
basso_cu_association_matrix(const basso_matrix_t *restrict h_A,
							const basso_option_t *restrict h_opt)
{
	int device_count;
	cudaGetDeviceCount(&device_count);

	for(int i=0 ; i < BASSO_CU_NUMBER_OF_STREAMS ; i++)
	{
		cudaSetDevice(i % device_count);
		cudaStreamCreate(&streams[i]);
	}

	//copy thresholds to the gpu
	const uint64_t thresholds_len 	= basso_opt_get_threshold_list_len(h_opt);
	const double* thresholds 		= basso_opt_get_threshold_list(h_opt);

	basso_matrix_t *d_A1	[BASSO_CU_NUMBER_OF_STREAMS];
	basso_matrix_t *d_A2	[BASSO_CU_NUMBER_OF_STREAMS];
	basso_matrix_t *d_asso	[BASSO_CU_NUMBER_OF_STREAMS];
	double* d_thresholds	[BASSO_CU_NUMBER_OF_STREAMS];

	basso_matrix_t *h_C;
	basso_cu_m_alloc(h_A->rows,h_A->rows * thresholds_len,BASSO_COL_MAJ,BASSO_CU_ON_HOST,&h_C);

	//fixme: error handling needed here
	for(int i=0 ; i< BASSO_CU_NUMBER_OF_STREAMS ; i++)
	{
		cudaSetDevice(i % device_count);
		basso_cu_m_alloc(BASSO_CU_A_VECTOR_PER_STREAM,h_A->cols,BASSO_ROW_MAJ,BASSO_CU_ON_DEVICE,&d_A1[i]);
		basso_cu_m_alloc(BASSO_CU_A_VECTOR_PER_STREAM,h_A->cols,BASSO_ROW_MAJ,BASSO_CU_ON_DEVICE,&d_A2[i]);
		basso_cu_m_alloc(h_A->rows,BASSO_CU_A_VECTOR_PER_STREAM * thresholds_len,BASSO_COL_MAJ,BASSO_CU_ON_DEVICE,&d_asso[i]);

		cudaMalloc((void **) &d_thresholds[i], thresholds_len * sizeof(double));
		cudaMemcpyAsync(d_thresholds[i],thresholds,thresholds_len * sizeof(double),cudaMemcpyHostToDevice,streams[i]);

		cudaStreamSynchronize(streams[i]);
	}

	uint64_t stream_idx = 0;
	for(int i=0 ; i < h_A->rows ; i += BASSO_CU_A_VECTOR_PER_STREAM , stream_idx = (stream_idx + 1) % BASSO_CU_NUMBER_OF_STREAMS)
	{
		cudaSetDevice(stream_idx % device_count);

		basso_cu_block A1_offset_on_dest = make_block(0,0);
		basso_cu_block A1_offset_on_src = make_block(i,0);
		basso_cu_block A1_copy_size = make_block(min((uint64_t)BASSO_CU_A_VECTOR_PER_STREAM, h_A->rows - i),h_A->cols);

		d_A1[stream_idx]->rows = A1_copy_size.rows;
		basso_cu_m_block_copy(d_A1[stream_idx],A1_offset_on_dest,h_A,A1_offset_on_src,A1_copy_size,streams[stream_idx],cudaMemcpyHostToDevice);

		basso_cu_m_device_set_elements_to_zero(d_asso[stream_idx],streams[stream_idx]);
		for(int j=0 ; j < h_A->rows ; j += BASSO_CU_A_VECTOR_PER_STREAM)
		{
			basso_cu_block A2_offset_on_dest = make_block(0,0);
			basso_cu_block A2_offset_on_src = make_block(j,0);
			basso_cu_block A2_copy_size = make_block(min((uint64_t)BASSO_CU_A_VECTOR_PER_STREAM, h_A->rows - j),h_A->cols);

			d_A2[stream_idx]->rows = A2_copy_size.rows;
			basso_cu_m_block_copy(d_A2[stream_idx],A2_offset_on_dest,h_A,A2_offset_on_src,A2_copy_size,streams[stream_idx],cudaMemcpyHostToDevice);

			dim3 threads_per_block (BASSO_CU_BLOCKSIZE,BASSO_CU_BLOCKSIZE);
			dim3 blocks_per_grid (BASSO_CU_A_VECTOR_PER_STREAM / BASSO_CU_BLOCKSIZE, BASSO_CU_A_VECTOR_PER_STREAM / BASSO_CU_BLOCKSIZE);

			basso_cu_get_association_matrix_kernel <<<blocks_per_grid,threads_per_block,0,streams[stream_idx]>>> (*d_A2[stream_idx],*d_A1[stream_idx],j,d_thresholds[stream_idx],thresholds_len,*d_asso[stream_idx]);

			CUDA_CHECK_LAST_ERROR();

			d_A2[stream_idx]->rows = BASSO_CU_A_VECTOR_PER_STREAM; // reset the size of the plate
		}


		basso_cu_block C_offset_on_dest = make_block(0,i * thresholds_len);
		basso_cu_block C_offset_on_src = make_block(0,0);
		basso_cu_block C_copy_size = make_block(d_asso[stream_idx]->rows,A1_copy_size.rows * thresholds_len);

		basso_cu_m_block_copy(h_C,C_offset_on_dest,d_asso[stream_idx],C_offset_on_src,C_copy_size,streams[stream_idx],cudaMemcpyDeviceToHost);

		d_A1[stream_idx]->rows = BASSO_CU_A_VECTOR_PER_STREAM; // reset the size of the plate
	}

	for(int i=0;i<device_count;i++)
	{
		cudaSetDevice(i);
		cudaDeviceSynchronize();
	}

	//Fixme: error handling on failed situation

	for (int i = 0; i < BASSO_CU_NUMBER_OF_STREAMS; ++i)
	{
		cudaSetDevice(i % device_count);
		cudaStreamDestroy(streams[i]);
	}

	for(int i=0 ; i < BASSO_CU_NUMBER_OF_STREAMS ; i++)
	{
		cudaSetDevice(i % device_count);
		basso_cu_m_free(d_A1[i],BASSO_CU_ON_DEVICE);
		basso_cu_m_free(d_A2[i],BASSO_CU_ON_DEVICE);
		basso_cu_m_free(d_asso[i],BASSO_CU_ON_DEVICE);
		cudaFree(d_thresholds[i]);
	}

	return h_C;
}



int
cu_compute_candidates_covered_score(	const basso_matrix_t *A,
										const basso_matrix_t *C,
										const basso_matrix_t *Covered,
										uint64_t h_covered_scores[])
{
	/*
	 * The whole coming process is asynchronous since the CPU (HOST) copy the needed data by GPUS (DEVICE) and
	 * doesn't wait for GPU to finish the kernel call. The streams are synchronous individually but asynchronous to each other.
	 */

	/*
	 * To compute the candidate covered score, we distribute candidates (columns) of candidate matrix (C) among
	 * streams. Each streams computes covered score for BASSO_CU_BASIS_SELECTION_C_VECTOR_PER_STREAM candidates per Kernel call.
	 */
	basso_matrix_t 	*d_A 				[BASSO_CU_NUMBER_OF_STREAMS];
	basso_matrix_t 	*d_C 				[BASSO_CU_NUMBER_OF_STREAMS];
	basso_matrix_t 	*d_Covered			[BASSO_CU_NUMBER_OF_STREAMS];
	uint64_t 		*d_covered_scores	[BASSO_CU_NUMBER_OF_STREAMS];

	for(int i=0 ; i< BASSO_CU_NUMBER_OF_STREAMS ; i++)
	{
		cudaSetDevice(i % device_count);
		basso_cu_m_alloc(A->rows,BASSO_CU_BASIS_SELECTION_A_VECTOR_PER_STREAM,BASSO_COL_MAJ,BASSO_CU_ON_DEVICE,&d_A[i]);
		basso_cu_m_alloc(A->rows,BASSO_CU_BASIS_SELECTION_A_VECTOR_PER_STREAM,BASSO_COL_MAJ,BASSO_CU_ON_DEVICE,&d_Covered[i]);
		basso_cu_m_alloc(C->rows,BASSO_CU_BASIS_SELECTION_C_VECTOR_PER_STREAM,BASSO_COL_MAJ,BASSO_CU_ON_DEVICE,&d_C[i]);
		cudaMalloc((void **) &d_covered_scores[i] , BASSO_CU_BASIS_SELECTION_C_VECTOR_PER_STREAM * sizeof(uint64_t));
	}

	uint64_t device_idx = 0;
	uint64_t stream_idx = 0;
	for(int i=0 ; i < C->cols ; i += BASSO_CU_BASIS_SELECTION_C_VECTOR_PER_STREAM , stream_idx = (stream_idx + 1) % BASSO_CU_NUMBER_OF_STREAMS)
	{
		//Set the device which current stream was previously assigned to
		device_idx = stream_idx % device_count;
		cudaSetDevice(device_idx);

		//Calculating the offset and size of the copy.
		basso_cu_block C_copy_size = make_block(C->rows, min((uint64_t)BASSO_CU_BASIS_SELECTION_C_VECTOR_PER_STREAM, C->cols - i));
		d_C[stream_idx]->cols = C_copy_size.cols;
		//Copy the candidates from host to the candidate-plate (d_C) on the set device

		basso_cu_m_block_copy(d_C[stream_idx], make_block(0,0), C, make_block(0,i), C_copy_size, streams[stream_idx], cudaMemcpyHostToDevice);

		cudaMemsetAsync(d_covered_scores[stream_idx],0,BASSO_CU_BASIS_SELECTION_C_VECTOR_PER_STREAM * sizeof(uint64_t),streams[stream_idx]);

		/*
		 * Now, the candidates are ready. It needs to compute partial covered score for a part of A. Thus, again,
		 * BASSO_CU_BASIS_SELECTION_A_VECTOR_PER_STREAM columns of A and mask matrix (Covered) are moved to device for each stream.
		 */
		for(int j=0 ; j < A->cols ; j += BASSO_CU_BASIS_SELECTION_A_VECTOR_PER_STREAM)
		{
			//Calculating the offset and size of copy transfer
			basso_cu_block A_copy_size = make_block(A->rows,min((uint64_t)BASSO_CU_BASIS_SELECTION_A_VECTOR_PER_STREAM, A->cols - j));
			d_A[stream_idx]->cols = A_copy_size.cols;
			basso_cu_m_block_copy(d_A[stream_idx], make_block(0,0), A, make_block(0,j),A_copy_size,streams[stream_idx],cudaMemcpyHostToDevice);

			basso_cu_block Covered_copy_size = A_copy_size;
			d_Covered[stream_idx]->cols = A_copy_size.cols;
			basso_cu_m_block_copy(d_Covered[stream_idx], make_block(0,0), Covered, make_block(0,j),Covered_copy_size,streams[stream_idx],cudaMemcpyHostToDevice);

			//Calculating the number of threads and blocks of threads it needs.
			dim3 threads_per_block (BASSO_CU_BLOCKSIZE,BASSO_CU_BLOCKSIZE);
			dim3 blocks_per_grid (BASSO_CU_BASIS_SELECTION_C_VECTOR_PER_STREAM / BASSO_CU_BLOCKSIZE);

			/*
			 * Calling the kernel with the current stream and set of data it transfered.
			 * The partial covered scores are accumulated to d_covered_scores.
			 */
			basso_cu_get_covered_scores_kernel <<<blocks_per_grid,threads_per_block,0,streams[stream_idx]>>>
					(*d_A[stream_idx],*d_C[stream_idx],*d_Covered[stream_idx],covering_1s_weight,covering_0s_weight,d_covered_scores[stream_idx]);

			CUDA_CHECK_LAST_ERROR();

			d_A[stream_idx]->cols 		= BASSO_CU_BASIS_SELECTION_A_VECTOR_PER_STREAM;
			d_Covered[stream_idx]->cols = BASSO_CU_BASIS_SELECTION_A_VECTOR_PER_STREAM;

		}

		//The total covered scores computation is done and needs to transfered back to host with the offset i (The chunk it was working on)
		cudaMemcpyAsync(h_covered_scores + i, d_covered_scores[stream_idx] , C_copy_size.cols * sizeof(uint64_t) , cudaMemcpyDeviceToHost,streams[stream_idx]);

		d_C[stream_idx]->cols = BASSO_CU_BASIS_SELECTION_C_VECTOR_PER_STREAM;
	}

	//We need to wait for all devices to compute their compuation
	for(int i=0;i<device_count;i++)
	{
		cudaSetDevice(i);
		cudaDeviceSynchronize();
	}

	for(int i=0 ; i < BASSO_CU_NUMBER_OF_STREAMS ; i++)
	{
		cudaSetDevice(i % device_count);
		basso_cu_m_free(d_A[i],BASSO_CU_ON_DEVICE);
		basso_cu_m_free(d_C[i],BASSO_CU_ON_DEVICE);
		basso_cu_m_free(d_Covered[i],BASSO_CU_ON_DEVICE);
		cudaFree(d_covered_scores[i]);
	}

	return 0;
}

uint64_t
cu_find_max_covered_score_candidate_index(const uint64_t h_covered_scores[],const uint64_t len)
{
	//Fixme: use openmp
	//Find the index of candidate with maximum covered score
	uint64_t max_score_candidate_idx = 0;
	uint64_t max_score_candidate = 0;
	for(uint64_t i=0 ; i < len ; i++)
	{
		//printf("Scores[%llu] = %llu\n",i,h_covered_scores[i]);
		if(h_covered_scores[i] > max_score_candidate)
		{
			max_score_candidate = h_covered_scores[i];
			max_score_candidate_idx = i;
		}
	}

	return max_score_candidate_idx;
}



int
cu_get_candidate_corresponding_factor(	const basso_matrix_t 	*A,
										const basso_matrix_t 	*Covered,
										const basso_elem_t 		*candidate,
										basso_elem_t 			*factor)
{
	basso_matrix_t 	**d_C_vector;
	basso_matrix_t 	**d_X_vector;
	cudaMallocHost((void **) &d_C_vector, device_count * sizeof(basso_matrix_t *));
	cudaMallocHost((void **) &d_X_vector, device_count * sizeof(basso_matrix_t *));
	basso_matrix_t 	*d_A 				[BASSO_CU_NUMBER_OF_STREAMS];
	basso_matrix_t 	*d_Covered			[BASSO_CU_NUMBER_OF_STREAMS];

	for(int i=0 ; i < device_count ; i++)
	{
		cudaSetDevice(i);
		basso_cu_m_alloc(A->rows,1,BASSO_COL_MAJ,BASSO_CU_ON_DEVICE,&d_C_vector[i]);
		basso_cu_m_alloc(1,A->cols,BASSO_ROW_MAJ,BASSO_CU_ON_DEVICE,&d_X_vector[i]);
	}

	for(int i=0 ; i< BASSO_CU_NUMBER_OF_STREAMS ; i++)
	{
		cudaSetDevice(i % device_count);
		basso_cu_m_alloc(A->rows,BASSO_CU_BASIS_SELECTION_A_VECTOR_PER_STREAM,BASSO_COL_MAJ,BASSO_CU_ON_DEVICE,&d_A[i]);
		basso_cu_m_alloc(A->rows,BASSO_CU_BASIS_SELECTION_A_VECTOR_PER_STREAM,BASSO_COL_MAJ,BASSO_CU_ON_DEVICE,&d_Covered[i]);
	}

	uint64_t device_idx = 0;
	uint64_t stream_idx = 0;

	for(int i=0 ; i < device_count ; i++)
	{
		cudaSetDevice(i);
		cudaMemcpy(d_C_vector[i]->data,candidate ,A->elem_per_vect * sizeof(basso_elem_t),cudaMemcpyHostToDevice);
		//basso_cu_m_block_copy(d_C_vector[i], make_block(0,0), C, make_block(0,candidate_index), make_block(C->rows,1),streams[i % BASSO_CU_NUMBER_OF_STREAMS],cudaMemcpyHostToDevice);
		basso_cu_m_device_set_elements_to_zero(d_X_vector[i],streams[i % BASSO_CU_NUMBER_OF_STREAMS]);
	}

	for(int i=0 ; i < A->cols ; i += BASSO_CU_BASIS_SELECTION_A_VECTOR_PER_STREAM , stream_idx = (stream_idx + 1) % BASSO_CU_NUMBER_OF_STREAMS)
	{
		device_idx = stream_idx % device_count;
		cudaSetDevice(device_idx);

		//Copy A sub-matrix from host to device
		basso_cu_block A_copy_size = make_block(A->rows,min((uint64_t)BASSO_CU_BASIS_SELECTION_A_VECTOR_PER_STREAM, A->cols - i));
		d_A[stream_idx]->cols = A_copy_size.cols;
		basso_cu_m_block_copy(d_A[stream_idx], make_block(0,0), A, make_block(0,i),A_copy_size,streams[stream_idx],cudaMemcpyHostToDevice);

		//Copy Covered sub-matrix from host to device
		basso_cu_block Covered_copy_size = A_copy_size;
		d_Covered[stream_idx]->cols = A_copy_size.cols;
		basso_cu_m_block_copy(d_Covered[stream_idx], make_block(0,0), Covered, make_block(0,i),Covered_copy_size,streams[stream_idx],cudaMemcpyHostToDevice);

		dim3 threads_per_block (BASSO_CU_BLOCKSIZE,BASSO_CU_BLOCKSIZE);
		dim3 blocks_per_grid (BASSO_CU_BASIS_SELECTION_A_VECTOR_PER_STREAM / BASSO_CU_BLOCKSIZE);

		basso_cu_get_right_factor_vector_kernel <<<blocks_per_grid,threads_per_block,0,streams[stream_idx]>>>
				(*d_A[stream_idx],*d_Covered[stream_idx],d_C_vector[device_idx]->data,covering_1s_weight,covering_0s_weight,d_X_vector[device_idx]->data + i / basso_elem_bits);

		CUDA_CHECK_LAST_ERROR();

		//small memcpy -> very bad
		cudaMemcpyAsync(factor + i / basso_elem_bits ,
				d_X_vector[device_idx]->data + i / basso_elem_bits,
				ceilf((float)A_copy_size.cols / basso_elem_bits)  * sizeof(basso_elem_t) , cudaMemcpyDeviceToHost , streams[stream_idx]);

		d_A[stream_idx]->cols 		= BASSO_CU_BASIS_SELECTION_A_VECTOR_PER_STREAM;
		d_Covered[stream_idx]->cols = BASSO_CU_BASIS_SELECTION_A_VECTOR_PER_STREAM;

	}



	for(int i=0;i<device_count;i++)
	{
		cudaSetDevice(i);
		cudaDeviceSynchronize();
	}



	for(int i=0 ; i < BASSO_CU_NUMBER_OF_STREAMS ; i++)
	{
		cudaSetDevice(i % device_count);
		basso_cu_m_free(d_A[i],BASSO_CU_ON_DEVICE);
		basso_cu_m_free(d_Covered[i],BASSO_CU_ON_DEVICE);
	}

	for(int i=0 ; i < device_count ; i++)
	{
		cudaSetDevice(i);
		basso_cu_m_free(d_C_vector[i],BASSO_CU_ON_DEVICE);
		basso_cu_m_free(d_X_vector[i],BASSO_CU_ON_DEVICE);
	}

	cudaFreeHost(d_C_vector);
	cudaFreeHost(d_X_vector);


	return 0;
}

int
cu_update_covered_matrix(const basso_elem_t *left_factor,const basso_elem_t *right_factor,basso_matrix_t *Covered)
{
	basso_matrix_t 	**d_C_vector;
	basso_matrix_t 	**d_X_vector;
	cudaMallocHost((void **) &d_C_vector, device_count * sizeof(basso_matrix_t *));
	cudaMallocHost((void **) &d_X_vector, device_count * sizeof(basso_matrix_t *));
	basso_matrix_t 	*d_Covered [BASSO_CU_NUMBER_OF_STREAMS];

	for(int i=0 ; i < device_count ; i++)
	{
		cudaSetDevice(i);
		basso_cu_m_alloc(Covered->rows,1,BASSO_COL_MAJ,BASSO_CU_ON_DEVICE,&d_C_vector[i]);
		basso_cu_m_alloc(1,Covered->cols,BASSO_ROW_MAJ,BASSO_CU_ON_DEVICE,&d_X_vector[i]);
	}

	for(int i=0 ; i< BASSO_CU_NUMBER_OF_STREAMS ; i++)
	{
		cudaSetDevice(i % device_count);
		basso_cu_m_alloc(Covered->rows,BASSO_CU_BASIS_SELECTION_A_VECTOR_PER_STREAM,BASSO_COL_MAJ,BASSO_CU_ON_DEVICE,&d_Covered[i]);
	}

	for(int i=0 ; i < device_count ; i++)
	{
		cudaSetDevice(i);
		cudaMemcpy(d_C_vector[i]->data,left_factor ,elem_per_vect(Covered->rows) * sizeof(basso_elem_t),cudaMemcpyHostToDevice);
		cudaMemcpy(d_X_vector[i]->data,right_factor,elem_per_vect(Covered->cols) * sizeof(basso_elem_t),cudaMemcpyHostToDevice);
	}

	//Update mask matrix
	uint64_t device_idx = 0;
	uint64_t stream_idx = 0;
	for(int i=0 ; i < Covered->cols ; i += BASSO_CU_BASIS_SELECTION_A_VECTOR_PER_STREAM , stream_idx = (stream_idx + 1) % BASSO_CU_NUMBER_OF_STREAMS)
	{
		device_idx = stream_idx % device_count;
		cudaSetDevice(device_idx);

		//Copy Covered sub-matrix from host to device
		basso_cu_block Covered_copy_size = make_block(Covered->rows,min((uint64_t)BASSO_CU_BASIS_SELECTION_A_VECTOR_PER_STREAM, Covered->cols - i));
		d_Covered[stream_idx]->cols = Covered_copy_size.cols;
		basso_cu_m_block_copy(d_Covered[stream_idx], make_block(0,0), Covered, make_block(0,i),Covered_copy_size,streams[stream_idx],cudaMemcpyHostToDevice);

		dim3 threads_per_block (BASSO_CU_BLOCKSIZE,BASSO_CU_BLOCKSIZE);
		dim3 blocks_per_grid (BASSO_CU_BASIS_SELECTION_A_VECTOR_PER_STREAM / BASSO_CU_BLOCKSIZE);

		basso_cu_update_covered_matrix_kernel <<<blocks_per_grid,threads_per_block,0,streams[stream_idx]>>>
				(d_C_vector[device_idx]->data,d_X_vector[device_idx]->data + i / basso_elem_bits,*d_Covered[stream_idx]);

		CUDA_CHECK_LAST_ERROR();

		basso_cu_m_block_copy(Covered, make_block(0,i), d_Covered[stream_idx], make_block(0,0),Covered_copy_size,streams[stream_idx],cudaMemcpyDeviceToHost);

		d_Covered[stream_idx]->cols = BASSO_CU_BASIS_SELECTION_A_VECTOR_PER_STREAM;
	}

	for(int i=0;i<device_count;i++)
	{
		cudaSetDevice(i);
		cudaDeviceSynchronize();
	}

	for(int i=0 ; i < BASSO_CU_NUMBER_OF_STREAMS ; i++)
	{
		cudaSetDevice(i % device_count);
		basso_cu_m_free(d_Covered[i],BASSO_CU_ON_DEVICE);
	}

	for(int i=0 ; i < device_count ; i++)
	{
		cudaSetDevice(i);
		basso_cu_m_free(d_C_vector[i],BASSO_CU_ON_DEVICE);
		basso_cu_m_free(d_X_vector[i],BASSO_CU_ON_DEVICE);
	}

	cudaFreeHost(d_C_vector);
	cudaFreeHost(d_X_vector);


	return 0;
}




linked_list_t *
get_candidates_in_up_index_lists(const basso_matrix_t *restrict C)
{
	linked_list_t *candidates_in_up_index = (linked_list_t *)malloc(C->rows * sizeof(linked_list_t));
#pragma omp parallel for
	for(uint64_t i=0; i<C->rows;i++)
		init_list(&candidates_in_up_index[i]);

	for(uint64_t i=0 ; i < C->cols ; i++)
	{
#pragma omp parallel for
		for(uint64_t elem_idx = 0 ; elem_idx < C->elem_per_vect ; elem_idx ++)
		{
			basso_elem_t C_i_element = C->data[i * C->elem_per_vect + elem_idx];
			if(C_i_element == 0)
				continue;
			int maxbit = ((elem_idx+1) * basso_elem_bits > C->rows ? C->rows % basso_elem_bits : basso_elem_bits);

			for(int k = 0 ; k < maxbit ; k++)
			{
				if((C_i_element & BASSO_ONE_AT_IND(k)) == 0)
					continue;

				int row = elem_idx * basso_elem_bits + k;
				push_back(&candidates_in_up_index[row],i);
			}
		}
	}

	return candidates_in_up_index;
}

linked_list_t *
get_candidate_overlapped_list(const linked_list_t* candidates_in_up_index,const uint64_t number_of_candidates,const basso_elem_t *candidate,const uint64_t elem_per_vect)
{
	linked_list_t *overlapped_candidates = (linked_list_t *)malloc(sizeof(linked_list_t));
	init_list(overlapped_candidates);


	basso_matrix_t *candidates_bitmask_vect = basso_m_alloc(1,number_of_candidates,BASSO_ROW_MAJ);
	for(uint64_t i=0 ; i < elem_per_vect; i++)
	{
		basso_elem_t element = candidate[i];
		for(uint64_t j=0 ; j < basso_elem_bits ; j++)
		{
			if((BASSO_ONE_AT_IND(j) & element) == 0)
				continue;

			uint64_t up_index = i * basso_elem_bits + j;

			node_t *node = candidates_in_up_index[up_index].head;
			for(uint64_t cnt = 0 ; cnt < candidates_in_up_index[up_index].count ; cnt++, node = node->next)
			{
				uint64_t candidate_index = node->data;
				candidates_bitmask_vect->data[candidate_index/basso_elem_bits] |= BASSO_ONE_AT_IND(candidate_index % basso_elem_bits);
			}

		}

	}


	for(uint64_t i=0 ; i < candidates_bitmask_vect->elem_per_vect; i++)
	{
		basso_elem_t element = candidates_bitmask_vect->data[i];
		for(uint64_t j=0 ; j < basso_elem_bits ; j++)
		{
			if((BASSO_ONE_AT_IND(j) & element) == 0)
				continue;

			uint64_t candidate_index = i * basso_elem_bits + j;
			push_back(overlapped_candidates,candidate_index);
		}
	}

	basso_m_free(candidates_bitmask_vect);

	return overlapped_candidates;

}


int
cu_update_candidates_covered_score(	const basso_matrix_t *A,
									const basso_matrix_t *C,
									const basso_matrix_t *Covered,
									const linked_list_t	 *candidates_in_up_index,
									const uint64_t prev_selected_candidate_index,
									const basso_elem_t *selected_candidate_right_factor,
									uint64_t h_covered_scores[])
{
	basso_matrix_t 	**d_C_vector;
	basso_matrix_t 	*d_A 					[BASSO_CU_NUMBER_OF_STREAMS];
	basso_matrix_t 	*d_C 					[BASSO_CU_NUMBER_OF_STREAMS];
	basso_matrix_t 	*d_Covered				[BASSO_CU_NUMBER_OF_STREAMS];
	long long 	*d_updating_covered_scores	[BASSO_CU_NUMBER_OF_STREAMS];

	for(int i=0 ; i< BASSO_CU_NUMBER_OF_STREAMS ; i++)
	{
		cudaSetDevice(i % device_count);
		basso_cu_m_alloc(A->rows,BASSO_CU_BASIS_SELECTION_A_VECTOR_PER_STREAM,BASSO_COL_MAJ,BASSO_CU_ON_DEVICE,&d_A[i]);
		basso_cu_m_alloc(A->rows,BASSO_CU_BASIS_SELECTION_A_VECTOR_PER_STREAM,BASSO_COL_MAJ,BASSO_CU_ON_DEVICE,&d_Covered[i]);
		basso_cu_m_alloc(C->rows,BASSO_CU_BASIS_SELECTION_C_VECTOR_PER_STREAM,BASSO_COL_MAJ,BASSO_CU_ON_DEVICE,&d_C[i]);
		cudaMalloc((void **) &d_updating_covered_scores[i] , BASSO_CU_BASIS_SELECTION_C_VECTOR_PER_STREAM * sizeof(long long));
	}

	cudaMallocHost((void **) &d_C_vector, device_count * sizeof(basso_matrix_t *));
	for(int i=0 ; i < device_count ; i++)
	{
		cudaSetDevice(i);
		basso_cu_m_alloc(Covered->rows,1,BASSO_COL_MAJ,BASSO_CU_ON_DEVICE,&d_C_vector[i]);
		cudaMemcpy(d_C_vector[i]->data,C->data + prev_selected_candidate_index * C->elem_per_vect, C->elem_per_vect * sizeof(basso_elem_t),cudaMemcpyHostToDevice);
	}

	const uint64_t	r_factor_elem_per_vect = elem_per_vect(A->cols);

	uint64_t chunk_offset = 0;
	uint64_t h_update_score_len = (C->cols > BASSO_CU_NUMBER_OF_STREAMS * BASSO_CU_BASIS_SELECTION_C_VECTOR_PER_STREAM ? C->cols : BASSO_CU_NUMBER_OF_STREAMS * BASSO_CU_BASIS_SELECTION_C_VECTOR_PER_STREAM);
	long long *h_updated_scores,*h_updating_candidates_index;
	cudaMallocHost((void **) &h_updated_scores, h_update_score_len * sizeof(long long));
	cudaMemset(h_updated_scores,0,h_update_score_len * sizeof(long long));
	cudaMallocHost((void **) &h_updating_candidates_index, h_update_score_len * sizeof(long long));
	cudaMemset(h_updating_candidates_index,-1,h_update_score_len * sizeof(long long));

	uint64_t col_len_d_C[BASSO_CU_NUMBER_OF_STREAMS] = {0};


	linked_list_t *overlapped_candidates = get_candidate_overlapped_list(candidates_in_up_index,C->cols,C->data + prev_selected_candidate_index * C->elem_per_vect,C->elem_per_vect);
	node_t *node = overlapped_candidates->head;

	uint64_t candidates_pushed = 0;
	for(uint64_t cnt = 0 ; cnt < overlapped_candidates->count ; cnt++,node = node->next)
	{
		uint64_t col_C = node->data;
		{
			//col_C should be transfered to one stream.
			uint64_t stream_idx 	= candidates_pushed % BASSO_CU_NUMBER_OF_STREAMS;
			uint64_t device_idx 	= stream_idx % device_count;
			cudaSetDevice(device_idx);

			//one column
			basso_cu_m_block_copy(d_C[stream_idx], make_block(0,col_len_d_C[stream_idx]), C, make_block(0,col_C), make_block(C->rows,1), streams[stream_idx], cudaMemcpyHostToDevice);
			h_updating_candidates_index[(chunk_offset + stream_idx) * BASSO_CU_BASIS_SELECTION_C_VECTOR_PER_STREAM + col_len_d_C[stream_idx]] = col_C;

			col_len_d_C[stream_idx]++;
			candidates_pushed++;
		}

		//If all plates of all streams are full or no candidates have been remained
		if(candidates_pushed == BASSO_CU_NUMBER_OF_STREAMS * BASSO_CU_BASIS_SELECTION_C_VECTOR_PER_STREAM ||  (candidates_pushed !=0 && cnt == (overlapped_candidates->count - 1)))
		{
			for(uint64_t j=0;j<BASSO_CU_NUMBER_OF_STREAMS;j++)
			{
				cudaSetDevice(j % device_count);
				cudaMemsetAsync(d_updating_covered_scores[j],0,BASSO_CU_BASIS_SELECTION_C_VECTOR_PER_STREAM * sizeof(long long),streams[j]);
			}

			uint64_t col_A_pushed = 0;

			for(uint64_t i=0 ; i < r_factor_elem_per_vect ; i++)
			{
				basso_elem_t cand_r_fact_elem_i = selected_candidate_right_factor[i];
				int maxbit = ((i+1) * basso_elem_bits > A->cols ? A->cols % basso_elem_bits : basso_elem_bits);
				for(int p=0 ; p < maxbit ; p++)
				{

					if((cand_r_fact_elem_i & BASSO_ONE_AT_IND(p)) != 0)
					{
						uint64_t col_A = i * basso_elem_bits + p;
						//col_A should be transfered to the to all streams
						for(uint64_t j=0 ; j < BASSO_CU_NUMBER_OF_STREAMS ; j++)
						{
							cudaSetDevice(j % device_count);
							// one column
							basso_cu_m_block_copy(d_A[j], make_block(0,col_A_pushed), A, make_block(0,col_A), make_block(A->rows,1), streams[j], cudaMemcpyHostToDevice);
							basso_cu_m_block_copy(d_Covered[j], make_block(0,col_A_pushed), Covered, make_block(0,col_A), make_block(Covered->rows,1), streams[j], cudaMemcpyHostToDevice);
						}

						col_A_pushed ++;
					}

					//If all plates of all streams are full or no columns of A have been remained
					if(col_A_pushed == BASSO_CU_BASIS_SELECTION_A_VECTOR_PER_STREAM || (col_A_pushed !=0 &&  i == (r_factor_elem_per_vect - 1) && p == (maxbit - 1)))
					{
						//Time to run score update scores among all combination of d_A and d_C

						//Calculating the number of threads and blocks of threads it needs.
						dim3 threads_per_block (BASSO_CU_BLOCKSIZE,BASSO_CU_BLOCKSIZE);
						dim3 blocks_per_grid (BASSO_CU_BASIS_SELECTION_C_VECTOR_PER_STREAM / BASSO_CU_BLOCKSIZE);

						for(uint64_t j=0 ; j < BASSO_CU_NUMBER_OF_STREAMS ; j++)
						{
							d_A[j]->cols = col_A_pushed;
							d_C[j]->cols = col_len_d_C[j];

							cudaSetDevice(j % device_count);

							basso_cu_update_covered_scores_kernel <<<blocks_per_grid,threads_per_block,0,streams[j]>>>
								(*d_A[j],*d_C[j],*d_Covered[j],d_C_vector[j % device_count]->data,covering_1s_weight,covering_0s_weight,d_updating_covered_scores[j]);

							CUDA_CHECK_LAST_ERROR();

							d_A[j]->cols = BASSO_CU_BASIS_SELECTION_A_VECTOR_PER_STREAM;
						}

						col_A_pushed = 0;

					}

				}
			}


			for(uint64_t j=0 ; j < BASSO_CU_NUMBER_OF_STREAMS ; j++)
			{
				cudaSetDevice(j % device_count);
				cudaMemcpyAsync(h_updated_scores + (chunk_offset + j) * BASSO_CU_BASIS_SELECTION_C_VECTOR_PER_STREAM, d_updating_covered_scores[j] , col_len_d_C[j] * sizeof(long long) , cudaMemcpyDeviceToHost,streams[j]);
				col_len_d_C[j] = 0;
				d_C[j]->cols = BASSO_CU_BASIS_SELECTION_C_VECTOR_PER_STREAM;
			}

			chunk_offset += BASSO_CU_NUMBER_OF_STREAMS;
			candidates_pushed = 0;
		}
	}

	for(int i=0;i<device_count;i++)
	{
		cudaSetDevice(i);
		cudaDeviceSynchronize();
	}

	for(uint64_t i=0; i < h_update_score_len; i++)
		if(h_updating_candidates_index[i] != -1)
			h_covered_scores[h_updating_candidates_index[i]] += h_updated_scores[i];

	cudaFreeHost(h_updated_scores);
	cudaFreeHost(h_updating_candidates_index);

	for(int i=0 ; i < BASSO_CU_NUMBER_OF_STREAMS ; i++)
	{
		cudaSetDevice(i % device_count);
		basso_cu_m_free(d_A[i],BASSO_CU_ON_DEVICE);
		basso_cu_m_free(d_C[i],BASSO_CU_ON_DEVICE);
		basso_cu_m_free(d_Covered[i],BASSO_CU_ON_DEVICE);
		cudaFree(d_updating_covered_scores[i]);
	}

	for(int i=0 ; i < device_count ; i++)
	{
		cudaSetDevice(i);
		basso_cu_m_free(d_C_vector[i],BASSO_CU_ON_DEVICE);
	}

	cudaFreeHost(d_C_vector);

	return 0;
}

int
cu_rebuild_covered_matrix(	const basso_matrix_t	*restrict B,
							const basso_matrix_t	*restrict X,
							const bool				make_it_transposed,
							basso_matrix_t			*restrict Covered)
{
	if(B == NULL || X == NULL || Covered == NULL)
	{
		errno = EINVAL;
		return 1;
	}

	if(Covered->majority == BASSO_ROW_MAJ)
	{
		BASSO_ERRMSG("NOT IMPLEMENTED FOR ROW MAJOR");
		return 1;
	}

	//Clear Covered matrix
	basso_m_set_all_zeros(Covered);

	basso_elem_t	*restrict left_factor, *restrict right_factor;

	if(make_it_transposed)
	{
		for(uint64_t i = 0 ; i < X->rows ; i++)
		{
			left_factor		= X->data + i * X->elem_per_vect;
			right_factor 	= B->data + i * B->elem_per_vect;
			cu_update_covered_matrix(left_factor,right_factor,Covered);
		}
	}
	else
	{
		for(uint64_t i = 0 ; i < B->cols ; i++)
		{
			left_factor 	= B->data + i * B->elem_per_vect;
			right_factor	= X->data + i * X->elem_per_vect;
			cu_update_covered_matrix(left_factor,right_factor,Covered);
		}
	}

	return 0;
}


int
cu_update_covered_matrix_without_nth_factor(const basso_matrix_t *B,const basso_matrix_t *X,const uint64_t n,const uint64_t num_factors,const bool make_it_transposed,basso_matrix_t *Covered)
{
	const basso_matrix_t *left_mat = (make_it_transposed ? X : B), *right_mat = (make_it_transposed ? B : X);

	basso_matrix_t *d_Covered_vector[BASSO_CU_NUMBER_OF_STREAMS];
	basso_matrix_t *h_Covered_vector[BASSO_CU_NUMBER_OF_STREAMS];

	basso_matrix_t 	*d_left_mat[BASSO_CU_NUMBER_OF_STREAMS];

	for(int s=0 ; s < BASSO_CU_NUMBER_OF_STREAMS ; s++)
	{
		cudaSetDevice(s % device_count);
		basso_cu_m_alloc(Covered->rows,1,BASSO_COL_MAJ,BASSO_CU_ON_DEVICE,&d_Covered_vector[s]);
		basso_cu_m_alloc(Covered->rows,1,BASSO_COL_MAJ,BASSO_CU_ON_HOST,&h_Covered_vector[s]);
		basso_cu_m_alloc(Covered->rows,BASSO_CU_B_VECTOR_PER_STREAM,BASSO_COL_MAJ,BASSO_CU_ON_DEVICE,&d_left_mat[s]);
	}



	basso_elem_t *removing_right_factor = right_mat->data + n * right_mat->elem_per_vect;
	for(uint64_t i=0 ; i < Covered->cols ; i++)
	{
		if((removing_right_factor[i/basso_elem_bits] & BASSO_ONE_AT_IND(i)) == 0)
			continue;

		basso_m_set_nth_col_zero(Covered,i);

		for(int s=0 ; s < BASSO_CU_NUMBER_OF_STREAMS ; s++)
		{
			cudaSetDevice(s % device_count);
			cudaMemsetAsync(d_Covered_vector[s]->data,0,d_Covered_vector[s]->elem_per_vect * sizeof(basso_elem_t),streams[s]);
			memset(h_Covered_vector[s]->data,0,h_Covered_vector[s]->elem_per_vect * sizeof(basso_elem_t));
		}

		uint64_t d_B_len[BASSO_CU_NUMBER_OF_STREAMS] = {0};
		uint64_t stream_idx = 0;
		for(uint64_t j=0 ; j < num_factors ; j++, stream_idx = (stream_idx + 1) % BASSO_CU_NUMBER_OF_STREAMS)
		{
			if(j != n)
			{
				basso_elem_t 	*restrict curr_right_factor = right_mat->data + j * right_mat->elem_per_vect;
				if((curr_right_factor[i/basso_elem_bits] & BASSO_ONE_AT_IND(i)) != 0)
				{
					cudaSetDevice(stream_idx % device_count);
					cudaMemcpyAsync(d_left_mat[stream_idx]->data + d_B_len[stream_idx] * d_left_mat[stream_idx]->elem_per_vect ,
							left_mat->data + j * left_mat->elem_per_vect, left_mat->elem_per_vect * sizeof(basso_elem_t),cudaMemcpyHostToDevice,streams[stream_idx]);
					//basso_cu_m_block_copy(d_left_mat[stream_idx], make_block(0,d_B_len[stream_idx]), left_mat, make_block(0,j), make_block(B->rows,1), streams[stream_idx], cudaMemcpyHostToDevice);
					d_B_len[stream_idx]++;
				}
			}

			for(int s=0 ; s < BASSO_CU_NUMBER_OF_STREAMS ; s++)
			{
				if(d_B_len[s] == BASSO_CU_B_VECTOR_PER_STREAM || (d_B_len[s] !=0 && j== (num_factors-1)))
				{
					int device_idx = s % device_count;
					cudaSetDevice(device_idx);
					d_left_mat[s]->cols = d_B_len[s];

					dim3 threads_per_block (BASSO_CU_BLOCKSIZE,BASSO_CU_BLOCKSIZE);
					dim3 blocks_per_grid (BASSO_CU_B_VECTOR_PER_STREAM / BASSO_CU_BLOCKSIZE,ceil((double)Covered->elem_per_vect / BASSO_CU_BLOCKSIZE));

					basso_cu_update_covered_matrix_without_nth_factor_kernel <<<blocks_per_grid,threads_per_block,0,streams[s]>>>(*d_left_mat[s],*d_Covered_vector[s]);

					d_left_mat[s]->cols = BASSO_CU_B_VECTOR_PER_STREAM;
					d_B_len[s] = 0;
				}
			}
		}

		for(int s=0 ; s < BASSO_CU_NUMBER_OF_STREAMS ; s++)
		{
			cudaSetDevice(s % device_count);
			cudaMemcpyAsync(h_Covered_vector[s]->data, d_Covered_vector[s]->data, d_Covered_vector[s]->elem_per_vect * sizeof(basso_elem_t),cudaMemcpyDeviceToHost, streams[s]);
			cudaStreamSynchronize(streams[s]);

#pragma omp parallel for
			for(uint64_t elem_idx = 0 ; elem_idx < Covered->elem_per_vect ; elem_idx ++)
				Covered->data[i * Covered->elem_per_vect + elem_idx] |= h_Covered_vector[s]->data[elem_idx];
		}

	}


	for(int s=0 ; s < BASSO_CU_NUMBER_OF_STREAMS ; s++)
	{
		cudaSetDevice(s % device_count);
		basso_cu_m_free(d_Covered_vector[s],BASSO_CU_ON_DEVICE);
		basso_cu_m_free(h_Covered_vector[s],BASSO_CU_ON_HOST);
		basso_cu_m_free(d_left_mat[s],BASSO_CU_ON_DEVICE);
	}

	return 0;
}

int
cu_iterative_update(	const basso_matrix_t  	*restrict A,
						basso_matrix_t  		*restrict B,
						basso_matrix_t  		*restrict X)
{
	//First for every factor of B, we update it
	basso_matrix_t *AT;
	basso_cu_m_alloc(A->cols,A->rows,BASSO_COL_MAJ,BASSO_CU_ON_HOST,&AT); // A transpose
	basso_m_transpose(AT,A);
	basso_matrix_t *AT_Covered;
	basso_cu_m_alloc(AT->rows,AT->cols,BASSO_COL_MAJ,BASSO_CU_ON_HOST,&AT_Covered);

	cu_rebuild_covered_matrix(B,X,true,AT_Covered);


	for(uint64_t i=0 ; i < B->cols ; i++)
	{
		cu_update_covered_matrix_without_nth_factor(B,X,i,B->cols,true,AT_Covered);
		//Clean and re-generate B without i_th factor
		basso_m_set_nth_col_zero(B,i);

		basso_elem_t *restrict right_factor = X->data + i * X->elem_per_vect;	//This is the candidate
		basso_elem_t *restrict left_factor 	= B->data + i * B->elem_per_vect;	//This is the factor needs to be updated

		//This will be row covered score
		cu_get_candidate_corresponding_factor(AT,AT_Covered,right_factor,left_factor);

		cu_update_covered_matrix(right_factor,left_factor,AT_Covered);

		//printf("Iterative update: Updating %lluth factor in B. RE = %llu\n",i,basso_m_bnorm(A,B,X));
	}

	basso_cu_m_free(AT,BASSO_CU_ON_HOST);
	basso_cu_m_free(AT_Covered,BASSO_CU_ON_HOST);

	//Update factors of X based on new B
	basso_matrix_t *A_Covered;
	basso_cu_m_alloc(A->rows,A->cols,BASSO_COL_MAJ,BASSO_CU_ON_HOST,&A_Covered);
	cu_rebuild_covered_matrix(B,X,false,A_Covered);

	for(uint64_t i=0 ; i < X->rows ; i++)
	{
		cu_update_covered_matrix_without_nth_factor(B,X,i,X->rows,false,A_Covered);

		//Clean and re-generate B without i_th factor
		basso_m_set_nth_row_zero(X,i);

		basso_elem_t *restrict right_factor = X->data + i * X->elem_per_vect;	//This is the factor needs to be updated
		basso_elem_t *restrict left_factor 	= B->data + i * B->elem_per_vect;	//This is the candidate

		//This will be column covered score
		cu_get_candidate_corresponding_factor(A,A_Covered,left_factor,right_factor);

		cu_update_covered_matrix(left_factor,right_factor,A_Covered);

		//printf("Iterative update: Updating %lluth factor in X. RE = %llu\n",i,basso_m_bnorm(A,B,X));
	}
	basso_cu_m_free(A_Covered,BASSO_CU_ON_HOST);

	return 0;
}

uint64_t
cu_get_best_left_and_right_factors(	const basso_matrix_t  	*restrict A,
									const basso_matrix_t  	*restrict C,
									const linked_list_t		*candidates_in_up_index,
									const uint64_t			factor_index,
									basso_matrix_t  		*restrict Covered,
									uint64_t				h_covered_scores[],
									basso_elem_t			*restrict left_fact,
									basso_elem_t			*restrict right_fact)
{

	uint64_t max_score_candidate_idx = cu_find_max_covered_score_candidate_index(h_covered_scores,C->cols);
	uint64_t max_score = h_covered_scores[max_score_candidate_idx];

	memcpy(left_fact, C->data + max_score_candidate_idx * C->elem_per_vect, C->elem_per_vect * sizeof(basso_elem_t));

	cu_get_candidate_corresponding_factor(A,Covered,left_fact,right_fact);

	cu_update_candidates_covered_score(A,C,Covered,candidates_in_up_index,max_score_candidate_idx,right_fact,h_covered_scores);

	cu_update_covered_matrix(left_fact,right_fact,Covered);

	return max_score;
}


int
basso_cu_select_basis(	const basso_matrix_t  *restrict A,
						const basso_matrix_t  *restrict Association_matrix,
						const basso_option_t  *restrict opt,
						basso_matrix_t *restrict B,
						basso_matrix_t *restrict X)
{
	int status = 0;

	cudaGetDeviceCount(&device_count);

	for(int i=0 ; i < BASSO_CU_NUMBER_OF_STREAMS ; i++)
	{
		cudaSetDevice(i % device_count);
		cudaStreamCreate(&streams[i]);
	}


	basso_matrix_t 	*Covered;
	basso_matrix_t 	*C;
	uint64_t 		*h_covered_scores;

	basso_cu_m_alloc(Association_matrix->rows, Association_matrix->cols, BASSO_COL_MAJ,BASSO_CU_ON_HOST,&C);
	basso_m_copy(C,Association_matrix);

	if(basso_opt_is_ext_candidate_set(opt))
	{
		basso_matrix_t *new_mat;
		basso_cu_m_alloc(C->rows,C->cols + A->cols,BASSO_COL_MAJ,BASSO_CU_ON_HOST,&new_mat);
		basso_m_hor_concat(C,A,new_mat);
		basso_cu_m_free(C,BASSO_CU_ON_HOST);
		C = new_mat;
	}

	if(basso_opt_is_remove_duplicate_candidates_set(opt))
	{
		basso_matrix_t *restrict C_unique = basso_m_remove_duplicate_column(C);
		basso_cu_m_free(C,BASSO_CU_ON_HOST);
		basso_cu_m_alloc(C_unique->rows,C_unique->cols,C_unique->majority,BASSO_CU_ON_HOST,&C);
		basso_m_copy(C,C_unique);
	}



	/*
	 * Start of initializing
	 */
	basso_cu_m_alloc(A->rows,A->cols,BASSO_COL_MAJ,BASSO_CU_ON_HOST,&Covered);


	/*
	 * Distributing the cuda streams among GPU devices. i.e 4 streams and
	 * 2 devices will be distributed such that streams 0 and 2 are assigned to device 0 and streams 1 and 3
	 * are assigned to device 1.
	 */



	if(cudaMallocHost((void **) &h_covered_scores, C->cols * sizeof(uint64_t)) != cudaSuccess)
	{
		errno = EINVAL;
		return 1;
	}



	covering_1s_weight 	= basso_opt_get_weight(opt);
	covering_0s_weight 	= basso_opt_get_zero_cover_weight(opt); // It changes over time
	double modifier 	= basso_opt_get_zcw_modify_step(opt);
	/*
	 * End of initializing
	 */



	linked_list_t *candidates_in_up_index;
	candidates_in_up_index = get_candidates_in_up_index_lists(C);

	uint64_t k = basso_opt_get_rank(opt);

	cu_compute_candidates_covered_score(A,C,Covered,h_covered_scores);


	for(uint64_t l = 0; l < k ; l++)
	{
		basso_elem_t *left_factor 	= B->data + l * B->elem_per_vect;
		basso_elem_t *right_factor 	= X->data + l * X->elem_per_vect;

		cu_get_best_left_and_right_factors(A,C,candidates_in_up_index,l,Covered,h_covered_scores,left_factor,right_factor);

		uint64_t new_weight = covering_0s_weight * modifier;
		covering_0s_weight = (new_weight > 1 ? new_weight : 1);
	}

	basso_cu_m_free(Covered,BASSO_CU_ON_HOST);

	uint64_t iter_update = basso_opt_get_iterative_update(opt);
	for(uint64_t i = 0; i < iter_update;i++)
		cu_iterative_update(A,B,X);


	/*
	 * Start of destruction
	 */
	for (int i = 0; i < BASSO_CU_NUMBER_OF_STREAMS; ++i)
	{
		cudaSetDevice(i % device_count);
		cudaStreamDestroy(streams[i]);
	}


#pragma omp parallel for
	for(uint64_t i=0; i<C->rows;i++)
		free_list(&candidates_in_up_index[i]);

	free(candidates_in_up_index);




	cudaFreeHost(h_covered_scores);

	/*
	 * End of destruction
	 */

	return status;
}



//basso_matrix_t *restrict
//basso_cu_association_matrix(const basso_matrix_t *restrict d_A,
//                         const basso_option_t *restrict opt)
//
//{
//	basso_matrix_t * h_A_meta = (basso_matrix_t *)malloc(sizeof(basso_matrix_t));
//	cudaMemcpy(h_A_meta,d_A,sizeof(basso_matrix_t),cudaMemcpyDeviceToHost);
//
//
//	int neededThreads = ceilf((float)h_A_meta->rows/WarpSize)*WarpSize;
//	int neededBlocks = 1;
//	if(neededThreads > MaxThreadsPerBlock)
//	{
//		neededBlocks = ceilf((float)neededThreads/MaxThreadsPerBlock);
//		neededThreads = MaxThreadsPerBlock;
//	}
//	uint64_t *d_ones_per_row;
//	cudaMalloc((void**)&d_ones_per_row , h_A_meta->rows * sizeof(uint64_t));
//	row_sum<<<neededBlocks,neededThreads>>>(d_A,d_ones_per_row);
//
//
//	basso_matrix_t* d_C = basso_cu_m_alloc(h_A_meta->rows,h_A_meta->rows,BASSO_ROW_MAJ);
//
//	basso_matrix_t * h_C_meta = (basso_matrix_t *)malloc(sizeof(basso_matrix_t));
//	cudaMemcpy(h_C_meta,d_C,sizeof(basso_matrix_t),cudaMemcpyDeviceToHost);
//
//	dim3 threadsPerBlock(h_C_meta->elem_per_vect,h_C_meta->rows);
//	dim3 blocksPerGrid(1, 1);
//	if (threadsPerBlock.x * threadsPerBlock.y > MaxThreadsPerBlock){
//		blocksPerGrid.x = ceilf(float(threadsPerBlock.x)/float(MaxThreadsPerBlockX));
//		blocksPerGrid.y = ceilf(float(threadsPerBlock.y)/float(MaxThreadsPerBlockY));
//		threadsPerBlock.x = MaxThreadsPerBlockX;
//		threadsPerBlock.y = MaxThreadsPerBlockY;
//	}
//
//	//cudaEvent_t start, stop;
//	//cudaEventCreate(&start);
//	//cudaEventCreate(&stop);
//	//cudaEventRecord(start);
//	//printf("%d %d %d %d\n",threadsPerBlock.x,threadsPerBlock.y,blocksPerGrid.x,blocksPerGrid.y);
//	double threshold = basso_opt_get_threshold(opt);
//	association_matrix<<<blocksPerGrid,threadsPerBlock>>>(d_A,d_ones_per_row,threshold,d_C);
//
//	//cudaEventRecord(stop);
//	//cudaEventSynchronize(stop);
//
//	if(cudaDeviceSynchronize()!=cudaSuccess)
//		printf("Not able to sync device\n");
//
//
//	//float milliseconds = 0;
//	//cudaEventElapsedTime(&milliseconds, start, stop);
//	//uint64_t N = A_Meta_OnHost->mRows;
//	//double rw = (N*(N+1)/2 * (A_Meta_OnHost->integerPerRow * 8) + AM_Meta_OnHost->mRows * AM_Meta_OnHost->integerPerRow * 8 );
//
//	//printf("Effective Bandwidth (GB/s): %lf\n",rw/milliseconds/1e6);
//
//	//Fixme: cudafree onesperrow
//	cudaFree(d_ones_per_row);
//	free(h_A_meta);
//	free(h_C_meta);
//
//	return d_C;
//}



//int
//basso_cu_select_basis(const basso_matrix_t  *restrict d_A,
//                   const basso_matrix_t  *restrict d_C,
//                   const basso_option_t  *restrict opt,
//                         basso_matrix_t **restrict d_Bptr,
//                         basso_matrix_t **restrict d_Xptr)
//{
//
//	const uint64_t k      = basso_opt_get_rank(opt);
//	const uint64_t weight = basso_opt_get_weight(opt);
//
//	basso_matrix_t A_info = basso_cu_m_retrieve_info(d_A);
//	basso_matrix_t C_info = basso_cu_m_retrieve_info(d_C);
//
//	basso_matrix_t *restrict d_B = basso_cu_m_alloc(A_info.rows	, k		, BASSO_COL_MAJ);
//	basso_matrix_t *restrict d_X = basso_cu_m_alloc(k	, A_info.cols 	, BASSO_ROW_MAJ);
//
//	basso_matrix_t B_info = basso_cu_m_retrieve_info(d_B);
//	basso_matrix_t X_info = basso_cu_m_retrieve_info(d_X);
//
//	*d_Bptr = d_B;
//	*d_Xptr = d_X;
//
//	basso_matrix_t *d_Covered = basso_cu_m_alloc(A_info.rows, A_info.cols, BASSO_COL_MAJ);
//	basso_matrix_t Covered_info = basso_cu_m_retrieve_info(d_Covered);
//
//
//	/*
//	 * Defining the number of threads we need in total and the number of blocks
//	 * - num_candidate_score_computation_per_task is the number of columns from association matrix which we compute the covered score for
//	 * - threadsPerCandidate is the number of threads are in charge of computing the covered score for each candidate
//	 */
//	//uint64_t num_candidate_score_computation_per_task = C_info.cols;
//
//	uint64_t *d_X_candidate_score;
//	size_t X_candidate_score_size = C_info.cols * sizeof(uint64_t);
//	cudaMalloc((void**)&d_X_candidate_score ,X_candidate_score_size);
//
//
//	uint64_t *d_candidate_cols, *h_candidate_cols;
//	size_t candidate_cols_size = C_info.cols * sizeof(uint64_t);
//	cudaMalloc((void**)&d_candidate_cols ,candidate_cols_size);
//	h_candidate_cols = (uint64_t *)malloc(candidate_cols_size);
//
//
//	//This bitmask(vector or 1-row matrix) shows which candidates have been selected so far
//	basso_matrix_t *selected_candidate = basso_m_alloc(1,C_info.cols,BASSO_ROW_MAJ);
//
//
//	//uint64_t *d_max_col_idx, *d_max_col_score;
//	//cudaMalloc((void**)&d_max_col_idx ,sizeof(uint64_t));
//	//cudaMalloc((void**)&d_max_col_score ,sizeof(uint64_t));
//
//	//size_t val;
//	//cudaThreadSetLimit(cudaLimitMallocHeapSize, C_info.cols * A_info.cols * sizeof(long long));
//	//cudaThreadGetLimit(&val,cudaLimitMallocHeapSize);
//	//printf("cudaLimitMallocHeapSize = %d B\n",val);
//
//	//cudaFuncCache cache_config;
//	//cudaThreadGetCacheConfig(&cache_config);
//	//printf("cache config = %d\n",cache_config);
//
//	int nDevices;
//
//	  cudaGetDeviceCount(&nDevices);
//	  for (int i = 0; i < nDevices; i++) {
//	    cudaDeviceProp prop;
//	    cudaGetDeviceProperties(&prop, i);
//	    printf("Device Number: %d\n", i);
//	    printf("  Device name: %s\n", prop.name);
//	    printf("  Memory Clock Rate (KHz): %d\n",
//	           prop.memoryClockRate);
//	    printf("  Memory Bus Width (bits): %d\n",
//	           prop.memoryBusWidth);
//	    printf("  Peak Memory Bandwidth (GB/s): %f\n\n",
//	           2.0*prop.memoryClockRate*(prop.memoryBusWidth/8)/1.0e6);
//	  }
//
//
//	uint64_t l;
//	for(l=0 ; l<k ; l++)
//	{
//		//cudaMemset(d_max_col_score,0,sizeof(uint64_t));
//
//		uint64_t num_of_candidates = 0;
//		uint64_t i;
//		for(i=0 ; i<C_info.cols ; i++)
//		{
//			// Check whether the i-th column of C has not been selected so far
//			if(!(selected_candidate->data[i / basso_elem_bits] & BASSO_ONE_AT_IND(i)))
//			{
//				//selecting this column as one the candidate to compute the score for it in parallel with other candidate
//				h_candidate_cols [num_of_candidates] = i;
//				num_of_candidates ++;
//			}
//		}
//
//			//If the number of parallel task is full or it is the last column
//			//if(num_of_candidates == num_candidate_score_computation_per_task || i == C_info.cols - 1)
//			//{
//				//Init the scores and partial scores for each column to 0
//		cudaMemcpy(d_candidate_cols,h_candidate_cols,candidate_cols_size,cudaMemcpyHostToDevice);
//
//		cudaMemset(d_X_candidate_score,0,X_candidate_score_size);
//
//		/*
//		{
//			uint64_t threadsPerCandidate = 1024;
//			//It is better to have more than warp size per candidate, then they read the same location and using constant memory is beneficial
//			threadsPerCandidate = max((unsigned long)threadsPerCandidate,(unsigned long)WarpSize);
//			uint64_t threadsPerBlock = num_of_candidates * threadsPerCandidate;
//			threadsPerBlock = ceilf((float)threadsPerBlock/WarpSize)*WarpSize;
//			uint64_t blocksPerGrid = 1;
//
//			if(threadsPerBlock > MaxThreadsPerBlock)
//			{
//				blocksPerGrid = ceilf((float)threadsPerBlock/MaxThreadsPerBlock);
//				threadsPerBlock = MaxThreadsPerBlock;
//			}
//			//uint64_t candidatePerBlock = (uint64_t)ceilf((float)num_of_candidates/blocksPerGrid);
//			uint64_t candidatePerBlock = 1;//ceilf((float)threadsPerBlock/threadsPerCandidate);
//			size_t shared_memory_size = candidatePerBlock * sizeof(uint64_t);
//
//			shared_memory_size += candidatePerBlock * C_info.elem_per_vect * sizeof(uint64_t);
//
//			get_column_covered_score<<<blocksPerGrid,threadsPerBlock,shared_memory_size>>>(d_A,d_C,d_Covered,weight,threadsPerCandidate,d_candidate_cols,num_of_candidates,d_X_candidate_score);
//			if(cudaDeviceSynchronize()!=cudaSuccess)
//				printf("Not able to sync device\n");
//
//		}
//
//		uint64_t *scores1 = (uint64_t *)malloc(num_of_candidates * sizeof(uint64_t));
//		cudaMemcpy(scores1,d_X_candidate_score,num_of_candidates * sizeof(uint64_t),cudaMemcpyDeviceToHost);
//		cudaMemset(d_X_candidate_score,0,candidate_cols_size);
//		*/
//
//
//
//		///*
//
//		/*
//
//		uint64_t threadsPerBlock = 256;
//		uint64_t candidatePerBlock = CANDIDATE_PER_BLOCK;
//		uint64_t threads_per_candidate = threadsPerBlock/candidatePerBlock;
//		uint64_t blocksPerGrid = (uint64_t) ceilf((float)num_of_candidates / candidatePerBlock);
//		size_t shared_mem_size = (candidatePerBlock + candidatePerBlock * C_info.elem_per_vect) *  sizeof(uint64_t);
//
//		get_column_covered_score_coalesced <<< blocksPerGrid , threadsPerBlock , shared_mem_size>>>
//					(d_A,d_C,d_Covered,weight,d_candidate_cols,num_of_candidates,d_X_candidate_score);
//
//		if(cudaDeviceSynchronize()!=cudaSuccess)
//			printf("get_column_covered_score_coalesced: Not able to sync device\n");
//
//		cudaCheckError();
//
//		*/
//
//
//		/*
//		//very very important note:
//		//candiadate per block should be multiple of half-warp-size and less than block dim
//		//at least 16 element per candidate (multiple of 16)
//		int candidatePerBlock = 16;
//		int elem_per_thread = C_info.elem_per_vect;
//
//		dim3 threadsPerBlock(256);
//		dim3 blocksPerGrid(ceilf((float)num_of_candidates / candidatePerBlock));
//		size_t shared_mem_size = (candidatePerBlock + candidatePerBlock * elem_per_thread) *  sizeof(uint64_t);
//
//		get_column_covered_score_coalesced_no_shared_mem_limit <<< blocksPerGrid , threadsPerBlock , shared_mem_size >>>
//				(d_A,d_C,d_Covered,weight,d_candidate_cols,num_of_candidates,d_X_candidate_score,candidatePerBlock,elem_per_thread);
//
//
//		if(cudaDeviceSynchronize()!=cudaSuccess)
//			printf("get_column_covered_score_coalesced_no_shared_mem_limit: Not able to sync device\n");
//
//		cudaCheckError();
//		*/
//
//		///*
//
//
//		/*{
//		 * 	fully functional 10s blockwise for tesla
//		 *
//			//cudaFuncSetCacheConfig(get_column_covered_score_coalesced_no_shared_mem_limit,cudaFuncCachePreferL1);
//
//			dim3 threadsPerBlock(256);
//
//			uint64_t candidate_per_block = 16; // Half warp size
//
//			//fix this number for element_per_vect
//
//			uint64_t element_per_thread = min(ceilf((float)C_info.elem_per_vect),86.0); // better multiply of threadsperblocks
//			//uint64_t column_per_thread = ceilf((float)A_info.cols / (threadsPerBlock.x / candidate_per_block));
//			uint64_t column_per_thread = 10;
//			uint64_t column_per_iteration = column_per_thread * (threadsPerBlock.x / candidate_per_block) ;
//
//			dim3 blocksPerGrid(ceilf((float)C_info.cols / candidate_per_block));
//
//			size_t shared_mem_size = (candidate_per_block * element_per_thread + 4) * sizeof(uint64_t);
//
//			set_constants_for_get_column_covered_score_coalesced_no_shared_mem_limit
//			(candidate_per_block,element_per_thread,column_per_thread,column_per_iteration,weight,A_info.elem_per_vect,num_of_candidates,A_info.cols,C_info.cols,threadsPerBlock.x/candidate_per_block);
//
//			get_column_covered_score_coalesced_no_shared_mem_limit <<< blocksPerGrid , threadsPerBlock , shared_mem_size >>>
//					(A_info.data,C_info.data,Covered_info.data,d_candidate_cols,d_X_candidate_score);
//
//
//			if(cudaDeviceSynchronize()!=cudaSuccess)
//				printf("get_column_covered_score_coalesced_no_shared_mem_limit: Not able to sync device\n");
//
//			cudaCheckError();
//		}*/
//
////		{
////					dim3 threadsPerBlock(256);
////
////					uint64_t candidate_per_block = 16; // Half warp size
////
////					//fix this number for element_per_vect
////
////					uint64_t element_per_thread = min(ceilf((float)C_info.elem_per_vect),87.0); // better multiply of threadsperblocks
////					uint64_t column_per_iteration = threadsPerBlock.x / candidate_per_block;
////					uint64_t thread_per_candidate = threadsPerBlock.x/candidate_per_block;
////
////					dim3 blocksPerGrid(ceilf((float)C_info.cols / candidate_per_block));
////
////					size_t shared_mem_size = (candidate_per_block * element_per_thread ) * sizeof(basso_elem_t)  + (candidate_per_block + 3) * sizeof(uint64_t);
////
////					set_constants_for_get_column_covered_score_coalesced_no_shared_mem_limit
////					(candidate_per_block,element_per_thread,1,column_per_iteration,weight,A_info.elem_per_vect,num_of_candidates,A_info.cols,C_info.cols,thread_per_candidate);
////
////					get_column_covered_score_coalesced_no_shared_mem_limit <<< blocksPerGrid , threadsPerBlock , shared_mem_size >>>
////							(A_info.data,C_info.data,Covered_info.data,d_candidate_cols,d_X_candidate_score);
////
////
////					if(cudaDeviceSynchronize()!=cudaSuccess)
////						printf("get_column_covered_score_coalesced_no_shared_mem_limit: Not able to sync device\n");
////
////					cudaCheckError();
////		}
//
////		{
////			dim3 threadsPerBlock(256);
////
////			uint64_t candidate_per_block = 16; // Half warp size
////
////			//fix this number for element_per_vect
////
////			uint64_t element_per_thread = min(ceilf((float)C_info.elem_per_vect),32.0); // better multiply of threadsperblocks
////			uint64_t column_per_iteration = threadsPerBlock.x / candidate_per_block;
////			uint64_t thread_per_candidate = threadsPerBlock.x/candidate_per_block;
////
////			dim3 blocksPerGrid(ceilf((float)C_info.cols / candidate_per_block));
////
////			size_t shared_mem_size = (candidate_per_block * element_per_thread + 2*(thread_per_candidate * element_per_thread)) * sizeof(basso_elem_t)  + (candidate_per_block + 2) * sizeof(uint64_t);
////
////			set_constants_for_get_column_covered_score_coalesced_no_shared_mem_limit
////			(candidate_per_block,element_per_thread,1,column_per_iteration,weight,A_info.elem_per_vect,num_of_candidates,A_info.cols,C_info.cols,thread_per_candidate);
////
////			get_column_covered_score_coalesced_no_shared_mem_limit <<< blocksPerGrid , threadsPerBlock , shared_mem_size >>>
////					(A_info.data,C_info.data,Covered_info.data,d_candidate_cols,d_X_candidate_score);
////
////
////			if(cudaDeviceSynchronize()!=cudaSuccess)
////				printf("get_column_covered_score_coalesced_no_shared_mem_limit: Not able to sync device\n");
////
////			cudaCheckError();
////		}
//
//		{
//			dim3 threads_per_block (BLOCKSIZE_WIDTH,BLOCKSIZE_WIDTH);
//			dim3 blocks_per_grid (ceilf((float)num_of_candidates / BLOCKSIZE_WIDTH));
//			//size_t shared_mem_size = (3 * (BLOCKSIZE_WIDTH * BLOCKSIZE_HEIGHT)) * sizeof(basso_elem_t) + BLOCKSIZE_WIDTH * sizeof(uint64_t);
//
//			set_constants_for_get_column_covered_score_coalesced_no_shared_mem_limit
//						(16,0,1,16,weight,A_info.elem_per_vect,num_of_candidates,A_info.cols,C_info.cols,16);
//
//			get_column_covered_score_coalesced_no_shared_mem_limit <<< blocks_per_grid , threads_per_block >>>
//								(d_A,d_C,d_Covered,d_candidate_cols,num_of_candidates,d_X_candidate_score);
//
//
//
//			if(cudaDeviceSynchronize()!=cudaSuccess)
//				printf("get_column_covered_score_coalesced_no_shared_mem_limit: Not able to sync device\n");
//
//			cudaCheckError();
//
//		}
//
//		// */
//
//		/*uint64_t *s,*os;
//		s = (uint64_t *) malloc (num_of_candidates *  sizeof(uint64_t));
//		os = (uint64_t *) malloc (num_of_candidates *  sizeof(uint64_t));
//		cudaMemcpy(s,d_X_candidate_score,num_of_candidates *  sizeof(uint64_t),cudaMemcpyDeviceToHost);
//		cudaMemcpy(os,d_X_candidate_over_score,num_of_candidates *  sizeof(uint64_t),cudaMemcpyDeviceToHost);
//
//		for(int i=0;i<num_of_candidates;i++)
//			printf("score = %llu , over_score = %llu \n",s[i],os[i]);
//
//		printf("---------------\n");8/
//		//*/
//
//		///
//		////
//		////Fixme : shared memory size with basso_elem_t
//		////
//
//
//
//		/*
//		uint64_t threadsPerBlock = 256;
//		uint64_t candidatePerBlock = CANDIDATE_PER_BLOCK;
//		uint64_t threads_per_candidate = threadsPerBlock/candidatePerBlock;
//		uint64_t blocksPerGrid = (uint64_t) ceilf((float)num_of_candidates / candidatePerBlock);
//		uint64_t shared_mem_size = (candidatePerBlock + (candidatePerBlock + 2 * threads_per_candidate) * C_info.elem_per_vect) *  sizeof(uint64_t);
//		get_column_covered_score_shared_mem<<< blocksPerGrid , threadsPerBlock , shared_mem_size>>>
//					(d_A,d_C,d_Covered,weight,d_candidate_cols,num_of_candidates,d_X_candidate_score);
//
//		if(cudaDeviceSynchronize()!=cudaSuccess)
//			printf("Not able to sync device\n");
//		*/
//
//		/*
//		uint64_t *scores2 = (uint64_t *)malloc(num_of_candidates * sizeof(uint64_t));
//		cudaMemcpy(scores2,d_X_candidate_score,num_of_candidates * sizeof(uint64_t),cudaMemcpyDeviceToHost);
//
//		if(!Compare_Array(scores1,scores2,num_of_candidates))
//		{
//			printf("Not Equal\n");
//			return 0;
//		}
//		*/
//
//		if(DEBUG){
//			//printf("threadsPerBlock = %llu blocksPerGrid = %llu , candidatePerBlock = %llu \n",threadsPerBlock,blocksPerGrid,candidatePerBlock);
//			uint64_t *scores = (uint64_t *)malloc(num_of_candidates * sizeof(uint64_t));
//			cudaMemcpy(scores,d_X_candidate_score,num_of_candidates * sizeof(uint64_t),cudaMemcpyDeviceToHost);
//			int j;
//			printf("Scores: ");
//			for(j=0;j<num_of_candidates;j++)
//				printf("%llu ,",scores[j]);
//			printf("\n");
//
//			//printf("number of candidate = %d\n",num_of_candidates);
//			//printf("cols candidate: ");
//			//for(j=0;j<num_of_candidates;j++)
//			//	printf("%llu ,",h_candidate_cols[j]);
//			//printf("\n");
//		}
//
//
//		//max_reduction<<<1,1>>>(d_X_candidate_score,num_of_candidates,d_max_col_score,d_max_col_idx);
//
//
//		//if(cudaDeviceSynchronize()!=cudaSuccess)
//			//printf("max_reduction: Not able to sync device\n");
//
//		//}
//
//		uint64_t h_max_col_idx = get_max_score_index(d_X_candidate_score,num_of_candidates);
//		uint64_t selected_candidate_idx =  h_candidate_cols[h_max_col_idx];
//
//		if(DEBUG)
//		{
//			printf("max score = %llu \n",h_max_col_idx);
//		}
//
//		//uint64_t h_max_col_idx;
//		//cudaMemcpy(&h_max_col_idx,d_max_col_idx,sizeof(uint64_t),cudaMemcpyDeviceToHost);
//		//uint64_t selected_candidate_idx =  h_candidate_cols[h_max_col_idx];
//
//		//if(DEBUG)
//		//printf("selected candidate idx = %llu\n",selected_candidate_idx);
//
//		{
//	 	 	/*
//			uint64_t threads_count = 32;
//			threads_count = ceilf((float)threads_count/WarpSize)*WarpSize;
//			uint64_t blocks_count = 1;
//			if(threads_count > MaxThreadsPerBlock)
//			{
//				blocks_count = ceilf((float)threads_count/MaxThreadsPerBlock);
//				threads_count = MaxThreadsPerBlock;
//			}
//
//			uint64_t last_thrd_start_task_idx,last_thrd_end_task_idx;
//			Round_Robin_Tournament(A_info.cols,blocks_count * threads_count,threads_count-1,last_thrd_start_task_idx,last_thrd_end_task_idx);
//
//			size_t shared_memory_elem_count =  ceilf((float)last_thrd_end_task_idx/basso_elem_bits);
//
//			set_right_factor_vect<<<blocks_count,threads_count,shared_memory_elem_count * sizeof(basso_elem_t)>>>(d_A,d_C,d_Covered,weight,selected_candidate_idx,l,d_X);
//
//			if(cudaDeviceSynchronize()!=cudaSuccess)
//				printf("Not able to sync device\n");
//			*/
//		}
//
//		{
//			///*
//			uint64_t threadsPerBlock = 256;
//			uint64_t columnsPerBlock = threadsPerBlock/THREADS_PER_COLUMN;
//			uint64_t blocksPerGrid = (uint64_t) ceilf((float)A_info.cols / columnsPerBlock);
//
//			size_t shared_memory_size = (2 * columnsPerBlock + ceilf((float)columnsPerBlock/basso_elem_bits)) * sizeof(uint64_t);
//			set_right_factor_vect_coalesced<<<blocksPerGrid,threadsPerBlock,shared_memory_size>>>
//					(d_A,d_C,d_Covered,weight,selected_candidate_idx,l,d_X);
//
//			if(cudaDeviceSynchronize()!=cudaSuccess)
//				printf("set_right_factor_vect_coalesced: Not able to sync device\n");
//			//*/
//		}
//
//
//		cudaMemcpy(B_info.data + l * B_info.elem_per_vect , C_info.data + selected_candidate_idx * C_info.elem_per_vect , C_info.elem_per_vect  * sizeof(basso_elem_t),cudaMemcpyDeviceToHost);
//		selected_candidate->data[selected_candidate_idx/basso_elem_bits] |= BASSO_ONE_AT_IND(selected_candidate_idx);
//
//
//		int t = A_info.cols;
//		int b = 1;
//		if(t > MaxThreadsPerBlock)
//		{
//			b = ceilf((float)t/MaxThreadsPerBlock);
//			t = MaxThreadsPerBlock;
//		}
//
//		//Update Covered Matrix
//		update_covered_matrix<<<b,t>>>(d_C,selected_candidate_idx,d_X,l,d_Covered);
//
//		/*if(DEBUG){
//			basso_matrix_t *cover;
//			basso_cu_m_cpy_device_to_host(&cover,d_Covered);
//			printBitwiseMatrix(cover);
//		}*/
//
//
//		if(cudaDeviceSynchronize()!=cudaSuccess)
//			printf("update_covered_matrix: Not able to sync device\n");
//
//		//printf("factor %llu computed\n",l);
//
//
//	}
//
//	if(DEBUG){
//		basso_matrix_t *left;
//		basso_matrix_t *right;
//		basso_cu_m_cpy_device_to_host(&left,d_B);
//		basso_cu_m_cpy_device_to_host(&right,d_X);
//		printBitwiseMatrix(left);
//		printBitwiseMatrix(right);
//	}
//
//	basso_cu_m_free(d_Covered);
//	cudaFree(d_X_candidate_score);
//	cudaFree(d_candidate_cols);
//	//cudaFree(d_max_col_idx);
//	//cudaFree(d_max_col_score);
//	free(h_candidate_cols);
//
//
//	//Fixme: Return value
//
//	return 0;
//}

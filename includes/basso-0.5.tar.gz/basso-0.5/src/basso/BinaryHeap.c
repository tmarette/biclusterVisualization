#ifdef HAVE_CONFIG_H
# include "config.h"
#endif

#include <limits.h>
#include <stdio.h>
#include <stdlib.h>

#include "BinaryHeap.h"
#include "linked_list.h"

/**
 * Allocates memory, initialises and returns a BinaryHeap.
 */
BinaryHeap *restrict
createBinaryHeap(const uint64_t maxNumberOfElements)
{
	BinaryHeap* heap = malloc( sizeof(BinaryHeap) );

	heap->numberOfElements = 0;
	heap->maxNumberOfElements = maxNumberOfElements;
	heap->colToIndex = malloc( sizeof(uint64_t) * maxNumberOfElements );
	heap->elements = malloc( sizeof(HeapElement) * maxNumberOfElements );

	return heap;
}

/**
 * Free()s the memory allocated for the heap.
 */
void
freeBinaryHeap(BinaryHeap *restrict heap)
{
	free(heap->elements);
	free(heap);
}

/**
 * Inserts a column with a given score into the heap.
 * Does not check whether the column already exists;
 * if it already exists, the behaviour of the heap is undefined.
 */
void
insert(BinaryHeap *restrict heap,
	   const uint64_t score,
	   const uint64_t column)
{
	if (heap->numberOfElements >= heap->maxNumberOfElements) {
		fprintf(stderr, "Trying to insert too many elements into binary heap.\n");
		return;
	}

	heap->elements[heap->numberOfElements].score = score;
	heap->elements[heap->numberOfElements].column = column;
	heap->colToIndex[column] = heap->numberOfElements;
	heap->numberOfElements += 1;

	siftUp(heap, heap->numberOfElements-1);
}

/**
 * Removes the biggest element from the heap.
 */
HeapElement
deleteMax(BinaryHeap *restrict heap)
{
	if (heap->numberOfElements == 0) {
		fprintf(stderr, "Trying to delete from empty heap.\n");
		return heap->elements[0];
	}

	HeapElement root = heap->elements[0];

	heap->elements[0] = heap->elements[heap->numberOfElements - 1];
	heap->colToIndex[heap->elements[0].column] = 0;
	siftDown(heap, 0);
	heap->numberOfElements -= 1;

	return root;
}

/**
 * Deletes the given column from the heap.
 */
void
deleteColumn(BinaryHeap *restrict heap,
			 const uint64_t column)
{
	updateKey(heap, UINT64_MAX, column);
	deleteMax(heap);
}

/**
 * Internal function to move an element of the heap upwards.
 */
void
siftUp(BinaryHeap *restrict heap,
	   uint64_t elementIndex)
{
	if (elementIndex == 0) {
		return;
	}

	uint64_t parentIndex = (elementIndex-1)/2;

	if (heapElementIsLarger(heap, elementIndex, parentIndex)) {
		HeapElement tmpParent = heap->elements[parentIndex];
		heap->elements[parentIndex] = heap->elements[elementIndex];
		heap->elements[elementIndex] = tmpParent;

		heap->colToIndex[heap->elements[parentIndex].column] = parentIndex;
		heap->colToIndex[heap->elements[elementIndex].column] = elementIndex;

		siftUp(heap, parentIndex);
	}
}

/**
 * Internal function to move an element of the heap downwards.
 */
void
siftDown(BinaryHeap *restrict heap,
		 uint64_t elementIndex)
{
	if (elementIndex > heap->numberOfElements) {
		fprintf(stderr, "Trying to sift down an element that does not exist.\n");
		return;
	}

	// check whether we have a leaf
	if ( ! (2*(elementIndex+1)-1 < heap->numberOfElements)) {
		return;
	}

	// find smallest child
	uint64_t smallestChild = 2*(elementIndex+1)-1; // first child
	if ( smallestChild+1 < heap->numberOfElements
			&& heapElementIsLarger(heap, smallestChild+1, smallestChild)) {
		// check whether second child exists and is smaller
		smallestChild += 1;
	}

	if (heapElementIsLarger(heap, smallestChild, elementIndex)) {
		HeapElement tmpParent = heap->elements[elementIndex];
		heap->elements[elementIndex] = heap->elements[smallestChild];
		heap->elements[smallestChild] = tmpParent;

		heap->colToIndex[heap->elements[elementIndex].column] = elementIndex;
		heap->colToIndex[heap->elements[smallestChild].column] = smallestChild;

		siftDown(heap, smallestChild);
	}
}

/**
 * Returns true if the score of the element at elementIndex1 is smaller
 * than the on at elementIndex2. If both scores are equal, it returns
 * true if the first element's column number is smaller.
 */
bool
heapElementIsLarger(BinaryHeap *restrict heap,
					const uint64_t elementIndex1,
					const uint64_t elementIndex2)
{
	if (heap->elements[elementIndex1].score != heap->elements[elementIndex2].score) {
		return (heap->elements[elementIndex1].score > heap->elements[elementIndex2].score);
	} else {
		return (heap->elements[elementIndex1].column < heap->elements[elementIndex2].column);
	}
}

/**
 * Updates the score of the given column inside the heap.
 * Notice that this function handles both increaseKey() and
 * decreaseKey() functionalities.
 */
void
updateKey(BinaryHeap *restrict heap,
		  const uint64_t score,
		  const uint64_t column)
{
	uint64_t elementIndex = heap->colToIndex[column];

	if (heap->elements[elementIndex].column != column) {
		fprintf(stderr, "Cannot increase key, element was already deleted.\n");
		return;
	}

	if (heap->elements[elementIndex].score > score) { // decrease key
		heap->elements[elementIndex].score = score;
		siftDown(heap, elementIndex);
	} else { // increase key
		heap->elements[elementIndex].score = score;
		siftUp(heap, elementIndex);
	}
}


void
init_list(linked_list_t *list)
{
	list->tail 	= NULL;
	list->head 	= NULL;
	list->count = 0;
}


void
free_list(linked_list_t *list)
{
	uint64_t count = list->count;
	uint64_t i;
	node_t *next;
	for(i=0;i<count;i++)
	{
		next = list->head->next;
		free(list->head);
		list->head = next;
	}
	init_list(list);
}


void
push_front(linked_list_t *list,const uint64_t value)
{
	node_t *temp = (node_t *)malloc(sizeof(node_t));
	temp->data=value;
	if (list->head == NULL)
	{
		list->tail=temp;
		list->head=temp;
		list->head->next=NULL;
		list->count = 1;
	}
	else
	{
		temp->next=list->head;
		list->head=temp;
		list->count++;
	}

}

void
push_back(linked_list_t *list,const uint64_t value)
{
	node_t *temp = (node_t *)malloc(sizeof(node_t));
	temp->data=value;
	temp->next=NULL;
	if (list->tail == NULL)
	{
		list->tail=temp;
		list->head=temp;
		list->head->next=NULL;
		list->count = 1;
	}
	else
	{
		list->tail->next=temp;
		list->tail = temp;
		list->count++;
	}
}

void
display(const linked_list_t *list)
{
	uint64_t count = list->count;
	if(count !=0)
	{
		printf("Count: %llu , {",count);
		node_t *head = list->head;
		uint64_t i;
		for(i=0;i<count;i++)
		{
			printf("%llu,",head->data);
			head = head->next;
		}
		printf("}\n");
	}
}



/*
 * Note: This function only works properly if and only if the lists are filled with sorted and unique values
 */
linked_list_t* get_lists_union(const linked_list_t *l1,const linked_list_t *l2)
{
	linked_list_t *union_set = (linked_list_t *)malloc(sizeof(linked_list_t));
	init_list(union_set);

	node_t *l1_head = l1->head;
	node_t *l2_head = l2->head;
	while(l1_head != NULL && l2_head != NULL)
	{

		if(l1_head->data < l2_head->data)
		{
			push_back(union_set,l1_head->data);
			l1_head = l1_head->next;
		}
		else if(l1_head->data > l2_head->data)
		{
			push_back(union_set,l2_head->data);
			l2_head = l2_head->next;
		}
		else
		{
			push_back(union_set,l2_head->data);
			l2_head = l2_head->next;
			l1_head = l1_head->next;
		}
	}

	node_t *remained = (l1_head == NULL ? l2_head : l1_head);
	while(remained != NULL)
	{
		push_back(union_set,remained->data);
		remained = remained->next;
	}

    return union_set;
}



/*
 * bassopriv.h
 *
 * This file contains the private header information for libbasso. It should
 * not be included by any application that uses libbasso. It is not part of
 * the public API.
 */

/*
 * Copyright (c) 2016 Pauli Miettinen
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to
 * deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

#ifndef _BASSOPRIV_H
#define _BASSOPRIV_H

#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <stddef.h>
#include <stdio.h> // for BASSO_ERRMSG
#if ( defined(HAVE_CONFIG_H) && defined(HAVE_INTTYPES_H) ) || !defined(HAVE_CONFIG_H)
#  include <inttypes.h>
#endif


/* C++ safety */
#ifdef __cplusplus
#  define BEGIN_C_DECL extern "C" {
#  define END_C_DECL   }
#else
#  define BEGIN_C_DECL
#  define END_C_DECL
#endif

BEGIN_C_DECL

/*
 * DEFAULT SETTINGS
 */
#define B_DEFAULT_RANK      					((uint64_t)1)
#define B_DEFAULT_THRESHOLDS_LIST_LEN 			((uint64_t)0)
#define B_DEFAULT_THRESHOLDS_LIST				((double*)NULL)
#define B_DEFAULT_THRESHOLD 					((double)0.5)
#define B_DEFAULT_WEIGHT    					((uint64_t)1)
#define B_DEFAULT_UPDATE_STEP 					((uint64_t)0)
#define B_DEFAULT_EXT_CANDIDATES 				((int)0)
#define B_DEFAULT_ZERO_COVER_WEIGHT    			((uint64_t)1)
#define B_DEFAULT_ZCW_MODIFY_STEP				((double)1.0)
#define B_DEFAULT_ITERATIVE_UPDATE				((uint64_t)0)
#define B_DEFAULT_PRINT_MID_ERROR 				((int)0)
#define B_DEFAULT_UPDATE_CANDIDATES_STEP		((uint64_t)0)
#define B_DEFAULT_SYMMETRICAL_DECOMPOSE			((int)0)
#define B_DEFAULT_OPTIMIZED_COMPUTATION			((int)1)
#define B_DEFAULT_REMOVE_DUPLICATE_CANDIDATES	((int)1)
#define B_DEFAULT_USE_CANDIDATES_OVERLAP_ALG	((int)1)


#ifndef BASSO_ERRMSG
#  define BASSO_ERRMSG(msg) fprintf(stderr, "%s (%s:%d): %s\n", __func__, __FILE__, __LINE__, (msg))
#endif

#ifndef BASSO_MIN
#  define BASSO_MIN(a, b) (((a) < (b)) ? (a) : (b))
#endif

#ifndef BASSO_MAX
#  define BASSO_MAX(a, b) (((a) > (b)) ? (a) : (b))
#endif

/*
 * _basso_opt_s is the struct for storing the options for the algorithms
 */
struct _basso_opt_s {
  uint64_t rank;
  uint64_t thresholds_list_len;
  double*  thresholds_list;
  uint64_t weight;
  uint64_t update_step;
  int ext_candidates;
  uint64_t zero_cover_weight;
  double zcw_modify_step;
  int print_mid_error;
  uint64_t iterative_update;
  uint64_t update_candidates_step;
  int symmetrical_decompose;
  int optimized_computation;
  int remove_duplicate_candidates;
  int use_candidates_overlap_alg;
};

/*
 * elem_per_vect computes how many elements we need per vector of length n with padding
 */
size_t
elem_per_vect(size_t n);


END_C_DECL

#endif /* _BASSOPRIV_H */

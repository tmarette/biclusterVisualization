/*
 * linked_list.h
 *
 *  Created on: Mar 14, 2017
 *      Author: enadjara
 */

#ifndef LINKED_LIST_H_
#define LINKED_LIST_H_

#ifdef HAVE_CONFIG_H
# include "config.h"
#endif

#include <stdbool.h>
#include <stdint.h>
#include <basso.h>


BEGIN_C_DECL

typedef struct node
{
    uint64_t data;
    struct node *next;
}node_t;

typedef struct linked_list
{
	uint64_t count;
	node_t	*head;
	node_t 	*tail;
}linked_list_t;


void
push_front(linked_list_t *list,const uint64_t value);

void
push_back(linked_list_t *list,const uint64_t value);

void
init_list(linked_list_t *list);

void
free_list(linked_list_t *list);

void
display(const linked_list_t *list);

/*
 * Note: This function only works properly if and only if the lists are filled with sorted and unique values
 */
linked_list_t* get_lists_union(const linked_list_t *l1,const linked_list_t *l2);

END_C_DECL

#endif /* LINKED_LIST_H_ */

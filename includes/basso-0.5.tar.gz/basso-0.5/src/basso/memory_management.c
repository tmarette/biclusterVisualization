/*
 * memory_management.c
 *
 * This file contains the allocation and de-allocation functions for bitwise
 * matrices. These are declared in bassodata.h.
 */

/*
 * Copyright (c) 2016 Pauli Miettinen
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to
 * deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

#ifdef HAVE_CONFIG_H
# include "config.h"
#endif

#include <stdlib.h> // for malloc, calloc, and free
#include <errno.h>  // for errno

#include "bassodata.h"
#include "bassopriv.h"


size_t
elem_per_vect(size_t n)
{
  size_t x = n/basso_elem_bits;
  if (n % basso_elem_bits > 0) x += 1; // Add one element to store the left-over
  return x;
}

basso_matrix_t *
basso_m_alloc(const size_t rows, const size_t cols, const basso_majority_t majority)
{
  basso_matrix_t *A = malloc(sizeof(basso_matrix_t));
  if (A == NULL) goto fail;
  
  A->rows     = rows;
  A->cols     = cols;
  A->majority = majority;
  
  if (majority == BASSO_ROW_MAJ) {
    A->elem_per_vect = elem_per_vect(cols);
    A->data = calloc(rows*A->elem_per_vect, sizeof(basso_elem_t));
  } else {
    A->elem_per_vect = elem_per_vect(rows);
    A->data = calloc(cols*A->elem_per_vect, sizeof(basso_elem_t));
  }
  
  if (A->data == NULL) goto fail;
  
  return A;
  
fail:
  if (A != NULL) free(A->data);
  free(A);
  return NULL;
}

void
basso_m_free(basso_matrix_t *A)
{
  if (A != NULL) free(A->data);
  free(A);
}

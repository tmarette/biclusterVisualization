#ifndef _BASSO_BINARYHEAP_H
#define _BASSO_BINARYHEAP_H

#ifdef HAVE_CONFIG_H
# include "config.h"
#endif


#include <stdbool.h>
#include <stdint.h>
#include <basso.h>

BEGIN_C_DECL

/**
 * Here are some general instructions on the implementation
 * and the usage of the binary heap. For comments on the usage of the
 * functions, please see the documentation inside the implementation
 * file.
 *
 * Implements a binary max-priority heap. The heap allocates its
 * memory statically, i.e. after initialisation with a certain number
 * elements, it will never resize.
 * Besides the score, the elements of the heap store a column. All
 * columns must have numbers between 0 and maxNumberOfElements.
 * No column can occur twice.
 * To get access to the element storing a certain column, use the
 * colToIndex array, that can be used like a dictionary or map.
 */

typedef struct {
	uint64_t score; // we order after this entry
	uint64_t column;
} HeapElement;

typedef struct {
	uint64_t numberOfElements;
	uint64_t maxNumberOfElements;
	uint64_t *colToIndex;
	HeapElement* elements;
} BinaryHeap;

// public methods
BinaryHeap *restrict
createBinaryHeap(const uint64_t maxNumberOfElements);

void
freeBinaryHeap(BinaryHeap *restrict heap);

void
insert(BinaryHeap *restrict heap,
       const uint64_t score,
       const uint64_t columnNumber);

HeapElement
deleteMax(BinaryHeap *restrict heap);

void
updateKey(BinaryHeap *restrict heap, const uint64_t score, const uint64_t column);

void
deleteColumn(BinaryHeap *restrict heap, const uint64_t column);

// internal methods to update the heap
void
siftUp(BinaryHeap *restrict heap, uint64_t elementIndex);

void
siftDown(BinaryHeap *restrict heap, uint64_t elementIndex);

bool
heapElementIsLarger(BinaryHeap *restrict heap,
		    const uint64_t elementIndex1,
		    const uint64_t elementIndex2);

END_C_DECL

#endif


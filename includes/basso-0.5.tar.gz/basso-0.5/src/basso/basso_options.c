/*
 * basso_options.c
 *
 * This file contains the implementations of the initializer, getters, 
 * and setters for the options structure used in the basso algorithms.
 */

/*
 * Copyright (c) 2016 Pauli Miettinen
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to 
 * deal in the Software without restriction, including without limitation the 
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or 
 * sell copies of the Software, and to permit persons to whom the Software is 
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in 
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR 
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, 
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER 
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING 
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER 
 * DEALINGS IN THE SOFTWARE.
 */

#ifdef HAVE_CONFIG_H
# include "config.h"
#endif

#include <errno.h>
#include <stdlib.h> // for malloc & free

#include "bassodata.h"
#include "basso.h"
#include "bassopriv.h"


basso_option_t *
basso_opt_init()
{
  basso_option_t *opt = malloc(sizeof(basso_option_t));
  if (opt == NULL) return NULL;
  /* Set the default values */
  opt->rank      				= B_DEFAULT_RANK;
  opt->thresholds_list_len 		= B_DEFAULT_THRESHOLDS_LIST_LEN;
  opt->thresholds_list			= B_DEFAULT_THRESHOLDS_LIST;
  opt->weight    				= B_DEFAULT_WEIGHT;
  opt->update_step 				= B_DEFAULT_UPDATE_STEP;
  opt->zero_cover_weight		= B_DEFAULT_ZERO_COVER_WEIGHT;
  opt->zcw_modify_step			= B_DEFAULT_ZCW_MODIFY_STEP;
  opt->iterative_update 		= B_DEFAULT_ITERATIVE_UPDATE;
  opt->print_mid_error 			= B_DEFAULT_PRINT_MID_ERROR;
  opt->update_candidates_step	= B_DEFAULT_UPDATE_CANDIDATES_STEP;
  opt->optimized_computation	= B_DEFAULT_OPTIMIZED_COMPUTATION;
  opt->remove_duplicate_candidates = B_DEFAULT_REMOVE_DUPLICATE_CANDIDATES;
  opt->use_candidates_overlap_alg = B_DEFAULT_USE_CANDIDATES_OVERLAP_ALG;
  
  return opt;
}

void
basso_opt_free(basso_option_t *opt)
{
	free(opt->thresholds_list);
	free(opt);
}

int
basso_opt_set_rank(basso_option_t *opt, const uint64_t rank)
{
  if (opt == NULL || rank == 0) {
    errno = EINVAL;
    return 1;
  }
  opt->rank = rank;
  return 0;
}


int
basso_opt_set_thresholds_list(basso_option_t *opt, const double* thresholds, const uint64_t thresholds_len)
{
	if (opt == NULL || thresholds == NULL || thresholds_len <= 0) {
		errno = EINVAL;
		return 1;
	}

	for(uint64_t i = 0 ; i < thresholds_len ; i++)
		if(thresholds[i] < 0 || thresholds [i] > 1)
		{
			errno = EINVAL;
			return 1;
		}

	opt->thresholds_list_len 	= thresholds_len;
	opt->thresholds_list 		= (double *) malloc( thresholds_len * sizeof(double));
	if(opt->thresholds_list == NULL)
	{
		errno = EINVAL;
		return 1;
	}

	for(uint64_t i = 0 ; i < thresholds_len ; i++)
		opt->thresholds_list[i] = thresholds[i];

	return 0;
}

int
basso_opt_set_threshold(basso_option_t *opt, const double threshold)
{
	if (opt == NULL || threshold < 0 || threshold > 1) {
		errno = EINVAL;
		return 1;
	}
	double thresholds[1];
	thresholds[0] = threshold;
	return basso_opt_set_thresholds_list(opt,thresholds,1);
}

int
basso_opt_set_weight(basso_option_t *opt, const uint64_t weight)
{
  if (opt == NULL) {
    errno = EINVAL;
    return 1;
  }
  opt->weight = weight;
  return 0;
}

int
basso_opt_set_update_step(basso_option_t *opt, const uint64_t update_step)
{
  if (opt == NULL) {
    errno = EINVAL;
    return 1;
  }
  opt->update_step = update_step;
  return 0;
}

int
basso_opt_set_ext_candidates(basso_option_t *opt, const int ext_candidates)
{
	if (opt == NULL) {
		errno = EINVAL;
		return 1;
	}
	opt->ext_candidates = ext_candidates;
	return 0;
}

int
basso_opt_set_remove_duplicate_candidates(basso_option_t *opt, const int remove_duplicate_candidates)
{
	if (opt == NULL) {
		errno = EINVAL;
		return 1;
	}
	opt->remove_duplicate_candidates = remove_duplicate_candidates;
	return 0;
}

int
basso_opt_set_use_candidates_overlap_alg(basso_option_t *opt, const int use_candidates_overlap_alg)
{
	if (opt == NULL) {
		errno = EINVAL;
		return 1;
	}
	opt->use_candidates_overlap_alg = use_candidates_overlap_alg;
	return 0;
}


int
basso_opt_set_optimized_computation(basso_option_t *opt, const int optimized_computation)
{
	if (opt == NULL) {
		errno = EINVAL;
		return 1;
	}
	opt->optimized_computation = optimized_computation;
	return 0;
}

int
basso_opt_set_iterative_update(basso_option_t *opt, const uint64_t iterative_update)
{
	if (opt == NULL) {
		errno = EINVAL;
		return 1;
	}
	opt->iterative_update = iterative_update;
	return 0;
}


int
basso_opt_set_print_mid_error(basso_option_t *opt, const int print_mid_error)
{
	if (opt == NULL) {
		errno = EINVAL;
		return 1;
	}
	opt->print_mid_error = print_mid_error;
	return 0;
}

int
basso_opt_set_zero_cover_weight(basso_option_t *opt, const uint64_t zero_cover_weight)
{
  if (opt == NULL) {
    errno = EINVAL;
    return 1;
  }
  opt->zero_cover_weight = zero_cover_weight;
  return 0;
}

int
basso_opt_set_zcw_modify_step(basso_option_t *opt, const double zcw_modify_step)
{
	if (opt == NULL) {
		errno = EINVAL;
		return 1;
	}
	opt->zcw_modify_step = zcw_modify_step;
	return 0;
}

int
basso_opt_set_update_candidates_step(basso_option_t *opt, const uint64_t update_candidates_step)
{
	if (opt == NULL) {
		errno = EINVAL;
		return 1;
	}
	opt->update_candidates_step = update_candidates_step;
	return 0;
}

int
basso_opt_set_symmetrical_decompose(basso_option_t *opt, const int symmetrical_decompose)
{
	if (opt == NULL) {
		errno = EINVAL;
		return 1;
	}
	opt->symmetrical_decompose = symmetrical_decompose;
	return 0;
}

uint64_t
basso_opt_get_rank(const basso_option_t *opt)
{
  if (opt == NULL) {
    errno = EINVAL;
    return 0;
  }
  return opt->rank;
}

double
basso_opt_get_threshold(const basso_option_t *opt)
{
  if (opt == NULL) {
    errno = EINVAL;
    return -1.0;
  }
  return opt->thresholds_list[0];
}

uint64_t
basso_opt_get_threshold_list_len(const basso_option_t *opt)
{
	if (opt == NULL) {
		errno = EINVAL;
		return 0;
	}
	return opt->thresholds_list_len;
}

double *
basso_opt_get_threshold_list(const basso_option_t *opt)
{
	if (opt == NULL) {
		errno = EINVAL;
		return NULL;
	}
	return opt->thresholds_list;
}

uint64_t
basso_opt_get_weight(const basso_option_t *opt)
{
  if (opt == NULL) {
    errno = EINVAL;
    return ULLONG_MAX;
  }
  return opt->weight;
}

uint64_t
basso_opt_get_update_step(const basso_option_t *opt)
{
  if (opt == NULL) {
    errno = EINVAL;
    return ULLONG_MAX;
  }
  return opt->update_step;
}

int
basso_opt_is_ext_candidate_set(const basso_option_t *opt)
{
	if (opt == NULL) {
		errno = EINVAL;
		return -1;
	}
	return opt->ext_candidates;
}

int
basso_opt_is_optimized_computation_set(const basso_option_t *opt)
{
	if (opt == NULL) {
		errno = EINVAL;
		return -1;
	}
	return opt->optimized_computation;
}

int
basso_opt_is_remove_duplicate_candidates_set(const basso_option_t *opt)
{
	if (opt == NULL) {
		errno = EINVAL;
		return -1;
	}
	return opt->remove_duplicate_candidates;
}

int
basso_opt_is_use_candidates_overlap_alg_set(const basso_option_t *opt)
{
	if (opt == NULL) {
		errno = EINVAL;
		return -1;
	}
	return opt->use_candidates_overlap_alg;
}

uint64_t
basso_opt_get_zero_cover_weight(const basso_option_t *opt)
{
  if (opt == NULL) {
    errno = EINVAL;
    return ULLONG_MAX;
  }
  return opt->zero_cover_weight;
}

double
basso_opt_get_zcw_modify_step(const basso_option_t *opt)
{
	if (opt == NULL) {
		errno = EINVAL;
		return -1;
	}
	return opt->zcw_modify_step;
}

uint64_t
basso_opt_get_iterative_update(const basso_option_t *opt)
{
	if (opt == NULL) {
		errno = EINVAL;
		return ULLONG_MAX;
	}
	return opt->iterative_update;
}



int
basso_opt_is_print_mid_error_set(const basso_option_t *opt)
{
	if (opt == NULL) {
		errno = EINVAL;
		return -1;
	}
	return opt->print_mid_error;
}

uint64_t
basso_opt_get_update_candidates_step(const basso_option_t *opt)
{
	if (opt == NULL) {
		errno = EINVAL;
		return ULLONG_MAX;
	}
	return opt->update_candidates_step;
}

int
basso_opt_is_symmetrical_decompose_set(const basso_option_t *opt)
{
	if (opt == NULL) {
		errno = EINVAL;
		return -1;
	}
	return opt->symmetrical_decompose;
}


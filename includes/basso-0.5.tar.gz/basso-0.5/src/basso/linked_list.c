///*
// * linked_list.c
// *
// *  Created on: Aug 1, 2017
// *      Author: enadjara
// */
//
//#include "linked_list.h"
//
//void
//init_list(linked_list_t *list)
//{
//	list->tail 	= NULL;
//	list->head 	= NULL;
//	list->count = 0;
//}
//
//
//void
//free_list(linked_list_t *list)
//{
//	uint64_t count = list->count;
//	uint64_t i;
//	node_t *next;
//	for(i=0;i<count;i++)
//	{
//		next = list->head->next;
//		free(list->head);
//		list->head = next;
//	}
//	init_list(list);
//}
//
//
//void
//push_front(linked_list_t *list,const uint64_t value)
//{
//	node_t *temp = (node_t *)malloc(sizeof(node_t));
//	temp->data=value;
//	if (list->head == NULL)
//	{
//		list->tail=temp;
//		list->head=temp;
//		list->head->next=NULL;
//		list->count = 1;
//	}
//	else
//	{
//		temp->next=list->head;
//		list->head=temp;
//		list->count++;
//	}
//
//}
//
//void
//push_back(linked_list_t *list,const uint64_t value)
//{
//	node_t *temp = (node_t *)malloc(sizeof(node_t));
//	temp->data=value;
//	temp->next=NULL;
//	if (list->tail == NULL)
//	{
//		list->tail=temp;
//		list->head=temp;
//		list->head->next=NULL;
//		list->count = 1;
//	}
//	else
//	{
//		list->tail->next=temp;
//		list->tail = temp;
//		list->count++;
//	}
//}
//
//void
//display(const linked_list_t *list)
//{
//	uint64_t count = list->count;
//	if(count !=0)
//	{
//		printf("Count: %llu , {",count);
//		node_t *head = list->head;
//		uint64_t i;
//		for(i=0;i<count;i++)
//		{
//			printf("%llu,",head->data);
//			head = head->next;
//		}
//		printf("}\n");
//	}
//}
//
//
//
///*
// * Note: This function only works properly if and only if the lists are filled with sorted and unique values
// */
//linked_list_t* get_lists_union(const linked_list_t *l1,const linked_list_t *l2)
//{
//	linked_list_t *union_set = (linked_list_t *)malloc(sizeof(linked_list_t));
//	init_list(union_set);
//
//	node_t *l1_head = l1->head;
//	node_t *l2_head = l2->head;
//	while(l1_head != NULL && l2_head != NULL)
//	{
//
//		if(l1_head->data < l2_head->data)
//		{
//			push_back(union_set,l1_head->data);
//			l1_head = l1_head->next;
//		}
//		else if(l1_head->data > l2_head->data)
//		{
//			push_back(union_set,l2_head->data);
//			l2_head = l2_head->next;
//		}
//		else
//		{
//			push_back(union_set,l2_head->data);
//			l2_head = l2_head->next;
//			l1_head = l1_head->next;
//		}
//	}
//
//	node_t *remained = (l1_head == NULL ? l2_head : l1_head);
//	while(remained != NULL)
//	{
//		push_back(union_set,remained->data);
//		remained = remained->next;
//	}
//
//    return union_set;
//}

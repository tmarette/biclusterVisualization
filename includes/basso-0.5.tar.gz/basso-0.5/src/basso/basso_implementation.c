/*
 * basso_implementation.c
 *
 * This file contains the algorithms for Boolean matrix factorization 
 * implemented in libbasso. These functions are declared in basso.h.
 */

/*
 * Copyright (c) 2016 Pauli Miettinen and Stefan Neumann
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to
 * deal in the Software without restriction, including without limitation the
 * rights to use, copy, modify, merge, publish, distribute, sublicense, and/or
 * sell copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
 * FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
 * DEALINGS IN THE SOFTWARE.
 */

/*
 * This file cannot be named basso.c, since otherwise
 * problems with the mex-file for basso will occur.
 */

#ifdef HAVE_CONFIG_H
# include "config.h"
#endif

#include <errno.h>
#include <string.h> // for memset & memcpy
#include <stdlib.h> // for malloc & free
#include <stdbool.h>

#include "bassodata.h"
#include "basso.h"
#include "bassopriv.h"

/* FIXME: We should probably not use the binary heap */
#include "linked_list.h"
#include "BinaryHeap.h"
#include <time.h>

#ifdef _OPENMP
#  include <omp.h>
#endif

/*
 * PUBLIC VARIABLES
 */

/* 
 * A signal handler can set this to 1 to stop the loop in basso_select_basis
 */
volatile sig_atomic_t basso_stop_select_basis = 0;

uint64_t
get_max_index(const uint64_t arr[],const uint64_t len)
{
	uint64_t max_index = 0;
	for(uint64_t i=0 ; i < len ; i++)
	{
		if(arr[i] > arr[max_index])
			max_index = i;
	}
	return max_index;
}


/*
 * ALGORITHMS
 */

int
basso(const basso_matrix_t  *restrict A,
      const basso_option_t  *restrict opt,
      basso_matrix_t **restrict B,
      basso_matrix_t **restrict C)
{
  if (A == NULL) {
    BASSO_ERRMSG("Input matrix cannot be NULL");
    errno = EINVAL;
    return 1;
  }
  if (opt == NULL) {
    BASSO_ERRMSG("Options cannot be NULL");
    errno = EINVAL;
    return 1;
  }
  
  const uint64_t rank = basso_opt_get_rank(opt);
  
  if (rank >= BASSO_MIN(A->rows, A->cols)) {
    /* Trivial decomposition, do nothing  */
    if (A->rows < A->cols) {
      *B = basso_m_eye(A->rows, BASSO_COL_MAJ);
      if (A->majority == BASSO_ROW_MAJ) *C = basso_m_duplicate(A);
      else *C = basso_m_swap_duplicate(A);
    } else {
      if (A->majority == BASSO_COL_MAJ) *B = basso_m_duplicate(A);
      else *B = basso_m_swap_duplicate(A);
      *C = basso_m_eye(A->cols, BASSO_ROW_MAJ);
    }
    if (*B == NULL || *C == NULL) goto fail;
    else return 0;
  }
  
  /* Compute the association matrix, and make it compute the row sums */
	basso_matrix_t *assoMat_row = basso_association_matrix(A, NULL, opt);
  
  if (assoMat_row == NULL) goto fail;

  /* FIXME: Use basso_m_swap() instead */
  basso_matrix_t *assoMat_col = basso_m_swap_duplicate(assoMat_row);
	basso_m_free(assoMat_row);

  if (assoMat_col == NULL) goto fail;
  
	basso_select_basis(A, assoMat_col, opt, B, C);
	basso_m_free(assoMat_col);

  if (*B == NULL || *C == NULL) goto fail;
  
	return 0;
  
fail:
  basso_m_free(*B);
  basso_m_free(*C);
  *B = NULL;
  *C = NULL;
  return 1;
}

//Different association matrices will be built with input thresholds and concatenated into a single association matrix
//If the ext-candidate flag is set, the columns of original matrix will be also concatenated.
basso_matrix_t *restrict
basso_association_matrix(const basso_matrix_t *restrict matrix_A,
                         const uint64_t *restrict orig_ones_per_row,
                         const basso_option_t *restrict orig_opt)
{

	basso_matrix_t *C = NULL;

	if (matrix_A == NULL || orig_opt == NULL) {
		errno = EINVAL;
		return NULL;
	}

	/* If orig_ones_per_row == NULL, we need to compute it, but then it can't be const.
	* Compute to separate non-const pointer and copy the correct pointer (orig or tmp)
	* to const working pointer. This way we can free if we had to allocate.
	*/
	int ones_per_row_allocated = 0;
	uint64_t *tmp_ones_per_row;
	if (orig_ones_per_row == NULL)
	{
		tmp_ones_per_row = malloc(matrix_A->rows*sizeof(uint64_t));
		if (tmp_ones_per_row == NULL) goto fail;
		ones_per_row_allocated = 1;
		if (basso_m_row_sums(matrix_A, tmp_ones_per_row)) goto fail;
	}

	const uint64_t *ones_per_row = (ones_per_row_allocated)?tmp_ones_per_row:orig_ones_per_row;

	const double* thresholds = basso_opt_get_threshold_list(orig_opt);
	const uint64_t thresholds_len = basso_opt_get_threshold_list_len(orig_opt);

	const uint64_t matrices_number = thresholds_len;
	basso_matrix_t **asso_matrices = (basso_matrix_t **) malloc(matrices_number * sizeof(basso_matrix_t));

	for(uint64_t i = 0 ; i < matrices_number ; i++)
	{
		asso_matrices[i] = basso_m_alloc(matrix_A->rows, matrix_A->rows, BASSO_COL_MAJ);
		if (asso_matrices[i] == NULL) goto fail;
	}

	const uint64_t epv_A = matrix_A->elem_per_vect;
	const uint64_t asso_epv = asso_matrices[0]->elem_per_vect;
	const uint64_t asso_rows = asso_matrices[0]->rows;
	const uint64_t asso_cols = asso_matrices[0]->cols;

	/* FIXME: improve cache locality: parallelization over A, not C? */

	// we do the computations in chunks of 64x64 blocks of matrix C
	// in order to avoid multiple processors writing to the same bits of C
	for (uint64_t chunkRow = 0; chunkRow < asso_epv; ++chunkRow) {
#pragma omp parallel for
		for (uint64_t chunkCol = 0; chunkCol < asso_epv; ++chunkCol){
			// now compute the actual 64x64 block of C
			for (uint64_t i = chunkRow * basso_elem_bits ; i < (chunkRow+1) * basso_elem_bits && i < asso_rows; ++i) {
				// due to the symmetry of C, we only have to compute for j above the diagonal
				uint64_t startingJ = (i > chunkCol * basso_elem_bits) ? i : chunkCol * basso_elem_bits;

				for (uint64_t j=startingJ; j < (chunkCol+1)*basso_elem_bits && j < asso_cols; ++j){
					// compute <A_i, A_j>
					uint64_t dotProd_ij = 0;
					for (uint64_t k=0; k<epv_A; ++k)
						dotProd_ij += BASSO_POPCNT( matrix_A->data[i * epv_A + k] & matrix_A->data[j * epv_A + k] );


					for(uint64_t t = 0 ; t < matrices_number ; t++){
						// set C[j,i] = C(i=>j) = (<A_i, A_j> / <A_i, A_i> >= threshold)
						double threshold = thresholds[t];
						if ( dotProd_ij >= threshold * ones_per_row[i])
							basso_m_set_val(asso_matrices[t],j,i,1);


						// set C[i,j] = C(j=>i) = (<A_i, A_j> / <A_j, A_j> >= threshold)
						// Remark: See remark above.
						if ( dotProd_ij >= threshold * ones_per_row[j])
							basso_m_set_val(asso_matrices[t],i,j,1);
					}
				}
			}
		}
	}

	//Concatenating all columns of association matrices into one unit association matrix C
	const uint64_t C_rows = matrix_A->rows;
	const uint64_t C_cols = matrices_number * asso_cols;
	C = basso_m_alloc(matrix_A->rows,C_cols,BASSO_COL_MAJ);

	for(uint64_t i = 0 ; i < matrices_number ; i ++)
		memcpy(C->data + i * asso_cols * asso_epv, asso_matrices[i]->data, asso_cols * asso_epv * sizeof(basso_elem_t));

	//Succesful execution
	goto cleanup;
  
fail:
	if (ones_per_row_allocated) free(tmp_ones_per_row);
	basso_m_free(C);
	return NULL;

cleanup:
	for(uint64_t i = 0 ; i < matrices_number ; i++)
		basso_m_free(asso_matrices[i]);

	free(asso_matrices);

	return C;
}


uint64_t covering_1s_weight;
uint64_t covering_0s_weight;


inline
long long
get_element_covered_score(	const basso_elem_t 	elem_A,
							const basso_elem_t 	elem_Covered,
							const basso_elem_t 	elem_candidate)
{
	uint8_t covered_1s = 0;
	uint8_t covered_0s = 0;

	// find the newly covered 1s
	basso_elem_t newlyCovered;
	newlyCovered  = ~(elem_Covered);
	newlyCovered &=   elem_A;
	newlyCovered &=   elem_candidate;

	// find the newly covered 0s
	basso_elem_t newlyOvercovered;
	newlyOvercovered  = elem_A;
	newlyOvercovered |= elem_Covered;
	newlyOvercovered  = ~newlyOvercovered;
	newlyOvercovered &= elem_candidate;

	covered_1s 	+= BASSO_POPCNT(newlyCovered);
	covered_0s	+= BASSO_POPCNT(newlyOvercovered);

	return (covering_1s_weight * covered_1s - covering_0s_weight * covered_0s);
}

inline
long long
get_vector_covered_score(	const basso_elem_t 	*restrict 	vect_A,
							const basso_elem_t 	*restrict 	vect_Covered,
							const basso_elem_t 	*restrict 	vect_candidate,
							const uint64_t 					elem_per_vect)
{
	uint64_t covered_1s = 0;
	uint64_t covered_0s = 0;

	for (uint64_t i=0; i < elem_per_vect; ++i)
	{
		// find the newly covered 1s
		basso_elem_t newlyCovered;
		newlyCovered  = ~(vect_Covered[i]);
		newlyCovered &=   vect_A[i];
		newlyCovered &=   vect_candidate[i];

		// find the newly covered 0s
		basso_elem_t newlyOvercovered;
		newlyOvercovered  = vect_A[i];
		newlyOvercovered |= vect_Covered[i];
		newlyOvercovered  = ~newlyOvercovered;
		newlyOvercovered &= vect_candidate[i];

		covered_1s 	+= BASSO_POPCNT(newlyCovered);
		covered_0s	+= BASSO_POPCNT(newlyOvercovered);
	}

	return (covering_1s_weight * covered_1s - covering_0s_weight * covered_0s);
}

int
compute_candidates_covered_score(	const 	basso_matrix_t  *restrict 	A,
									const 	basso_matrix_t  *restrict 	C,
									const	basso_matrix_t  *restrict 	Covered,
											uint64_t					candidates_score[])

{
#pragma omp parallel for
	for(uint64_t col_C = 0 ; col_C < C->cols ; col_C++)
	{
		uint64_t candidate_score = 0;
#pragma omp parallel for reduction (+: candidate_score)
		for(uint64_t col_A = 0 ; col_A < A->cols ; col_A++)
		{
			basso_elem_t *restrict v_candidate 	= C->data		+ col_C * C->elem_per_vect;
			basso_elem_t *restrict v_A 			= A->data 		+ col_A * A->elem_per_vect;
			basso_elem_t *restrict v_Covered 	= Covered->data + col_A * Covered->elem_per_vect;

			long long score = get_vector_covered_score(v_A,v_Covered,v_candidate,C->elem_per_vect);

			if(score > 0)
				candidate_score += score;
		}

		candidates_score[col_C] = candidate_score;
	}
	return 0;
}

linked_list_t *
get_candidates_in_up_index_lists(const basso_matrix_t *restrict C)
{
	linked_list_t *candidates_in_up_index = (linked_list_t *)malloc(C->rows * sizeof(linked_list_t));
#pragma omp parallel for
	for(uint64_t i=0; i<C->rows;i++)
		init_list(&candidates_in_up_index[i]);

	for(uint64_t i=0 ; i < C->cols ; i++)
	{
#pragma omp parallel for
		for(uint64_t elem_idx = 0 ; elem_idx < C->elem_per_vect ; elem_idx ++)
		{
			basso_elem_t C_i_element = C->data[i * C->elem_per_vect + elem_idx];
			if(C_i_element == 0)
				continue;
			int maxbit = ((elem_idx+1) * basso_elem_bits > C->rows ? C->rows % basso_elem_bits : basso_elem_bits);

			for(int k = 0 ; k < maxbit ; k++)
			{
				if((C_i_element & BASSO_ONE_AT_IND(k)) == 0)
					continue;

				int row = elem_idx * basso_elem_bits + k;
				push_back(&candidates_in_up_index[row],i);
			}
		}
	}

	return candidates_in_up_index;
}

linked_list_t *
get_candidate_overlapped_list(const linked_list_t* candidates_in_up_index,const uint64_t number_of_candidates,const basso_elem_t *candidate,const uint64_t elem_per_vect)
{
	linked_list_t *overlapped_candidates = (linked_list_t *)malloc(sizeof(linked_list_t));
	init_list(overlapped_candidates);

	basso_matrix_t *candidates_bitmask_vect = basso_m_alloc(1,number_of_candidates,BASSO_ROW_MAJ);
	for(uint64_t i=0 ; i < elem_per_vect; i++)
	{
		basso_elem_t element = candidate[i];
		for(uint64_t j=0 ; j < basso_elem_bits ; j++)
		{
			if((BASSO_ONE_AT_IND(j) & element) == 0)
				continue;

			uint64_t up_index = i * basso_elem_bits + j;

			node_t *node = candidates_in_up_index[up_index].head;
			for(uint64_t cnt = 0 ; cnt < candidates_in_up_index[up_index].count ; cnt++, node = node->next)
			{
				uint64_t candidate_index = node->data;
				candidates_bitmask_vect->data[candidate_index/basso_elem_bits] |= BASSO_ONE_AT_IND(candidate_index % basso_elem_bits);
			}

		}

	}


	for(uint64_t i=0 ; i < candidates_bitmask_vect->elem_per_vect; i++)
	{
		basso_elem_t element = candidates_bitmask_vect->data[i];
		for(uint64_t j=0 ; j < basso_elem_bits ; j++)
		{
			if((BASSO_ONE_AT_IND(j) & element) == 0)
				continue;

			uint64_t candidate_index = i * basso_elem_bits + j;
			push_back(overlapped_candidates,candidate_index);
		}
	}

	basso_m_free(candidates_bitmask_vect);

	return overlapped_candidates;

}


int
update_candidates_covered_score(	const 	basso_matrix_t *restrict 	A,
									const 	basso_matrix_t *restrict 	C,
									const 	basso_matrix_t *restrict 	Covered,
									const 	uint64_t					selected_candidate_index,
									const 	basso_elem_t				*selected_candidate_right_factor,
									const	bool						remove_its_score,
											uint64_t					candidates_score[])

{
	int sign = (remove_its_score ? -1 : 1);

	const uint64_t	r_factor_elem_per_vect = elem_per_vect(A->cols);
	basso_elem_t *v_selected_candidate = C->data + selected_candidate_index * C->elem_per_vect;

	for(uint64_t col_C = 0; col_C < C->cols ; col_C++){
		basso_elem_t *v_candidate = C->data + col_C * C->elem_per_vect;

		long long diff = 0;
#pragma omp parallel for reduction(+:diff)
		for(uint64_t i=0 ; i < r_factor_elem_per_vect ; i++)
		{
			basso_elem_t right_factor_elem = selected_candidate_right_factor[i];
			if(right_factor_elem != 0)
			{
				int maxbit = ((i+1) * basso_elem_bits > A->cols ? A->cols % basso_elem_bits : basso_elem_bits);
				for(int p=0 ; p < maxbit ; p++)
				{
					if((right_factor_elem & BASSO_ONE_AT_IND(p)) == 0)
						continue;

					uint64_t col_A 				= i * basso_elem_bits + p;
					basso_elem_t *v_A 			= A->data 		+ col_A * A->elem_per_vect;
					basso_elem_t *v_Covered 	= Covered->data + col_A * Covered->elem_per_vect;

					long long column_score = 0;
					for(uint64_t k=0 ; k<C->elem_per_vect ; k++)
						column_score += get_element_covered_score(v_A[k],v_Covered[k],v_candidate[k]);


					if(column_score > 0)
						diff += column_score;
				}
			}
		}

		candidates_score[col_C] += sign * diff;

	}
	return 0;
}


int
update_candidates_covered_score_using_candidate_overlap(	const 	basso_matrix_t *restrict 	A,
															const 	basso_matrix_t *restrict 	C,
															const 	basso_matrix_t *restrict 	Covered,
															const 	linked_list_t				*candidates_in_up_index,
															const 	uint64_t					selected_candidate_index,
															const 	basso_elem_t				*selected_candidate_right_factor,
															const	bool						remove_its_score,
																	uint64_t					candidates_score[])

{
	int sign = (remove_its_score ? -1 : 1);

	const uint64_t	r_factor_elem_per_vect = elem_per_vect(A->cols);
	basso_elem_t *v_selected_candidate = C->data + selected_candidate_index * C->elem_per_vect;

	linked_list_t *overlapped_candidates = get_candidate_overlapped_list(candidates_in_up_index,C->cols,v_selected_candidate,C->elem_per_vect);
	node_t *node = overlapped_candidates->head;

	for(uint64_t cnt = 0 ; cnt < overlapped_candidates->count ; cnt++,node = node->next)
	{
		uint64_t col_C = node->data;
		basso_elem_t *v_candidate = C->data + col_C * C->elem_per_vect;

		long long diff = 0;
#pragma omp parallel for reduction(+:diff)
		for(uint64_t i=0 ; i < r_factor_elem_per_vect ; i++)
		{
			basso_elem_t right_factor_elem = selected_candidate_right_factor[i];
			if(right_factor_elem != 0)
			{
				int maxbit = ((i+1) * basso_elem_bits > A->cols ? A->cols % basso_elem_bits : basso_elem_bits);
				for(int p=0 ; p < maxbit ; p++)
				{
					if((right_factor_elem & BASSO_ONE_AT_IND(p)) == 0)
						continue;

					uint64_t col_A 				= i * basso_elem_bits + p;
					basso_elem_t *v_A 			= A->data 		+ col_A * A->elem_per_vect;
					basso_elem_t *v_Covered 	= Covered->data + col_A * Covered->elem_per_vect;

					long long column_score = 0;
					for(uint64_t k=0 ; k<C->elem_per_vect ; k++)
						column_score += get_element_covered_score(v_A[k],v_Covered[k],v_candidate[k]);


					if(column_score > 0)
						diff += column_score;
				}
			}
		}

		candidates_score[col_C] += sign * diff;

	}

	free_list(overlapped_candidates);
	free(overlapped_candidates);

	return 0;
}

int
get_candidate_corresponding_factor(	const basso_matrix_t 	*restrict A,
									const basso_matrix_t 	*restrict Covered,
									const basso_elem_t 		*restrict candidate,
									basso_elem_t 			*restrict factor)
{
#pragma omp parallel for
	for (uint64_t l = 0 ; l < A->cols ; ++l)
	{
		const basso_elem_t *v_A = A->data + l * A->elem_per_vect;
		const basso_elem_t *v_Covered = Covered->data + l * Covered->elem_per_vect;
		long long score = get_vector_covered_score(v_A,v_Covered,candidate,A->elem_per_vect);

		if (score > 0)
		{
#pragma omp atomic
			factor[l / basso_elem_bits] |= BASSO_ONE_AT_IND(l);
		}
	}

	return 0;
}

int
update_covered_matrix(	const basso_elem_t	*restrict left_fact,
						const basso_elem_t	*restrict right_fact,
						basso_matrix_t  	*restrict Covered)
{
	if(left_fact == NULL || right_fact == NULL)
	{
		errno = EINVAL;
		return 1;
	}

	if(Covered->majority == BASSO_COL_MAJ)
	{
#pragma omp parallel for
		for (uint64_t col=0 ; col < Covered->cols ; ++col)
		{
			// if the col-th entry of right_fact is 0,
			// we do not cover anything new in this column
			if ( (right_fact[col/basso_elem_bits] & BASSO_ONE_AT_IND(col)) == 0)
				continue;

#pragma omp parallel for
			for (uint64_t k=0 ; k < Covered->elem_per_vect ; ++k)
				Covered->data[col * Covered->elem_per_vect + k] |= left_fact[k];
		}
	}
	else
	{
		BASSO_ERRMSG("NOT IMPLEMENTED");
	}

	return 0;
}

int
rebuild_covered_matrix(	const basso_matrix_t	*restrict B,
						const basso_matrix_t	*restrict X,
						const bool				make_it_transposed,
						basso_matrix_t			*restrict Covered)
{
	if(B == NULL || X == NULL || Covered == NULL)
	{
		errno = EINVAL;
		return 1;
	}

	if(Covered->majority == BASSO_ROW_MAJ)
	{
		BASSO_ERRMSG("NOT IMPLEMENTED FOR ROW MAJOR");
		return 1;
	}

	//Clear Covered matrix
	basso_m_set_all_zeros(Covered);

	basso_elem_t	*restrict left_factor, *restrict right_factor;

	if(make_it_transposed)
	{
		for(uint64_t i = 0 ; i < X->rows ; i++)
		{
			left_factor		= X->data + i * X->elem_per_vect;
			right_factor 	= B->data + i * B->elem_per_vect;
			update_covered_matrix(left_factor,right_factor,Covered);
		}
	}
	else
	{
		for(uint64_t i = 0 ; i < B->cols ; i++)
		{
			left_factor 	= B->data + i * B->elem_per_vect;
			right_factor	= X->data + i * X->elem_per_vect;
			update_covered_matrix(left_factor,right_factor,Covered);
		}
	}

	return 0;
}

int
update_covered_matrix_without_nth_factor(	const basso_matrix_t	*restrict B,
											const basso_matrix_t	*restrict X,
											const uint64_t			n,
											const uint64_t			num_factors,
											const bool				make_it_transposed,
											basso_matrix_t			*restrict Covered)
{
	if(B == NULL || X == NULL || Covered == NULL)
	{
		errno = EINVAL;
		return 1;
	}

	if(Covered->majority == BASSO_ROW_MAJ)
	{
		BASSO_ERRMSG("NOT IMPLEMENTED FOR ROW MAJOR");
		return 1;
	}

	if(make_it_transposed)
	{
		if(B->rows != Covered->cols || X->cols != Covered->rows)
		{
			BASSO_ERRMSG("Dimensions are not matched");
			return 1;
		}

#pragma omp parallel for
		for(uint64_t i = 0 ; i < B->rows ; i++)
		{
			basso_elem_t *removing_B_factor = B->data + n * B->elem_per_vect;
			if((removing_B_factor[i/basso_elem_bits] & BASSO_ONE_AT_IND(i)) == 0)
					continue;

			basso_m_set_nth_col_zero(Covered,i);

			for(uint64_t j=0 ; j < num_factors ; j++)
			{
				if(j != n)
				{
					basso_elem_t 	*left_factor 	= X->data + j * X->elem_per_vect;
					basso_elem_t	*right_factor 	= B->data + j * B->elem_per_vect;
					if((right_factor[i/basso_elem_bits] & BASSO_ONE_AT_IND(i)) == 0)
							continue;

#pragma omp parallel for
					for(uint64_t k=0 ; k < Covered->elem_per_vect ; k++)
						Covered->data[i * Covered->elem_per_vect + k] |= left_factor[k];
				}
			}
		}
	}
	else
	{
		if(B->rows != Covered->rows || X->cols != Covered->cols)
		{
			BASSO_ERRMSG("Dimensions are not matched");
			return 1;
		}

		basso_elem_t *removing_X_factor = X->data + n * X->elem_per_vect;
#pragma omp parallel for
		for(uint64_t i = 0 ; i < X->cols ; i++)
		{
			if((removing_X_factor[i/basso_elem_bits] & BASSO_ONE_AT_IND(i)) == 0)
					continue;

			basso_m_set_nth_col_zero(Covered,i);

			for(uint64_t j=0;j<num_factors;j++)
			{
				if(j != n)
				{
					basso_elem_t	*restrict left_factor 	= B->data + j * B->elem_per_vect;
					basso_elem_t 	*restrict right_factor 	= X->data + j * X->elem_per_vect;
					if((right_factor[i/basso_elem_bits] & BASSO_ONE_AT_IND(i)) == 0)
							continue;

#pragma omp parallel for
					for(uint64_t k=0 ; k < Covered->elem_per_vect ; k++)
						Covered->data[i * Covered->elem_per_vect + k] |= left_factor[k];
				}
			}
		}
	}

	return 0;
}

uint64_t
get_best_left_and_right_factors_naive(	const	basso_matrix_t  *restrict 	A,
										const 	basso_matrix_t  *restrict 	C,
												basso_matrix_t  *restrict 	Covered,
												uint64_t					candidates_score[],
												basso_elem_t	*restrict 	left_fact,
												basso_elem_t	*restrict 	right_fact)
{

	compute_candidates_covered_score(A,C,Covered,candidates_score);

	uint64_t max_score_candidate_idx = get_max_index(candidates_score,C->cols);
	uint64_t max_score = candidates_score[max_score_candidate_idx];

	memcpy(left_fact, C->data + max_score_candidate_idx * C->elem_per_vect, C->elem_per_vect * sizeof(basso_elem_t));

	get_candidate_corresponding_factor(A,Covered,left_fact,right_fact);

	update_covered_matrix(left_fact,right_fact,Covered);

	return max_score;
}

uint64_t
get_best_left_and_right_factors_optimized(	const basso_matrix_t  	*restrict A,
											const basso_matrix_t  	*restrict C,
											const basso_option_t	*opt,
											const linked_list_t		*candidates_in_up_index,
											const uint64_t			factor_index,
											long long				factor_to_candidate_index[],
											basso_matrix_t  		*restrict Covered,
											uint64_t				candidates_score[],
											basso_elem_t			*restrict left_fact,
											basso_elem_t			*restrict right_fact)
{

	uint64_t max_score_candidate_idx = get_max_index(candidates_score,C->cols);
	uint64_t max_score = candidates_score[max_score_candidate_idx];

	memcpy(left_fact, C->data + max_score_candidate_idx * C->elem_per_vect, C->elem_per_vect * sizeof(basso_elem_t));

	get_candidate_corresponding_factor(A,Covered,left_fact,right_fact);

	if(basso_opt_is_use_candidates_overlap_alg_set(opt))
		update_candidates_covered_score_using_candidate_overlap(A,C,Covered,candidates_in_up_index,max_score_candidate_idx,right_fact,true,candidates_score);
	else
		update_candidates_covered_score(A,C,Covered,max_score_candidate_idx,right_fact,true,candidates_score);

	update_covered_matrix(left_fact,right_fact,Covered);

	if(basso_opt_is_use_candidates_overlap_alg_set(opt))
		update_candidates_covered_score_using_candidate_overlap(A,C,Covered,candidates_in_up_index,max_score_candidate_idx,right_fact,false,candidates_score);
	else
		update_candidates_covered_score(A,C,Covered,max_score_candidate_idx,right_fact,false,candidates_score);

	factor_to_candidate_index[factor_index] = max_score_candidate_idx;

	return max_score;
}

long long
get_best_symmetric_left_and_right_factors(	const basso_matrix_t  *restrict A,
											const basso_matrix_t  *restrict C,
											basso_matrix_t  *restrict Covered,
											basso_elem_t	*restrict factor_L,
											basso_elem_t	*restrict factor_R)
{
	//printBitwiseMatrixx(A);
	//printBitwiseMatrixx(C);
	long long best_score = LLONG_MIN;
	uint64_t best_index = 0;

	for(uint64_t c = 0 ; c < C->cols ; c++)
	{
		basso_elem_t *restrict candidate = C->data + c * C->elem_per_vect;
		long long score = 0;

#pragma omp parallel for reduction (+:score)
		for (uint64_t col = 0 ; col < A->cols ; ++col)
		{
			if((candidate[col/basso_elem_bits] & BASSO_ONE_AT_IND(col)) == 0)
				continue;

			const basso_elem_t *v_A = A->data + col * A->elem_per_vect;
			const basso_elem_t *v_Covered = Covered->data + col * Covered->elem_per_vect;

			uint64_t covered_score_of_1s = 0;
			uint64_t covered_score_of_0s = 0;

			for (uint64_t i=0; i < A->elem_per_vect; ++i)
			{
				// find the newly covered 1s
				basso_elem_t newlyCovered;
				newlyCovered  = ~(v_Covered[i]);
				newlyCovered &=   v_A[i];
				newlyCovered &=   candidate[i];

				// find the newly overcovered 1s, i.e. 0-entries of A which were not
				// overcovered before
				basso_elem_t newlyOvercovered;
				newlyOvercovered  = v_A[i];
				newlyOvercovered |= v_Covered[i];
				newlyOvercovered  = ~newlyOvercovered;
				newlyOvercovered &= candidate[i];
				if(i == col/basso_elem_bits)
					newlyOvercovered &= ~BASSO_ONE_AT_IND(i);

				covered_score_of_1s += BASSO_POPCNT(newlyCovered);
				covered_score_of_0s	+= BASSO_POPCNT(newlyOvercovered);
			}

			long long column_score = covering_1s_weight * covered_score_of_1s - covering_0s_weight * covered_score_of_0s;
			score += column_score;
		}

		if (score >= best_score) {
			best_score = score;
			best_index = c;
		}

	}

	memcpy(factor_L, C->data + best_index * C->elem_per_vect, C->elem_per_vect * sizeof(basso_elem_t));
	memcpy(factor_R, C->data + best_index * C->elem_per_vect, C->elem_per_vect * sizeof(basso_elem_t));

	update_covered_matrix(factor_L,factor_R,Covered);
	//printBitwiseMatrixx(Covered);


	return best_score;
}


int
iterative_update(	const basso_matrix_t  	*restrict A,
					basso_matrix_t  		*restrict B,
					basso_matrix_t  		*restrict X)
{
	//First for every factor of B, we update it
	basso_matrix_t *restrict AT = basso_m_alloc(A->cols,A->rows,BASSO_COL_MAJ); // A transpose
	basso_m_transpose(AT,A);
	basso_matrix_t *restrict AT_Covered = basso_m_alloc(AT->rows,AT->cols,BASSO_COL_MAJ);
	rebuild_covered_matrix(B,X,true,AT_Covered);


	for(uint64_t i=0 ; i < B->cols ; i++)
	{
		update_covered_matrix_without_nth_factor(B,X,i,B->cols,true,AT_Covered);

		//Clean and re-generate B without i_th factor
		basso_m_set_nth_col_zero(B,i);


		basso_elem_t *restrict right_factor = X->data + i * X->elem_per_vect;	//This is the candidate
		basso_elem_t *restrict left_factor 	= B->data + i * B->elem_per_vect;	//This is the factor needs to be updated

		//This will be row covered score
		get_candidate_corresponding_factor(AT,AT_Covered,right_factor,left_factor);

		update_covered_matrix(right_factor,left_factor,AT_Covered);

		//printf("Iterative update: Updating %lluth factor in B. RE = %llu\n",i,basso_m_bnorm(A,B,X));
	}
	basso_m_free(AT);
	basso_m_free(AT_Covered);

	//Update factors of X based on new B
	basso_matrix_t *restrict A_Covered = basso_m_alloc(A->rows,A->cols,BASSO_COL_MAJ);
	rebuild_covered_matrix(B,X,false,A_Covered);

	for(uint64_t i=0 ; i < X->rows ; i++)
	{
		update_covered_matrix_without_nth_factor(B,X,i,X->rows,false,A_Covered);

		//Clean and re-generate B without i_th factor
		basso_m_set_nth_row_zero(X,i);

		basso_elem_t *restrict right_factor = X->data + i * X->elem_per_vect;	//This is the factor needs to be updated
		basso_elem_t *restrict left_factor 	= B->data + i * B->elem_per_vect;	//This is the candidate

		//This will be column covered score
		get_candidate_corresponding_factor(A,A_Covered,left_factor,right_factor);

		update_covered_matrix(left_factor,right_factor,A_Covered);
		//printf("Iterative update: Updating %lluth factor in X. RE = %llu\n",i,basso_m_bnorm(A,B,X));
	}
	basso_m_free(A_Covered);

	return 0;
}

int
update_factors_optimized(	const 	basso_matrix_t *restrict 	A,
							const 	basso_matrix_t *restrict 	C,
							const	linked_list_t  				*candidates_in_up_index,
							const	basso_option_t				*opt,
									basso_matrix_t *restrict 	Covered,
									basso_matrix_t *restrict 	B,
									basso_matrix_t *restrict 	X,
									long long					factor_to_candidate_index[],
									uint64_t					candidates_score[],
									uint64_t 					factors_count)
{

	//Running update: For every factors we have found so far, we remove it and find it again based on the others
	//Updating j_th factor
	for(uint64_t j = 0 ; j < factors_count ; j++)
	{
		basso_elem_t *left_fact 	= B->data + j * B->elem_per_vect;
		basso_elem_t *right_fact	= X->data + j * X->elem_per_vect;

		//before removing the factor, we remove its effect on the score if and only if optimized flag is enabled
		if(basso_opt_is_use_candidates_overlap_alg_set(opt))
			update_candidates_covered_score_using_candidate_overlap(A,C,Covered,candidates_in_up_index,factor_to_candidate_index[j],right_fact,true,candidates_score);
		else
			update_candidates_covered_score(A,C,Covered,factor_to_candidate_index[j],right_fact,true,candidates_score);

		//Regenerate mask matrix without j_th factor of i founded factors so far
		update_covered_matrix_without_nth_factor(B,X,j,factors_count,false,Covered);

		if(basso_opt_is_use_candidates_overlap_alg_set(opt))
			update_candidates_covered_score_using_candidate_overlap(A,C,Covered,candidates_in_up_index,factor_to_candidate_index[j],right_fact,false,candidates_score);
		else
			update_candidates_covered_score(A,C,Covered,factor_to_candidate_index[j],right_fact,false,candidates_score);

		basso_m_set_nth_col_zero(B,j);
		basso_m_set_nth_row_zero(X,j);

		factor_to_candidate_index[j] = -1;

		//Find the j_th factor again (update)
		long long updated_candidate_score;
		updated_candidate_score = get_best_left_and_right_factors_optimized(A,C,opt,candidates_in_up_index,j,factor_to_candidate_index,Covered,candidates_score,left_fact,right_fact);
	}

	return 0;
}

int
update_factors_naive(	const 	basso_matrix_t *restrict 	A,
						const 	basso_matrix_t *restrict 	C,
						const	basso_option_t *restrict    opt,
								basso_matrix_t *restrict 	Covered,
								basso_matrix_t *restrict 	B,
								basso_matrix_t *restrict 	X,
								uint64_t					candidates_score[],
								uint64_t 					factors_count)
{

	//Running update: For every factors we have found so far, we remove it and find it again based on the others
	//Updating j_th factor
	for(uint64_t j = 0 ; j < factors_count ; j++)
	{
		basso_elem_t *left_fact 	= B->data + j * B->elem_per_vect;
		basso_elem_t *right_fact	= X->data + j * X->elem_per_vect;

		//Regenerate mask matrix without j_th factor of i founded factors so far
		update_covered_matrix_without_nth_factor(B,X,j,factors_count,false,Covered);

		basso_m_set_nth_col_zero(B,j);
		basso_m_set_nth_row_zero(X,j);

		//Find the j_th factor again (update)
		long long updated_candidate_score;
		if(basso_opt_is_symmetrical_decompose_set(opt))
		{
			updated_candidate_score = get_best_symmetric_left_and_right_factors(A,C,Covered,left_fact,right_fact);
		}
		else
		{
			updated_candidate_score = get_best_left_and_right_factors_naive(A,C,Covered,candidates_score,left_fact,right_fact);
		}
	}

	return 0;
}




int
basso_select_basis(	const basso_matrix_t  	*restrict A,      // column-major
					const basso_matrix_t  	*restrict Association_matrix,      // column-major
                  	const basso_option_t  	*restrict opt,
                    basso_matrix_t 			**restrict Bptr,  // column-major
                    basso_matrix_t 			**restrict Xptr)  // row-major
{
	int retval = 0; // Set to non-zero in case of error
	if (A == NULL || Association_matrix == NULL || opt == NULL) {
		errno = EINVAL;
		retval = 1;
		return retval;
	}

	const uint64_t k 						= basso_opt_get_rank(opt);
	const uint64_t update_step 				= basso_opt_get_update_step(opt);
	const uint64_t update_candidate_step 	= basso_opt_get_update_candidates_step(opt);
	covering_1s_weight 						= basso_opt_get_weight(opt);
	covering_0s_weight 						= basso_opt_get_zero_cover_weight(opt); // It changes over time
	double modifier 						= basso_opt_get_zcw_modify_step(opt);

	/* Allocate memory for the results & temporary data */
	basso_matrix_t *restrict B       	= basso_m_alloc(A->rows, k, BASSO_COL_MAJ);
	basso_matrix_t *restrict X       	= basso_m_alloc(k, A->cols, BASSO_ROW_MAJ);
	basso_matrix_t *restrict Covered 	= basso_m_alloc(A->rows, A->cols, BASSO_COL_MAJ);

	*Bptr = B;
	*Xptr = X;

	//We change C over time since we make copy of association matrix
	basso_matrix_t *restrict C = basso_m_alloc(Association_matrix->rows, Association_matrix->cols, BASSO_COL_MAJ);
	basso_m_copy(C,Association_matrix);

	if(basso_opt_is_ext_candidate_set(opt))
	{
		basso_matrix_t *restrict new_mat = basso_m_alloc(C->rows, C->cols + A->cols, BASSO_COL_MAJ);
		basso_m_hor_concat(C,A,new_mat);
		basso_m_free(C);
		C = new_mat;
	}

	if(basso_opt_is_remove_duplicate_candidates_set(opt))
	{
		basso_matrix_t *restrict C_unique = basso_m_remove_duplicate_column(C);
		basso_m_free(C);
		C = C_unique;
	}


	if (B == NULL || X == NULL || Covered == NULL) {
		retval = 1;
		goto fail;
	}

	uint64_t *candidates_score = (uint64_t *) malloc(C->cols * sizeof(uint64_t));



	memset(candidates_score,0,C->cols * sizeof(uint64_t));

	linked_list_t *candidates_in_up_index;
	long long *factor_to_candidate_index;

	if(basso_opt_is_optimized_computation_set(opt))
	{
		if(basso_opt_is_use_candidates_overlap_alg_set(opt))
		{
			candidates_in_up_index = get_candidates_in_up_index_lists(C);
		}
		factor_to_candidate_index = (long long *)malloc(k * sizeof(long long));
		memset(factor_to_candidate_index,-1,k * sizeof(long long));
	}

	if(candidates_score == NULL)
	{
		errno = EINVAL;
		retval = 1;
		return retval;
	}

	for(uint64_t i = 0 ; i < C->rows ; i++)
		if(&candidates_in_up_index[i] == NULL)
		{
			errno = EINVAL;
			retval = 1;
			return retval;
		}


	compute_candidates_covered_score(A,C,Covered,candidates_score);

	// We run updating factors procedure when the it is time to update the factors based on update_step or the right factor is zero-vector
	// Do it one more if k is not divisible by update_step
	// If the update step is larger than k, it takes care of zero score update.
	// If the update step is between 1 and k, it takes care of both periodic and zero-score update.
	// If the update step is 0, the update phase will not be run.
	bool update_flag_is_on = (update_step != B_DEFAULT_UPDATE_STEP);
	bool periodic_update_is_on = (update_step > 0 && update_step <= k);

	for(uint64_t i = 0 ; i < k ; i++)
	{
		if(update_candidate_step != B_DEFAULT_UPDATE_CANDIDATES_STEP && (i+1) % basso_opt_get_update_candidates_step(opt) == 0)
		{
			basso_matrix_t *restrict A_residual = basso_m_XOR(A,Covered);
			basso_matrix_t *restrict new_C = basso_association_matrix(A_residual,NULL,opt);
			basso_m_free(A_residual);
			basso_matrix_t *restrict all_C = basso_m_alloc(C->rows, C->cols + new_C->cols, BASSO_COL_MAJ);
			basso_m_hor_concat(C,new_C,all_C);
			basso_m_free(new_C);
			basso_m_free(C);
			C = all_C;

			if(basso_opt_is_remove_duplicate_candidates_set(opt))
			{
				basso_matrix_t *restrict C_unique = basso_m_remove_duplicate_column(C);
				basso_m_free(C);
				C = C_unique;
			}

			free(candidates_score);
			candidates_score = (uint64_t *) malloc(C->cols * sizeof(uint64_t));
			memset(candidates_score,0,C->cols * sizeof(uint64_t));
			compute_candidates_covered_score(A,C,Covered,candidates_score);



			//fixme:
			if(basso_opt_is_optimized_computation_set(opt))
			{
				//basso_m_free(candidates_overlap_adj);
				//candidates_overlap_adj = get_candidates_overlap_adjacency_matrix(C);
			}












		}



		//These pointers point to the position of i_th column and row of the left and right factor matrices to fill them with the new founded factors
		basso_elem_t *left_fact = B->data + i * B->elem_per_vect;
		basso_elem_t *right_fact = X->data + i * X->elem_per_vect;

		//Find the i_th left and right factors and the candidate which has been selected for the left factor
		long long candidate_score;
		if(basso_opt_is_symmetrical_decompose_set(opt))
		{
			get_best_symmetric_left_and_right_factors(A,C,Covered,left_fact,right_fact);
		}
		else
		{
			if(basso_opt_is_optimized_computation_set(opt))
			{
				candidate_score = get_best_left_and_right_factors_optimized(A,C,opt,candidates_in_up_index,i,factor_to_candidate_index,Covered,candidates_score,left_fact,right_fact);
			}
			else
			{
				candidate_score = get_best_left_and_right_factors_naive(A,C,Covered,candidates_score,left_fact,right_fact);
			}
		}


		bool time_to_update = update_flag_is_on && ((i+1) % update_step == 0 || i == k-1);
		if(update_flag_is_on && (periodic_update_is_on && time_to_update))
		{
			if(basso_opt_is_symmetrical_decompose_set(opt) || !basso_opt_is_optimized_computation_set(opt))
				update_factors_naive(A,C,opt,Covered,B,X,candidates_score,i+1);
			else
				update_factors_optimized(A,C,candidates_in_up_index,opt,Covered,B,X,factor_to_candidate_index,candidates_score,i+1);
		}

		//change the zero cover weight till it is larger than 1
		uint64_t new_weight = covering_0s_weight * modifier;
		covering_0s_weight = (new_weight > 1 ? new_weight : 1);

		if(basso_opt_is_print_mid_error_set(opt))
		{
			printf("Intermediate reconstruction error:\t%llu\n",basso_m_bnorm(A,B,X));
		}

	}

	basso_m_free(Covered);

	uint64_t iter_update = basso_opt_get_iterative_update(opt);
	for(uint64_t i = 0; i < iter_update;i++)
		iterative_update(A,B,X);


	goto cleanup; // Successful execution

fail:
	basso_m_free(*Bptr);
	basso_m_free(*Xptr);

cleanup:

	if(basso_opt_is_optimized_computation_set(opt))
	{
		if(basso_opt_is_use_candidates_overlap_alg_set(opt))
		{
			#pragma omp parallel for
				for(uint64_t i=0; i<C->rows;i++)
					free_list(&candidates_in_up_index[i]);

			free(candidates_in_up_index);
		}

		free(factor_to_candidate_index);
	}

	//basso_m_free(right_factors);
	free(candidates_score);
	//basso_m_free(Covered);

	return retval;
}


//
//int
//symmetric_factorization(const basso_matrix_t 	*restrict A,
//						const basso_option_t  	*restrict opt,
//							  basso_matrix_t  	**restrict B_ptr,
//							  basso_matrix_t  	**restrict X_ptr)
//{
//	const uint64_t	covering_1s_weight = basso_opt_get_weight(opt);
//	const uint64_t	covering_0s_weight = basso_opt_get_zero_cover_weight(opt);
//
//	 /*
//	 * We choose the lowest reconstruction error between B.BT and XT.X to determine
//	 * which of B or XT matrices we should start with as a left factor matrix (Obviously, the right factor
//	 * matrix will be BT or X respectively).
//	 */
//
//
//	basso_matrix_t *restrict B = *B_ptr;
//	basso_matrix_t *restrict X = *X_ptr;
//
////	printBitwiseMatrixx(A);
////	basso_matrix_t *B_X 	= basso_m_alloc(B->rows,X->cols,BASSO_COL_MAJ);
////	basso_m_bprod(B,X,B_X);
////
////	printBitwiseMatrixx(B_X);
////	printBitwiseMatrixx(B);
////	printBitwiseMatrixx(X);
//
//	basso_matrix_t *BT 		= basso_m_alloc(B->cols,B->rows,BASSO_ROW_MAJ);
//	basso_matrix_t *B_BT 	= basso_m_alloc(B->rows,B->rows,BASSO_COL_MAJ);
//	basso_m_transpose(BT,B);
//	basso_m_bprod(B,BT,B_BT);
//	//printBitwiseMatrixx(B_BT);
//	uint64_t B_BT_RE = basso_m_diff_ignore_diagonal(A,B_BT);
//	basso_m_free(B_BT);
//
//	basso_matrix_t *XT 		= basso_m_alloc(X->cols,X->rows,BASSO_COL_MAJ);
//	basso_matrix_t *XT_X 	= basso_m_alloc(X->cols,X->cols,BASSO_COL_MAJ);
//	basso_m_transpose(XT,X);
//	basso_m_bprod(XT,X,XT_X);
//	//printBitwiseMatrixx(XT_X);
//	uint64_t XT_X_RE = basso_m_diff_ignore_diagonal(A,XT_X);
//	basso_m_free(XT_X);
//
//	if(XT_X_RE < B_BT_RE)
//	{
//		//B=XT , X=X
//		basso_m_free(BT);
//		basso_m_free(B);
//		B = XT;
//	}
//	else
//	{
//		//B = B , X = BT
//		basso_m_free(XT);
//		basso_m_free(X);
//		X = BT;
//	}
//
//	printf("XT.X: %llu B.BT: %llu\n",XT_X_RE,B_BT_RE);
//
//	basso_matrix_t *Covered = basso_m_alloc(A->rows,A->cols,BASSO_COL_MAJ);
//	rebuild_covered_matrix(B,X,false,Covered);
//	long long RE = basso_m_diff_ignore_diagonal(A,Covered);//Reconstruction error
//
//
//	for(uint64_t col=0 ; col < B->cols ; col++)
//	{
//		const basso_elem_t *v_candidate = B->data + col * B->elem_per_vect;
//		//basso_elem_t *vect = B->data + col * B->elem_per_vect;
//		for(uint64_t row=0 ; row < B->rows ; row++)
//		{
//			const basso_elem_t *v_A = A->data + row * A->elem_per_vect;
//			const basso_elem_t *v_covered = Covered->data + row * Covered->elem_per_vect;
//			int value = basso_m_get_val(B,row,col);
//			//Since we want to flip the value and check the RE, the row variable will be the row and column of B.X get affected
//			//B.X = Covered
//			if(value == 0)
//			{
//				//When this value (bit) is 0, it means this candidate has never had effect on B.X.
//				//So, we don't need to regenerate Covered(B.X) matrix again.
//				long long score = get_vector_covered_score(v_A,v_covered,v_candidate,B->elem_per_vect,covering_1s_weight,covering_0s_weight);
//				if(score > 0)
//				{
//					basso_m_set_val(B,row,col,1);
//					basso_m_set_val(X,col,row,1);//Fixme: we can only work with B but the functions argument are restrict
//					RE -= 2*score;
//				}
//
//				update_covered_matrix(v_candidate,v_candidate,Covered);
//			}
//			else
//			{
//				basso_m_set_val(B,row,col,0);
//				basso_m_set_val(X,col,row,0);
//
//
//				//Fixme: Very bad method, we can build it more efficient. We only changed a bit two rows and columns will be changed only
//				rebuild_covered_matrix(B,X,false,Covered);
//
//				long long new_RE = basso_m_diff_ignore_diagonal(A,Covered);
//				if(new_RE <= RE)
//				{
//					RE = new_RE;
//				}
//				else
//				{
//					//Return it to the first state
//					basso_m_set_val(B,row,col,1);
//					basso_m_set_val(X,col,row,1);
//					update_covered_matrix(v_candidate,v_candidate,Covered);
//				}
//			}
//		}
//		printf("Symmetric reconstruction error(Ignoring diagonal): %lld\n",RE);
//	}
//
//	//printBitwiseMatrixx(Covered);
//	basso_m_free(Covered);
//
//	*B_ptr = B;
//	*X_ptr = X;
//
//	return 0;
//}


//int
//regenerate_transposed_covered_matrix(	const basso_matrix_t	*restrict B,
//										const basso_matrix_t	*restrict X,
//										basso_matrix_t			*restrict Covered)
//{
//	if(B == NULL || X == NULL || Covered == NULL)
//	{
//		errno = EINVAL;
//		return 1;
//	}
//
//	//Clear Covered matrix
//	basso_m_set_all_zeros(Covered);
//
//	for(uint64_t i = 0 ; i < X->rows ; i++)
//	{
//		basso_elem_t	*restrict right_factor 	= B->data + i * B->elem_per_vect;
//		basso_elem_t	*restrict left_factor	= X->data + i * X->elem_per_vect;
//		update_covered_matrix(left_factor,right_factor,Covered);
//	}
//
//	return 0;
//}


////Sets left and right factors, returns selected candidate index as function argument and its score as function return value.
//int
//get_best_left_and_right_factors_naive2(	const basso_matrix_t  *restrict A,
//										const basso_matrix_t  *restrict C,
//										basso_matrix_t  *restrict Covered,
//										const basso_option_t  *restrict opt,
//										uint64_t		*selected_candidate_score,
//										basso_elem_t	*restrict left_fact,
//										basso_elem_t	*restrict right_fact)
//{
//
//	const uint64_t	covering_1s_weight = basso_opt_get_weight(opt);
//	const uint64_t	covering_0s_weight = basso_opt_get_zero_cover_weight(opt);
//
//	uint64_t best_candidate_score = 0;
//	uint64_t best_candidate_score_idx = 0;
//
//	//Computing covered score for all candidates (columns of C) to find the best one
////#pragma omp parallel for
//	for(uint64_t col_C = 0 ; col_C < C->cols ; col_C++)
//	{
//		size_t temp_right_fact_size = elem_per_vect(A->cols) * sizeof(basso_elem_t);
//		basso_elem_t *restrict temp_right_fact = (basso_elem_t *)malloc(temp_right_fact_size);
//		//Check whether this candidate has been used before or not
//		//This is a temporary right factor for the current candidate
//		//We store this to see whether if the covered score of this candidate is larger than best covered score so far,
//		//Then we copy it to the right factor matrix temporarily.
//		memset(temp_right_fact,0,temp_right_fact_size);
//
//		basso_elem_t *restrict candidate = C->data + col_C * C->elem_per_vect;
//		uint64_t candidate_score;
//
//		get_candidate_corresponding_factor(A,Covered,candidate,covering_1s_weight,covering_0s_weight,&candidate_score,temp_right_fact);
//
//		//Founded a better candidate
////#pragma omp critical
//		{
//			if (candidate_score > best_candidate_score) {
//				best_candidate_score = candidate_score;
//				best_candidate_score_idx = col_C;
//				memcpy(right_fact, temp_right_fact, temp_right_fact_size);
//			}
//		}
//
//		free(temp_right_fact);
//	}
//
//	//Copy the best candidate to the left factor matrix
//	memcpy(left_fact, C->data + best_candidate_score_idx * C->elem_per_vect, C->elem_per_vect * sizeof(basso_elem_t));
//
//	update_covered_matrix(left_fact,right_fact,Covered);
//
//	*selected_candidate_score = best_candidate_score;
//
//	return 0;
//}

//int
//update_candidates_covered_score(	const 	basso_matrix_t *restrict 	A,
//									const 	basso_matrix_t *restrict 	C,
//									const 	basso_matrix_t				*candidates_overlap_adj,
//									const 	basso_matrix_t *restrict 	Covered,
//									const 	uint64_t					selected_candidate_index,
//									const 	basso_elem_t				*selected_candidate_right_factor,
//											uint64_t					candidates_score[])
//
//{
//	const uint64_t	r_factor_elem_per_vect = elem_per_vect(A->cols);
//	basso_elem_t *v_selected_candidate = C->data + selected_candidate_index * C->elem_per_vect;
//
//#pragma omp parallel for
//	for(uint64_t col_C = 0 ; col_C < C->cols ; col_C++)
//	{
//		if(basso_m_get_val(candidates_overlap_adj,selected_candidate_index,col_C) == 1)
//		{
//			if(col_C == selected_candidate_index)
//			{
//				candidates_score[col_C] = 0;
//				continue;
//			}
//
//			basso_elem_t *v_candidate = C->data + col_C * C->elem_per_vect;
//
//			long long diff = 0;
//#pragma omp parallel for reduction(+:diff)
//			for(uint64_t i=0 ; i < r_factor_elem_per_vect ; i++)
//			{
//				basso_elem_t right_factor_elem = selected_candidate_right_factor[i];
//				if(right_factor_elem != 0)
//				{
//					int maxbit = ((i+1) * basso_elem_bits > A->cols ? A->cols % basso_elem_bits : basso_elem_bits);
//					for(int p=0 ; p < maxbit ; p++)
//					{
//						if((right_factor_elem & BASSO_ONE_AT_IND(p)) == 0)
//							continue;
//
//						uint64_t col_A 				= i * basso_elem_bits + p;
//						basso_elem_t *v_A 			= A->data 		+ col_A * A->elem_per_vect;
//						basso_elem_t *v_Covered 	= Covered->data + col_A * Covered->elem_per_vect;
//
//						long long prev_score = 0;
//						for(uint64_t k=0 ; k<C->elem_per_vect ; k++)
//							prev_score += get_element_covered_score(v_A[k],v_Covered[k],v_candidate[k]);
//
//						long long new_score = 0;
//						for(uint64_t k=0 ; k<C->elem_per_vect ; k++)
//							new_score += get_element_covered_score(v_A[k],v_Covered[k] | v_selected_candidate[k],v_candidate[k]);
//
//						//printf("[c=%llu,a=%llu] = (TS = %lld , NS = %lld , PS = %lld , DIFF = %lld\n",col_C,col_A,candidates_score[col_C],new_score,prev_score,diff);
//
//						/* Case 1: c was used, and will be used */
//						if (prev_score > 0 && new_score > 0)
//						{
//							diff += new_score - prev_score;
//						}
//						/* Case 2: c was not used, but will now be used */
//						else if (prev_score <= 0 && new_score > 0)
//							diff += new_score;
//						/* Case 3: c was used, but won’t be used anymore */
//						else if (prev_score > 0 && new_score <= 0)
//							diff -= prev_score;
//					}
//				}
//			}
//			candidates_score[col_C] += diff;
//		}
//	}
//	return 0;
//}




%BASSO computes the Boolean matrix factorization
%
%  BASSO factorizes the input m-by-n Boolean matrix A into m-by-k Boolean 
%  matrix B and k-by-n Boolean matrix C such that the Boolean product of 
%  B and C is approximately A. 
%
%  Usage:
%  [B, C] = BASSO(A, k, tau, threads) where A is the data as a logical matrix, 
%    k is the rank of the decomposition, tau is rounding threshold 
%    (between 0 and 1), and threads is an integer defining how many threads
%    will be used. Threads are only used if BASSO was compiled with OpenMP. 
%
%    All parameters are mandatory, as are the both output parameters.
%
%  (c)2016 Pauli Miettinen and Stefan Neumann

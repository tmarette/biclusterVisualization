#ifdef HAVE_CONFIG_H
# include "config.h"
#endif
#include <stdio.h>
#ifdef _OPENMP
# include <omp.h>
#else
# define omp_set_num_threads(n) do{ \
if((n)>1) mexWarnMsgTxt("Basso was compiled without OpenMP, number of threads is ignored"); \
}while(0)
#endif

#include "matrix.h" // from Matlab
#include "mex.h"

#include "basso.h"
#include "basso2mx.h"


#ifndef HAVE_MXISSCALAR
/* mxIsScalar is available only from 2015a */
static inline int
mxIsScalar(const mxArray *pm)
{
  const mwSize n = mxGetNumberOfDimensions(pm);
  if (n > 2) return 0; // Scalars are always 1-by-1
  const mwSize *dim = mxGetDimensions(pm);
  if (dim[0] != 1 || dim[1] != 1) return 0;
  return 1;
}
#endif

/**
 * Selects a basis to cover a given input matrix A using the columns of
 * A's association matrix C.
 * The input matrix A must be provided in prhs, the output will be stored in plhs.
 *
 * This function is inteded to be called by Matlab.
 */
void
mexFunction(const int      nlhs,
                  mxArray *plhs[],
            const int      nrhs,
            const mxArray *prhs[])
{
  /* Check mandatory input arguments */
	if (nrhs < 3 || nrhs > 5) {
        mexErrMsgTxt("Wrong number of input arguments. Three to five arguments expected:\n"
                     "\tA - the input matrix\n"
                     "\tk - the rank of the decomposition\n"
                     "\tt - the threshold\n"
                     "\tw - the weight of covering 1s (optional)\n"
                     "\tn - the (maximal) number of threads to use (optional)\n\n"
                     "See 'help basso' for more information");
	}
	if (!(mxIsLogical(prhs[0]) || mxIsDouble(prhs[0]))) {
        mexErrMsgTxt("The input matrix must be logical or double.");
	}
  if (mxGetNumberOfDimensions(prhs[0]) != 2) {
        mexErrMsgTxt("The first input variable must be a matrix.");
	}
	if (!(mxIsDouble(prhs[1]) && mxIsScalar(prhs[1]))) {
        mexErrMsgTxt("Second argument must be an integer.");
	}
	if (!(mxIsDouble(prhs[2]) && mxIsScalar(prhs[2]))) {
        mexErrMsgTxt("Third argument must be a scalar of type double.");
  }

  basso_option_t *opt = basso_opt_init();
  if (opt == NULL) mexErrMsgTxt("Failed to initialize options.");
  
  basso_opt_set_rank(opt, (uint64_t)mxGetScalar(prhs[1]));
	basso_opt_set_threshold(opt, mxGetScalar(prhs[2]));
  
  /* Check optional input arguments */
  int nthreads = 1; // The default
  
  if (nrhs > 3) {
    if (!(mxIsScalar(prhs[3]) && mxIsDouble(prhs[3]))) {
      mexErrMsgTxt("Fourth argument must be an integer.");
    }
    basso_opt_set_weight(opt, (uint64_t)mxGetScalar(prhs[3])); // default is 1
  }
  
  if (nrhs > 4) {
    if (!mxIsScalar(prhs[4]) || !mxIsDouble(prhs[4])) {
      mexErrMsgTxt("Fifth argument must be an integer.");
    }
    nthreads = (int)mxGetScalar(prhs[4]);
  }
  
	/* Check output arguments */
  if (nlhs != 2) {
    mexErrMsgTxt("Wrong number of output arguments. Exactly two arguments expected.");
  }
  

	const mwSize * const dim = mxGetDimensions(prhs[0]);
	const mwSize rows = dim[0];
	const mwSize cols = dim[1];

	if (basso_opt_get_rank(opt) >= rows || basso_opt_get_rank(opt) >= cols) {
        mexErrMsgTxt("Please choose k < min{m, n}, where m and n are the dimensions of the input matrix A."
					" For k >= min{m,n} you could just use a trivial factorization.");
	}

	// set up OpenMP
	omp_set_num_threads(nthreads);

	// Convert to bitwise representation
	basso_matrix_t *Arow = mxArray2basso(prhs[0], BASSO_ROW_MAJ);
  if (Arow == NULL) mexErrMsgTxt("Failed to convert the input matrix to bitwise matrix");
  
	basso_matrix_t *B;
	basso_matrix_t *X;
	int failed = basso(Arow, opt, &B, &X);
	basso_m_free(Arow);
  if (failed) mexErrMsgTxt("Failed to compute the BMF using basso");

  /* Copy output -- match type to the input */
  int flags = BASSO2MX_DEFAULT;
  if (mxIsSparse(prhs[0]))  flags |= BASSO2MX_SPARSE;
  if (mxIsLogical(prhs[0])) flags |= BASSO2MX_LOGICAL;
  plhs[0] = basso2mxArray(B, flags);
  plhs[1] = basso2mxArray(X, flags);
  
  basso_m_free(B);
  basso_m_free(X);
  
  if (plhs[0] == NULL || plhs[1] == NULL) mexErrMsgTxt("Failed to convert the bitwise matrices back");
  
  
  }

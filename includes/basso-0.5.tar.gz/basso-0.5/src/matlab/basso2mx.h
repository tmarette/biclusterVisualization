#ifndef BASSO2MEX_H
#define BASSO2MEX_H
#ifdef HAVE_CONFIG_H
# include "config.h"
#endif

#include "bassodata.h"

#include "matrix.h" // from Matlab

/* 
 * FLAGS FOR CHOOSING THE TYPE OF MXARRAY
 */
#define BASSO2MX_DEFAULT  (0) /* dense double */
#define BASSO2MX_LOGICAL  (1)
#define BASSO2MX_SPARSE   (2)

/*
 * Conversion functions
 */

/*
 * Returns a new bitwise matrix based on the input matrix M or NULL on error.
 * The majority of the returned matrix is defined by majority.
 *
 * The returned matrix must be de-allocated using basso_m_free before returning
 * from the MEX function.
 */
BASSO_ATTRIBUTE_MALLOC
basso_matrix_t*
mxArray2basso(const mxArray *restrict M, const basso_majority_t majority);

/*
 * Returns a new mxArray based on the input bitwise matrix M or NULL on error.
 * The type of the matrix is defined by the flags (logical vs. numerical,
 * dense vs. sparse) with 0 corresponding to the default dense numerical format.
 *
 * The resulting mxArray is allocated using mxAlloc and returned from the MEX
 * function or de-allocated using mxFree.
 */
mxArray*
basso2mxArray(const basso_matrix_t *restrict M, const int flags);


#endif /* ifndef BASSO2MEX_H */


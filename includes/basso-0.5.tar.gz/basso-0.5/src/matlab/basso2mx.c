#ifdef HAVE_CONFIG_H
# include "config.h"
#endif

#include "mex.h"    // from Matlab
#include "matrix.h" // from Matlab

#include "basso2mx.h"
#include "bassodata.h"

/* 
 * Static function declarations 
 */
static int
mxArray2basso_dense(const mxArray *restrict M, basso_matrix_t **restrict A);

static int
mxArray2basso_sparse(const mxArray *restrict M, basso_matrix_t **restrict A);

static mxArray *
basso2mxArray_dense(const basso_matrix_t *restrict B, const int flags);

static mxArray *
basso2mxArray_sparse(const basso_matrix_t *restrict B, const int flags);

/*
 * Function definitions
 */

basso_matrix_t*
mxArray2basso(const mxArray *restrict M, const basso_majority_t majority)
{
  if (M == NULL) {
    mexWarnMsgTxt("Cannot convert to bitwise: The input matrix is NULL");
    return NULL;
  }
  if (mxGetNumberOfDimensions(M) != 2) {
    mexWarnMsgTxt("Wrong number of dimensions. A matrix is required.");
    return NULL;
  }
  if (!(mxIsLogical(M) || mxIsDouble(M))) {
    mexWarnMsgTxt("Cannot convert matrices that are not logical or sparse.");
    return NULL;
  }
  
  const mwSize   *dim = mxGetDimensions(M);
  const uint64_t rows = (uint64_t)dim[0];
  const uint64_t cols = (uint64_t)dim[1];
  
  basso_matrix_t *B = basso_m_alloc(rows, cols, majority);
  if (B == NULL) {
    mexWarnMsgTxt("Allocation of bitwise matrix failed.");
    return NULL;
  }
  
  int failed;
  if (mxIsSparse(M)) {
    failed = mxArray2basso_sparse(M, &B);
  } else {
    failed = mxArray2basso_dense(M, &B);
  }
  if (failed) {
    basso_m_free(B);
    B = NULL;
    mexWarnMsgTxt("Converting the input to bitwise matrix failed.");
  }
  
  return B;
}


mxArray*
basso2mxArray(const basso_matrix_t *restrict B, const int flags)
{
  mxArray *M = NULL;

  if (B == NULL) {
    mexWarnMsgTxt("Cannot convert to mxArray: The input matrix is NULL");
    goto fail;
  }
  
  if (flags & BASSO2MX_SPARSE) {
    M = basso2mxArray_sparse(B, flags);
  } else {
    M = basso2mxArray_dense(B, flags);
  }
  
  if (M == NULL) {
    mexWarnMsgTxt("Failed to convert bitwise matrix to mxArray");
    goto fail;
  }
  
fail:
  return M;
}


/*
 * Static function definitions
 */

static int
mxArray2basso_dense(const mxArray *restrict M, basso_matrix_t **restrict A)
{
  basso_matrix_t *B = (*A);
  const uint64_t rows = B->rows;
  const uint64_t cols = B->cols;
  
  if (mxIsLogical(M)) {
    const mxLogical *data = mxGetLogicals(M);
    if (data == NULL) return 1;
    for (uint64_t j = 0; j < cols; j++) {
      for (uint64_t i = 0; i < rows; i++) {
        const int val = (int)data[j*rows + i];
        basso_m_set_val(B, i, j, val);
      }
    }
  } else if (mxIsDouble(M)) {
    const double *data = mxGetPr(M);
    if (data == NULL) return 1;
    for (uint64_t j = 0; j < cols; j++) {
      for (uint64_t i = 0; i < rows; i++) {
        const int val = (data[j*rows + i] != 0)?1:0;
        basso_m_set_val(B, i, j, val);
      }
    }
  } else { // data is neither logical nor double
    return 1;
  }
  return 0;
}


static int
mxArray2basso_sparse(const mxArray *restrict M, basso_matrix_t **restrict A)
{
  basso_matrix_t *B = (*A);
  const uint64_t cols = B->cols;
  
  const mwIndex *jc = mxGetJc(M); // cols+1 elements giving the col lengths
  const mwIndex *ir = mxGetIr(M); // nnz elements giving the row ids
  
  if (jc == NULL || ir == NULL) return 1;
  
  for (mwIndex j = 0; j < cols; j++) {
    for (mwIndex i = jc[j]; i < jc[j+1]; i++) {
      basso_m_set_val(B, ir[i], j, 1);
    }
  }
  
  return 0;
}


static mxArray *
basso2mxArray_dense(const basso_matrix_t *restrict B, const int flags)
{
  const mwSize rows = (mwSize)B->rows;
  const mwSize cols = (mwSize)B->cols;
  
  mxArray *M = NULL;
  
  if (flags & BASSO2MX_LOGICAL) {
    M = mxCreateLogicalMatrix(rows, cols);
    if (M == NULL) {
      goto fail;
    }
    mxLogical *data = mxGetLogicals(M);
    if (data == NULL) {
      mxDestroyArray(M);
      M = NULL;
      goto fail;
    }
    for (mwIndex j = 0; j < cols; j++) {
      for (mwIndex i = 0; i < rows; i++) {
        data[j*rows + i] = (mxLogical)basso_m_get_val(B, i, j);
      }
    }
  } else { // make a double matrix
    M = mxCreateDoubleMatrix(rows, cols, mxREAL);
    if (M == NULL) goto fail;
    double *data = mxGetPr(M);
    if (data == NULL) {
      mxDestroyArray(M);
      M = NULL;
      goto fail;
    }
    for (mwIndex j = 0; j < cols; j++) {
      for (mwIndex i = 0; i < rows; i++) {
        data[j*rows + i] = (double)basso_m_get_val(B, i, j);
      }
    }
  }

fail:
  return M;
}


static mxArray *
basso2mxArray_sparse(const basso_matrix_t *restrict B, const int flags)
{
  const mwSize rows = (mwSize)B->rows;
  const mwSize cols = (mwSize)B->cols;
  
  mxArray *M = NULL;
  
  const mwSize nnz = (mwSize)basso_m_nnz(B);
  
  if (flags & BASSO2MX_LOGICAL) {
    M = mxCreateSparseLogicalMatrix(rows, cols, nnz);
  } else { // sparse double matrix
    M = mxCreateSparse(rows, cols, nnz, mxREAL);
  }
  if (M == NULL) goto fail;
  
  /* Set ir and jc to correct values -- doesn't depend on data type */
  mwIndex *jc = mxGetJc(M); // cols+1, jc[j+1]-jc[j] = # of 1s in col j
  mwIndex *ir = mxGetIr(M); // nnz, row numbers for non-zeros
  if (jc == NULL || ir == NULL) {
    mxDestroyArray(M);
    M = NULL;
    goto fail;
  }
  jc[0] = 0; // By definition
  for (mwIndex j = 0; j < cols; j++) {
    mwIndex ones = 0; // number of 1s in this column
    for (mwIndex i = 0; i < rows; i++) {
      if (basso_m_get_val(B, i, j)) {
        (*ir) = i; // store the row number
        ir++;      // advance the row number array pointer
        ones++;    // add one more 1 to this column
      }
    }
    jc[j+1] = jc[j] + ones;
  }

  /* Set the values to 1[.0] -- depends on data type */
  if (flags & BASSO2MX_LOGICAL) {
    mxLogical *pr = mxGetLogicals(M);
    if (pr == NULL) {
      mxDestroyArray(M);
      M = NULL;
      goto fail;
    }
    for (mwIndex i = 0; i < nnz; i++) {
      pr[i] = 1;
    }
  } else { // sparse logical
    double  *pr = mxGetPr(M); // nnz values, all-1s for us
    if (pr == NULL) {
      mxDestroyArray(M);
      M = NULL;
      goto fail;
    }
    for (mwIndex i = 0; i < nnz; i++) {
      pr[i] = 1.0;
    }
  }
  
fail:
  return M;
}


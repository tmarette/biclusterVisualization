/*
 * Function definitions and macros for command-line interface of Basso
 */

#ifndef _BASSO_CMDLINE_H
#define _BASSO_CMDLINE_H

#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

/* We require POSIX 1995 / X/Open 5 */
#define _GNU_SOURCE
// #define _XOPEN_SOURCE 500

#include "bassodata.h"

/* 
 * PROGRAM EXIT AND FUNCTION RETURN CODES
*/
/*                                           sysexits.h names */
#define BASSO_EXIT_SUCCESS                0
#define BASSO_EXIT_UNKNOWN_ERROR          1
#define BASSO_EXIT_UNIMPLEMENTED         70 // EX_SOFTWARE
#define BASSO_EXIT_INVALID_PARAMETER     64 // EX_USAGE
#define BASSO_EXIT_INVALID_INPUT         65 // EX_DATAERR
#define BASSO_EXIT_INVALID_OUTPUT        73 // EX_CANTCREAT
#define BASSO_EXIT_MEMORY                71 // EX_OSERR
#define BASSO_EXIT_IOERROR               74 // EX_IOERR

#define BASSO_RETURN_SUCCESS              0
#define BASSO_RETURN_IOFAIL              10
#define BASSO_RETURN_IOPERM              15
#define BASSO_RETURN_INVALID_INPUT       20
#define BASSO_RETURN_MEMORY              25 // Use with non-fatal out-of-memory situations 


/*
 * INPUT AND OUTPUT FOR BINARY AND MATRIXMARKET FILES
 */

/*
 * read_mm_matrix_header reads the dimension of the matrix from file
*/
int 
read_mm_matrix_header(const char *filename,size_t *rows,size_t *columns);

/*
 * fill_mm_matrix fills the allocted matrix M from the given file
*/
int
fill_mm_matrix(const char *filename, basso_matrix_t * M);


/*
 * basso_bbm_header stores the header info of a binary file
 */
typedef struct basso_bbm_header {
           char magic[6];
  unsigned char reserved;
  unsigned char flags;
  uint64_t rows;
  uint64_t cols;
} basso_bbm_header;

/*
 * read_mm_matrix reads a MatrixMarket matrix and returns a
 * basso_matrix_t matrix of desired majority.
 *
 * Returns NULL on error.
 */
BASSO_ATTRIBUTE_MALLOC
basso_matrix_t *
read_mm_matrix(const char *file, const basso_majority_t majority);

/*
 * read_bmm_matrix reads a binary matrix file and returns the corresponding 
 * matrix. 
 *
 * Returns NULL on error.
 */
BASSO_ATTRIBUTE_MALLOC
basso_matrix_t *
read_bbm_matrix(const char *file);

/*
 * write_mm_matrix writes the matrix in MatrixMarket format, appending
 * the comments in the preamble.
 *
 * Returns non-zero on error.
 */
int
write_mm_matrix(const char           *restrict filename,
                const basso_matrix_t *restrict M,
                const char           *restrict comments);

/* 
 * write_bbm_matrix writes the matrix in binary format.
 *
 * Returns non-zero on error.
 */
int
write_bbm_matrix(const char           *restrict filename,
                 const basso_matrix_t *restrict M);


/*
 * Returns the string after the last dot in <filename>; returns NULL if there are no dots
 * The output must be free'd.
 */
BASSO_ATTRIBUTE_MALLOC
char *
get_file_suffix(const char *restrict filename);

/*
 * Returns <filename> with everything after and including the last . (dot) removed;
 * returns <filename> if there are no dots.
 * The output must be free'd.
 */
BASSO_ATTRIBUTE_MALLOC
char *
strip_file_suffix(const char *restrict filename);


/*
 * A standard function that's not part of the C99 standard...
 * The output must be free'd.
 */
BASSO_ATTRIBUTE_MALLOC
char *
b_strdup(const char *restrict str);

/* 
 * infer_format infers the data format from the filename.
 *
 * Returns the format ('m' or 'b') if successful, or -1 if not.
 */
BASSO_ATTRIBUTE_PURE
int
infer_format(const char *filename);

/*
 * Macros to check for supported file suffices 
 */
#define BASSO_BINARY_SUFFIX "bbm"
#define BASSO_MM_SUFFIX "mtx"
#define is_suffix_matrixmarket(suffix) (!strcmp((suffix), "mm") || !strcmp((suffix), "mmc") || !strcmp((suffix), BASSO_MM_SUFFIX))
#define is_suffix_bassobinary(suffix) (!strcmp((suffix), BASSO_BINARY_SUFFIX))

/*
 * Enums and structs for internal use
 */

enum factor_side {
  LEFT,
  RIGHT
};



#endif /* _BASSO_CMDLINE_H */

/*
 * basso_strto.h
 *
 * Helper functions to convert strings to number or exit in failure
 *
 */

#ifndef BASSO_STRTO_H
#define BASSO_STRTO_H

#ifdef HAVE_CONFIG_H
#  include "config.h"
#endif

#include "cmdline.h"

#ifdef HAVE_INTTYPES_H 
#  include <inttypes.h>
#else
#  ifdef HAVE_STDINT_T
#    include <stdint.h>
#  endif /* HAVE_STDINT_T */
#endif /* HAVE_INTTYPES_H */

/* strotoullOrExit only supports values until INT64_MAX */ 
uint64_t
strtoullOrExit(const char *restrict str, const char *restrict what);

int
strtolOrExit(const char *restrict str, const char *restrict what);

double
strtodOrExit(const char *restrict str, const char *restrict what);

int
strToDblListOrExit(const char *restrict str, const char *restrict what, const char * delimiter, double *list,uint64_t *list_len);

#endif /* defined BASSO_STRTO_H */

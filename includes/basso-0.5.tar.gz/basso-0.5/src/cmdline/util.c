//
//  util.c
//  basso
//
//  Created by Pauli Miettinen on 6.5.2016.
//  Copyright © 2016 Pauli Miettinen. All rights reserved.
//

#ifdef HAVE_CONFIG_H
#  include "config.h"
#endif

#include <stdio.h>
#include <stdlib.h>
#include <getopt.h>
#include <errno.h>
#include <string.h>
#include <time.h>

#include "cmdline.h"
#include "bassodata.h"

/*
 * Global variables for command-line arguments
 */
static int convert_flag = 0;   // are we convering an input matrix
static int swap_flag = 0;  // are we swapping the majority
static int product_flag = 0; // are we computing the Boolean product
static int diff_flag = 0;  // are we computing the difference of two matrices
static char informat = 0;  // input format, either 'm' or 'b'
static int informat_given = 0; // is the input format given explicitly
static char outformat = 0; // 0 is unset, o/w like informat
static char outmajority = 0; // the majority of the (binary) output, 'r' or 'c'
static size_t n_infiles = 0; // number of input files
static char **infile_list = NULL; // a list of input file names

static char *outfile = NULL; // the output file name, if given
static int outfile_given = 0; // is the output file explicitly given
static char *infile = NULL; // the current input file

static int version_flag = 0; // should we print the version info
static int verbosity_flag = 0; // should we print what we do (--verbose)

static char *prog_name = ""; // the name of the program

/*
 * Global constant string used to set stdin and stdout as filenames 
 */
static char *stdout_str = "-";

/*
 * Static functions
 */

static void
print_help()
{
  fprintf(stdout,
          "Perform simple operations to binary and MatrixMarket matrices.\n"
          "\n"
          "Usage: %s [-c|-s|-p|-d] [OPTIONS] [-o OUTPUT] [INPUT] ...\n"
          "\n"
          "The program supports the following major modes:\n"
          "  -c, --convert      convert the file type\n"
          "  -s, --swap         swap the majority of a file\n"
          "  -p, --product      compute the Boolean product of two matrices\n"
          "  -d, --difference   compute the difference between two matrices\n"
          "\n"
          "The options for the conversion are:\n"
          "  -f, --format=FMT   set the format of the input file to either\n"
          "                     MatrixMarket format with \"m\" or binary\n"
          "                     format with \"b\". If not given, the format is\n"
          "                     inferred from the file name. The output format\n"
          "                     will be the opposite of the input format.\n"
          "  -m, --majority=MAJ sets the majority of the output matrix if\n"
          "                     the output format is binary. Majority can be\n"
          "                     either \"r\" or \"c\" for row and column major.\n"
          "  -o, --output=FILE  save the output to file. If not given, the\n"
          "                     matrix is stored in a file with the same name\n"
          "                     but correct suffix, unless the input is\n"
          "                     standard input, when the output is written to\n"
          "                     standard output\n"
          "\n"
          "The options for the swapping are:\n"
          "  -f, --format=FMT   set the format of the input file to either\n"
          "                     MatrixMarket format with \"m\" or binary\n"
          "                     format with \"b\". If not given, the format is\n"
          "                     inferred from the file name.\n"
          "  -m, --majority=MAJ sets the majority of the output. If not given\n"
          "                     the majority is the opposite of the input data\n"
          "                     majority for binary input files.\n"
          "  -o, --output=FILE  save the ouput to file. If not given, the output\n"
          "                     is written to standard output.\n"
          "For swapping, there must be exaxtly one input file.\n"
          "\n"
          "The options for the product are:\n"
          "  -f, --format=FMT   set the format of the input files to either\n"
          "                     MatrixMarket format with \"m\" or binary\n"
          "                     format with \"b\". If not given, the format is\n"
          "                     inferred from the file names.\n"
          "  -F, --out-format=FMT\n"
          "                     set the output file format to FMT. If not given\n"
          "                     but --format is given, then that is used. Otherwise\n"
          "                     MatrixMarket format is used.\n"
          "  -m, --majority=MAJ sets the majority of the output. If not given\n"
          "                     the majority is set to column major\n"
          "  -o, --output=FILE  save the ouput to file. If not given, the output\n"
          "                     is written to standard output.\n"
          "For product, there must be exactly two input files, one of which can be\n"
          "the standard input.\n"
          "\n"
          "The options for the difference are:\n"
          "  -f, --format=FMT   set the format of the input files to either\n"
          "                     MatrixMarket format with \"m\" or binary\n"
          "                     format with \"b\". If not given, the format is\n"
          "                     inferred from the file names.\n"
          "  -o, --output=FILE  save the difference to file. If not given, the"
          "                     output is written to standard output.\n"
          "For difference, there must be exactly two input files, one of which can\n"
          "be the standard input.\n"
          "\n"
          "Global options are:\n"
          "      --verbose        print information to stderr\n"
          "      --quiet          suppress printing of information (default)\n"
          "  -h, --help           show this help and exit\n"
          "      --version        show the version information and exit\n"
          ,
          prog_name //for usage
  );
}

static void
print_version()
{
  fprintf(stdout,
          "%s utility program %s\n"
          "Copyright (C) 2016 Pauli Miettinen\n"
          "This software is licensed under the MIT license.\n"
          "This is free software: you are free to change and redistribute it.\n"
          "There is no warranty.\n"
          ,
          PACKAGE_NAME, PACKAGE_VERSION);
}

/*
 * Parses the command-line arguments and stores the results to global variables
 */
static int
parse_commandline_arguments(int argc, char *argv[])
{
  int c;

  /* Set prog_name */
  prog_name = argv[0];
  
  /*
   * Parse command-line arguments
   */
  
  while (1) {
    // Arguments
    static struct option long_options[] =
    {
      {"convert",   no_argument,       0,               'c'},
      {"swap",      no_argument,       0,               's'},
      {"product",   no_argument,       0,               'p'},
      {"difference", no_argument,      0,               'd'},
      {"output",    required_argument, 0,               'o'},
      {"format",    required_argument, 0,               'f'},
      {"out-format", required_argument, 0,              'F'},
      {"majority",  required_argument, 0,               'm'},
      {"verbose",   no_argument,       &verbosity_flag,   1},
      {"quiet",     no_argument,       &verbosity_flag,   0},
      {"help",      no_argument,       0,               'h'},
      {"version",   no_argument,       &version_flag,     1},
      {0, 0, 0, 0}
    };
    const char optionstring[] = "cspdo:f:F:m:h";
    int option_index = 0;
    
    c = getopt_long(argc, argv, optionstring, long_options, &option_index);
    
    if (c == -1) {
      // The end of options
      break;
    }
    
    switch (c) {
      case 0:
        /* Check if this is version option */
        if (!strcmp(long_options[option_index].name, "version")) {
          print_version();
          exit(BASSO_EXIT_SUCCESS);
        }
        /* No need to do anything for the verbosity flag */
        break;
      case 'h':
        print_help();
        exit(BASSO_EXIT_SUCCESS);
        
      case 'c':
        convert_flag = 1;
        break;
        
      case 's':
        swap_flag = 1;
        break;
        
      case 'p':
        product_flag = 1;
        break;
        
      case 'd':
        diff_flag = 1;
        break;
        
      case 'o':
        outfile = optarg;
        outfile_given = 1;
        break;
        
      case 'f':
        informat = optarg[0];
        informat_given = 1;
        break;
        
      case 'F':
        outformat = optarg[0];
        break;
        
      case 'm':
        outmajority = optarg[0];
        break;
        
      case '?':
      default:
        exit(BASSO_EXIT_INVALID_PARAMETER);
    }
  }
  
  if (optind == argc) {
    /* Set the infile_list to contain one element, "-" */
    infile_list = &stdout_str;
    n_infiles = 1;
  } else if (optind < argc) {
    n_infiles = argc - optind;
    infile_list = argv + optind;
  }
  
  /* Check that exactly one of -c or -s is set */
  if (convert_flag + swap_flag + product_flag + diff_flag != 1) {
    fprintf(stderr, "Exactly one of --convert, --swap, --product, or --difference must be defined\n"
            "Use %s --help to get help.\n", argv[0]);
    exit(BASSO_EXIT_INVALID_PARAMETER);
  }
  
  return BASSO_RETURN_SUCCESS;
}

static basso_majority_t
infer_majority()
{
  basso_majority_t majority;
  
  switch (outmajority) {
    case 'r':
      majority = BASSO_ROW_MAJ;
      break;
    case 'c':
    case 0:
      majority = BASSO_COL_MAJ;
      break;
    default:
      fprintf(stderr, "Invalid majority %c: must be either \"r\" or \"c\"\n",
              outmajority);
      exit(BASSO_EXIT_INVALID_PARAMETER);
      break;
  }
  return majority;
}

typedef enum mm_comment_type_enum {
  CONVERT_COMMENT = 1,
  BPROD_COMMENT = 2
} mm_comment_type;

static char *
mm_comments(mm_comment_type type)
{
  char date[128];
  const size_t comments_len = 1024*type; // the value of the type dictates the size of the comments
  char *comments;
  time_t t;
  struct tm *tm;
  
  comments = calloc(comments_len, 1);
  if (comments == NULL) {
    fprintf(stderr, "Failed to allocate memory for comments: %s",
            strerror(errno));
    return NULL;
  }
  
  t = time(NULL);
  tm = localtime(&t);
  
  if (strftime(date, sizeof(date), "%Y-%m-%d %H:%M:%S %z", tm) == 0) {
    fprintf(stderr, "Error when formatting time for comments\n");
    free(comments);
    return NULL;
  }

  if (type == CONVERT_COMMENT) {
    snprintf(comments, comments_len,
             "%% Matrix converted by %s on %s\n"
             "%% Original file: %s"
             , prog_name, date, infile);
  } else if (type == BPROD_COMMENT) {
    snprintf(comments, comments_len,
             "%% Product of matrices %s and %s\n"
             "%% Computed by %s on %s"
             , infile_list[0], infile_list[1], prog_name, date);
  }
  
  return comments;
}

void
convert()
{
  basso_majority_t majority = infer_majority();
  
  if (outfile_given && n_infiles > 1) {
    fprintf(stderr, "Error: The output file cannot be set if there are multiple input files\n");
    exit(BASSO_EXIT_INVALID_PARAMETER);
  }
  
  /* Loop over the input files */
  for (int i = 0; i < n_infiles; i++) {
    infile = infile_list[i];
    basso_matrix_t *A;

    if (verbosity_flag) fprintf(stderr, "Converting file %s\n", infile);
    
    /* Parse formats */
    if (!informat_given) {
      /* We go here for every input matrix if the infomat wasn't given explicitly */
      informat = infer_format(infile);
      if (informat == -1) {
        fprintf(stderr, "Warning: could not infer the format of file %s, skipping\n", infile);
        continue;
      }
    }
    
    /* Read input and set output format */
    if (verbosity_flag) fprintf(stderr, "\tReading in format %c...\t", informat);
    switch (informat) {
      case 'm':
        A = read_mm_matrix(infile, majority);
        outformat = 'b';
        break;
      case 'b':
        A = read_bbm_matrix(infile);
        outformat = 'm';
        break;
      default:
        fprintf(stderr, "Error: Invalid informat %c\n", informat);
        exit(BASSO_EXIT_INVALID_PARAMETER);
        break;
    }

    if (A == NULL) {
      exit(BASSO_EXIT_IOERROR);
    }
    if (verbosity_flag) fprintf(stderr, "done.\n");
    
    /* Figure out the output file name */
    if (!outfile_given) {
      if (strcmp(infile, stdout_str) == 0) {
        outfile = malloc(2); // so that we can free outfile
        strcpy(outfile, stdout_str);
      } else {
        const char *suffix = (outformat == 'b') ? BASSO_BINARY_SUFFIX : BASSO_MM_SUFFIX;
        char *basename = strip_file_suffix(infile);
        outfile = malloc(strlen(basename) + 1 + strlen(suffix) + 1);
        strcpy(outfile, basename);
        strcpy(outfile + strlen(basename), ".");
        strcpy(outfile + strlen(basename) + 1, suffix);
      }
    }
    
    /* Write output */
    if (verbosity_flag) fprintf(stderr, "\tWriting to file %s...\t", outfile);
    int retval;
    char *comments;
    switch (outformat) {
      case 'm':
        comments = mm_comments(CONVERT_COMMENT);
        retval = write_mm_matrix(outfile, A, comments);
        if (retval != 0) exit(BASSO_EXIT_IOERROR);
        free(comments);
        break;
      case 'b':
        retval = write_bbm_matrix(outfile, A);
        if (retval != 0) exit(BASSO_EXIT_IOERROR);
        break;
      default:
        fprintf(stderr, "Error: Unknown output file type %c\n", outformat);
        exit(BASSO_EXIT_INVALID_PARAMETER);
        break;
    }
    if (verbosity_flag) fprintf(stderr, "done.\n");
    
    if (!outfile_given) free(outfile);
    basso_m_free(A);
  } /* for infile in infiles */
}

void
swap()
{
  if (n_infiles > 1) {
    fprintf(stderr, "Error: Too many input files for swapping ('-s')\n");
    exit(BASSO_EXIT_INVALID_PARAMETER);
  }
  infile = infile_list[0];
  if (verbosity_flag) fprintf(stderr, "Swapping file %s\n", infile);
  
  /* Swapping is only sensible with binary files, so check the user didn't specify something else */
  if (informat == 'm') {
    fprintf(stderr, "Error: swapping (-s) can only be done with binary matrices\n");
    exit(BASSO_EXIT_INVALID_PARAMETER);
  }
  
  /* Read the input */
  if (verbosity_flag) fprintf(stderr, "\tReading...\t");
  errno = 0;
  basso_matrix_t *A = read_bbm_matrix(infile);
  if (A == NULL) {
    exit(BASSO_EXIT_IOERROR);
  }
  if (verbosity_flag) fprintf(stderr, "done.\n\tSwapping...\t");
  
  errno = 0;
  basso_matrix_t *B = basso_m_swap_duplicate(A);
  if (B == NULL) {
    fprintf(stderr, "Error when swapping the majority: %s", strerror(errno));
    exit(BASSO_EXIT_MEMORY);
  }
  basso_m_free(A);
  if (verbosity_flag) fprintf(stderr, "done.\n\tWriting to %s...\t", (outfile_given)?outfile:stdout_str);
  
  /* Write output */
  if (write_bbm_matrix((outfile_given)?outfile:stdout_str, B)) {
    exit(BASSO_EXIT_IOERROR);
  }
  if (verbosity_flag) fprintf(stderr, "done.\n");
  
  basso_m_free(B);
}

/*
 * Reads a factor matrix from file filename, inferring its type if needed.
 * Sets the majority to maj if reading a MatrixMarket file.
 * Aborts on failure.
 */
basso_matrix_t *
read_factor_matrix(const char *filename, basso_majority_t maj)
{
  basso_matrix_t *A;
  
  if (verbosity_flag) fprintf(stderr, "\tReading matrix from %s...\t", filename);
  /* Parse format */
  if (!informat_given) {
    informat = infer_format(filename);
    if (informat == -1) {
      fprintf(stderr, "Error: could not infer the format of file %s, aborting\n", filename);
      exit(BASSO_EXIT_INVALID_PARAMETER);
    }
  }
  
  /* Read input */
  if (verbosity_flag) fprintf(stderr, "in format %c...\t", informat);
  switch (informat) {
    case 'm':
      A = read_mm_matrix(filename, maj);
      break;
    case 'b':
      A = read_bbm_matrix(filename);
      break;
    default:
      fprintf(stderr, "Error: Invalid informat %c\n", informat);
      exit(BASSO_EXIT_INVALID_PARAMETER);
      break;
  }
  if (A == NULL) {
    exit(BASSO_EXIT_IOERROR);
  }
  if (verbosity_flag) fprintf(stderr, "done.\n");
  
  return A;
}

void
bprod()
{
  basso_matrix_t *L, *R, *P;
  basso_majority_t majority;
  
  if (n_infiles != 2) {
    fprintf(stderr, "Error: Exactly two input files must be given for computing the Boolean product ('-p')\n");
    exit(BASSO_EXIT_INVALID_PARAMETER);
  }
  
  if (verbosity_flag) fprintf(stderr, "Computing the product of %s and %s\n", infile_list[0], infile_list[1]);
  /* Read the factor matrices */
  L = read_factor_matrix(infile_list[0], BASSO_ROW_MAJ);
  R = read_factor_matrix(infile_list[1], BASSO_COL_MAJ);
  
  /* Sanity check */
  if (L->cols != R->rows) {
    fprintf(stderr, "Error: Matrix dimensions do not agree (left has %llu columns, right has %llu rows)\n",
            L->cols, R->rows);
    exit(BASSO_EXIT_INVALID_PARAMETER);
  }
  
  /* What's the output majority? */
  switch (outmajority) {
    case 0:
      // fall-through to column majority
    case 'c':
      majority = BASSO_COL_MAJ;
      break;
    case 'r':
      majority = BASSO_ROW_MAJ;
      break;
    default:
      fprintf(stderr, "Error: invalid output majority %c, aborting\n", outmajority);
      exit(BASSO_EXIT_INVALID_PARAMETER);
      break;
  }
  
  if (verbosity_flag) fprintf(stderr, "\tComputing the product...\t");
  /* Allocate P */
  errno = 0;
  P = basso_m_alloc(L->rows, R->cols, majority);
  if (P == NULL) {
    fprintf(stderr, "Cannot allocate memory for the product matrix: %s\n",
            strerror(errno));
    exit(BASSO_EXIT_MEMORY);
  }
  
  /* Do the product */
  errno = 0;
  int retval = basso_m_bprod(L, R, P);
  if (retval) {
    fprintf(stderr, "Error: failed to compute the Boolean product: %s\n",
            strerror(errno));
    exit(BASSO_EXIT_INVALID_PARAMETER);
  }
  
  basso_m_free(L);
  basso_m_free(R);
  
  /* Write the output */
  if (verbosity_flag) fprintf(stderr, "done.\n\tWriting to %s...\t", (outfile_given)?outfile:stdout_str);
  
  if (outformat == 0) {
    if (informat_given) outformat = informat;
    else if (infer_format(infile_list[0]) == infer_format(infile_list[1])) outformat = infer_format(infile_list[0]);
    else outformat = 'm';
  }
  
  char *comments;
  switch (outformat) {
    case 'b':
      retval = write_bbm_matrix((outfile_given)?outfile:stdout_str, P);
      if (retval != 0) exit(BASSO_EXIT_IOERROR);
      break;
    case 'm':
      // fall-through to default
    default:
      comments = mm_comments(BPROD_COMMENT);
      retval = write_mm_matrix((outfile_given)?outfile:stdout_str, P, comments);
      if (retval != 0) exit(BASSO_EXIT_IOERROR);
      free(comments);
      break;
  }
  if (verbosity_flag) fprintf(stderr, "done.\n");
  
  basso_m_free(P);
}

void
diff()
{
  basso_matrix_t *A, *B;
  FILE *fp = NULL;
  
  if (n_infiles > 2 || n_infiles == 0) {
    fprintf(stderr, "Error: One or two input files must be given for computing the difference ('-d')\n");
    exit(BASSO_EXIT_INVALID_PARAMETER);
  } else if (n_infiles == 2) {
    /* Read the matrices */
    A = read_factor_matrix(infile_list[0], BASSO_COL_MAJ);
    B = read_factor_matrix(infile_list[1], BASSO_COL_MAJ);
  } else { /* n_infiles == 1 */
    /* Read the matrices */
    A = read_factor_matrix(infile_list[0], BASSO_COL_MAJ);
    B = read_factor_matrix("-", BASSO_COL_MAJ);
  }
  
  /* Sanity check */
  if (A->cols != B->cols || A->rows != B->rows) {
    fprintf(stderr, "Error: Matrix dimensions do not agree (first is %llu-by-%llu, second is %llu-by-%llu)\n",
            A->rows, A->cols, B->rows, B->cols);
    exit(BASSO_EXIT_INVALID_PARAMETER);
  }

  if (verbosity_flag) fprintf(stderr, "Computing the product of %s and %s...", infile_list[0],
                              (n_infiles==1)?"standard input":infile_list[1]);
  
  errno = 0;
  uint64_t difference = basso_m_diff(A, B);
  if (difference == ULLONG_MAX && errno != 0) {
    fprintf(stderr, "\nError when computing the difference: %s\n", strerror(errno));
    exit(BASSO_EXIT_INVALID_INPUT);
  }
  
  if (verbosity_flag) fprintf(stderr, " done.\n");

  
  if (outfile_given) {
    errno = 0;
    fp = fopen(outfile, "a");
    if (fp == NULL) {
      fprintf(stderr, "Error when opening file %s: %s\n", outfile, strerror(errno));
      goto fail;
    }
  } else {
    fp = stdout;
  }
  
  fprintf(fp, "%llu\n", difference);
  
fail:
  basso_m_free(A);
  basso_m_free(B);
  if (fp != stdout) fclose(fp);
}

int
main(int argc, char *argv[])
{
  /* If there's no command-line arguments, we just print version and exit */
  if (argc == 1) {
    print_version();
    return BASSO_EXIT_SUCCESS;
  }
  /* Parse command-line arguments to populate global variables */
  parse_commandline_arguments(argc, argv);

  
  /* Decide what to do */
  if (convert_flag) {
    convert();
  }
  else if (swap_flag) {
    swap();
  }
  else if (product_flag) {
    bprod();
  }
  else if (diff_flag) {
    diff();
  } else {
    fputs("Error: No action given\n", stderr);
    fprintf(stderr, "Use '%s --help' to see the potential actions\n", prog_name);
    return BASSO_EXIT_INVALID_PARAMETER;
  }
  
  return BASSO_EXIT_SUCCESS;
}


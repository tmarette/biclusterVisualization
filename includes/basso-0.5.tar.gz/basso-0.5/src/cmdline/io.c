#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <string.h>
#include <limits.h>
#include "bassodata.h"
#include "cmdline.h"
#include "mmio.h"


#define _BASSO_ERR_L 127

char *
mm_strerror(const int mmerror)
{
  //const unsigned ERR_L=127;
  static char errstr[_BASSO_ERR_L+1]; /* space for termination */
  const char *errorlist[] = {
    "MMIO could not read file",
    "MMIO saw premature EOF",
    "MMIO not MTX",
    "MMIO found no header",
    "MMIO saw unsupported type",
    "MMIO line too long",
    "MMIO could not write to file"
  };

  if (mmerror < 11 || mmerror > 17) strncpy(errstr, "Unknown MMIO error type", _BASSO_ERR_L);
  else strncpy(errstr, errorlist[mmerror-11], _BASSO_ERR_L);
  errstr[_BASSO_ERR_L] = '\0';
  
  return errstr;
}

int 
read_mm_matrix_header(const char *filename,size_t *rows,size_t *columns)
{
	MM_typecode mmtype;
	int irows, icolumns, nnz;
	FILE *fp = NULL;
	int mmerror;

	errno = 0;
	if (strcmp(filename, "-") == 0) {
		fp = stdin;
	} else {
		fp = fopen(filename, "r");
		if (fp == NULL) {
			fprintf(stderr, "Error when opening file %s: %s\n", filename, strerror(errno));
	      		goto fail;
		}
	}

	mmerror = mm_read_banner(fp, &mmtype);
	if (mmerror) {
		fprintf(stderr, "Error when reading file %s: %s\n", filename, mm_strerror(mmerror));
		goto fail;
	}

	if (!(!mm_is_complex(mmtype) && mm_is_matrix(mmtype) && mm_is_sparse(mmtype))) {
		fprintf(stderr, "Error: input file %s is not sparse Matrix Market matrix; type is: %s\n", filename, mm_typecode_to_str(mmtype));
		goto fail;
	}

	mmerror = mm_read_mtx_crd_size(fp, &irows, &icolumns, &nnz);
	if (mmerror) {
		fprintf(stderr, "Error when reading the size of the matrix in file %s: %s\n", filename, mm_strerror(mmerror));
		goto fail;
	}

	if (irows >= 0 && icolumns >= 0) {
		*rows = (size_t)irows;
		*columns = (size_t)icolumns;
	} else {
		fprintf(stderr, "Error: the matrix in file %s has negative dimensions (%d times %d)\n", filename, irows, icolumns);
		goto fail;
	}

	fclose(fp);
	return 0;
  
	/*
	* Branch here only in case of error
	*/
fail:
	if (fp != NULL && fp != stdin) fclose(fp);
	return 1;

}

int
fill_mm_matrix(const char *filename, basso_matrix_t * M)
{
	MM_typecode mmtype;
	int irows, icolumns, nnz;
	size_t rows, columns;
	FILE *fp = NULL;
	int mmerror;

	errno = 0;
	if (M == NULL) {
		fprintf(stderr, "Unable to fill the matrix from the file since the pointer to the matrix is null: %s", strerror(errno));
		goto fail;
	}

	errno = 0;
	if (strcmp(filename, "-") == 0) {
		fp = stdin;
	} else {
		fp = fopen(filename, "r");
		if (fp == NULL) {
			fprintf(stderr, "Error when opening file %s: %s\n", filename, strerror(errno));
			goto fail;
		}
	}
	mmerror = mm_read_banner(fp, &mmtype);
	if (mmerror) {
		fprintf(stderr, "Error when reading file %s: %s\n", filename, mm_strerror(mmerror));
		goto fail;
	}

	if (!(!mm_is_complex(mmtype) && mm_is_matrix(mmtype) && mm_is_sparse(mmtype))) {
		fprintf(stderr, "Error: input file %s is not sparse Matrix Market matrix; type is: %s\n", filename, mm_typecode_to_str(mmtype));
		goto fail;
	}

	mmerror = mm_read_mtx_crd_size(fp, &irows, &icolumns, &nnz);
	if (mmerror) {
		fprintf(stderr, "Error when reading the size of the matrix in file %s: %s\n", filename, mm_strerror(mmerror));
		goto fail;
	}

	if (irows >= 0 && icolumns >= 0) {
		rows = (size_t)irows;
		columns = (size_t)icolumns;
	} else {
		fprintf(stderr, "Error: the matrix in file %s has negative dimensions (%d times %d)\n", filename, irows, icolumns);
		goto fail;
	}



	/*
	* Set-up is done
	*/
	for(int i=0; i < nnz; i++) {
		unsigned r, c;
		int scan_out;
		if (mm_is_pattern(mmtype)) {
			scan_out = fscanf(fp, "%u %u\n", &r, &c);
		} else {
			scan_out = fscanf(fp, "%u %u %*512s\n", &r, &c);
		}
		if (scan_out == EOF) {
			fprintf(stderr, "Error when reading file %s: Unexpected EOF\n", filename);
			goto fail;
		} else if (scan_out != 2) {
			fprintf(stderr, "Error while reading entry %d of file %s\n", i+1, filename);
			goto fail;
		} else if (r > rows || c > columns) {
			fprintf(stderr, "Error while reading file %s: Index (%u, %u) out of bounds\n", filename, r, c);
			goto fail;
		}
		basso_m_set_val(M, r-1, c-1, 1); /* Correct for 0-based indices */
		if (mm_is_symmetric(mmtype) || mm_is_skew(mmtype)) {
			basso_m_set_val(M, c-1, r-1, 1); /* Set the symmetric values */
		}
	}

	/*
	* All done, do clean exit
	*/
	fclose(fp);
	return 0;
  
	/*
	* Branch here only in case of error
	*/
fail:
	if (fp != NULL && fp != stdin) fclose(fp);
	return 1;
}



basso_matrix_t *
read_mm_matrix(const char *filename, const basso_majority_t majority)
{
  basso_matrix_t *M = NULL;
  MM_typecode mmtype;
  int irows, icolumns, nnz;
  size_t rows, columns;
  FILE *fp = NULL;
  int mmerror;

  errno = 0;
  if (strcmp(filename, "-") == 0) {
    fp = stdin;
  } else {
    fp = fopen(filename, "r");
    if (fp == NULL) {
      fprintf(stderr, "Error when opening file %s: %s\n", filename, strerror(errno));
      goto fail;
    }
  }
  mmerror = mm_read_banner(fp, &mmtype);
  if (mmerror) {
    fprintf(stderr, "Error when reading file %s: %s\n", filename, mm_strerror(mmerror));
    goto fail;
  }

  if (!(!mm_is_complex(mmtype) && mm_is_matrix(mmtype) && mm_is_sparse(mmtype))) {
    fprintf(stderr, "Error: input file %s is not sparse Matrix Market matrix; type is: %s\n", filename, mm_typecode_to_str(mmtype));
    goto fail;
  }

  mmerror = mm_read_mtx_crd_size(fp, &irows, &icolumns, &nnz);
  if (mmerror) {
    fprintf(stderr, "Error when reading the size of the matrix in file %s: %s\n", filename, mm_strerror(mmerror));
    goto fail;
  }

  if (irows >= 0 && icolumns >= 0) {
    rows = (size_t)irows;
    columns = (size_t)icolumns;
  } else {
    fprintf(stderr, "Error: the matrix in file %s has negative dimensions (%d times %d)\n", filename, irows, icolumns);
    goto fail;
  }

  M = basso_m_alloc(rows, columns, majority);
  if (M == NULL) {
    fprintf(stderr, "Error when allocating space for the %zu-by-%zu matrix: %s", rows, columns, strerror(errno));
    goto fail;
  }


  /*
   * Set-up is done
   */
  for(int i=0; i < nnz; i++) {
    unsigned r, c;
    int scan_out;
    if (mm_is_pattern(mmtype)) {
      scan_out = fscanf(fp, "%u %u\n", &r, &c);
    } else {
      scan_out = fscanf(fp, "%u %u %*512s\n", &r, &c);
    }
    if (scan_out == EOF) {
      fprintf(stderr, "Error when reading file %s: Unexpected EOF\n", filename);
      goto fail;
    } else if (scan_out != 2) {
      fprintf(stderr, "Error while reading entry %d of file %s\n", i+1, filename);
      goto fail;
    } else if (r > rows || c > columns) {
      fprintf(stderr, "Error while reading file %s: Index (%u, %u) out of bounds\n", 
	      filename, r, c);
      goto fail;
    }
    basso_m_set_val(M, r-1, c-1, 1); /* Correct for 0-based indices */
    if (mm_is_symmetric(mmtype) || mm_is_skew(mmtype)) {
      basso_m_set_val(M, c-1, r-1, 1); /* Set the symmetric values */
    }
  }

  /*
   * All done, do clean exit
   */
  fclose(fp);
  return M;
  
  /*
   * Branch here only in case of error
   */
 fail:
  basso_m_free(M);
  if (fp != NULL && fp != stdin) fclose(fp);
  return NULL;
}

int
write_mm_matrix_header(FILE *restrict fp,
                       const char *restrict filename,
                       const char *restrict comments,
                       const uint64_t       rows,
                       const uint64_t       cols,
                       const uint64_t       nnz)
{
  MM_typecode mattype;
  int mmerror, retcode;
  
  /* Set typecode to sparse pattern matrix */
  mm_initialize_typecode(&mattype);
  mm_set_matrix(&mattype);
  mm_set_sparse(&mattype);
  mm_set_pattern(&mattype);

  mmerror = mm_write_banner(fp, mattype);
  if (mmerror) {
    fprintf(stderr, "Error when writing the banner to file %s: %s\n", filename, mm_strerror(mmerror));
    retcode = BASSO_RETURN_IOFAIL;
    goto cleanup;
  }

  if (comments != NULL) {
    errno = 0;
    if(fprintf(fp, "%s\n", comments) < 0) {
      fprintf(stderr, "Error when writing comments to file %s: %s\n", filename, strerror(errno));
      retcode = BASSO_RETURN_IOFAIL;
      goto cleanup;
    }
  }

  /* Check that the matrix size can be represented with ints */
  if (rows > INT_MAX || cols > INT_MAX || nnz > INT_MAX) {
    fprintf(stderr, 
	    "Matrix size is too big to be stored in MatrixMarket format " \
	    "(%llu times %llu matrix with %llu non-zeros versus the maximum " \
	    "of %d times %d with %d non-zeros)\n", 
	    rows, cols, nnz, INT_MAX, INT_MAX, INT_MAX);
    retcode = BASSO_RETURN_INVALID_INPUT;
    goto cleanup;
  }

  /* Write the size */
  errno = 0;
  if (fprintf(fp, "%llu %llu %llu\n", rows, cols, nnz) < 0) {
    fprintf(stderr, "Error when writing the matrix size to file %s: %s\n", filename, strerror(errno));
    retcode = BASSO_RETURN_IOFAIL;
    goto cleanup;
  }

  /* No errors */
  retcode = BASSO_RETURN_SUCCESS;

 cleanup: /* Actually, there's no cleanup to be done */
  return retcode;

}

int
write_mm_matrix(const char           *restrict filename,
                const basso_matrix_t *restrict M,
                const char           *restrict comments)
{
  FILE *fp = NULL;
  int retcode;
  uint64_t nnz;

  if (filename == NULL || M == NULL || comments == NULL) {
    retcode = BASSO_RETURN_INVALID_INPUT;
    goto cleanup;
  }
  
  if (strcmp(filename, "-") == 0) {
    fp = stdout;
  } else {
    fp = fopen(filename, "w");
    if (fp == NULL) {
      fprintf(stderr, "Error when opening file %s: %s\n", filename, strerror(errno));
      retcode = BASSO_RETURN_IOPERM;
      goto cleanup;
    }
  }


  nnz = basso_m_nnz(M);

  retcode = write_mm_matrix_header(fp, filename, comments, M->rows, M->cols, nnz);
  if (retcode != BASSO_RETURN_SUCCESS) goto cleanup;


  /* 
   * Write the actual matrix as a pattern with 1-based indexing
   */
  errno = 0;
  if (M->majority == BASSO_ROW_MAJ) {
    for (uint64_t i=0; i < M->rows; i++) {
      for (uint64_t j=0; j < M->cols; j++) {
        if (basso_m_get_val(M, i, j)) {
          if (fprintf(fp, "%llu %llu\n", i+1, j+1) < 0) {
            fprintf(stderr, "Error when writing element (%llu, %llu) to file %s: %s\n",
                    i, j, filename, strerror(errno));
            retcode = BASSO_RETURN_IOFAIL;
            goto cleanup;
          }
        }
      }
    }
  } else { /* if M->majority == BASSO_ROW_MAJ */
    for (uint64_t j=0; j < M->cols; j++) {
      for (uint64_t i=0; i < M->rows; i++) {
        if (basso_m_get_val(M, i, j)) {
          if (fprintf(fp, "%llu %llu\n", i+1, j+1) < 0) {
            fprintf(stderr, "Error when writing element (%llu, %llu) to file %s: %s\n",
                    i, j, filename, strerror(errno));
            retcode = BASSO_RETURN_IOFAIL;
            goto cleanup;
          }
        }
      }
    }
  }

  /* Successful ending */
  retcode = BASSO_RETURN_SUCCESS;

  /*
   * Do cleanup with or without successful ending
   */
 cleanup:
  if (fp != NULL && fp != stdout && fp != stderr) fclose(fp);
  return retcode;
}



/*
 * The format for Basso binary matrix is 
 * <uint64_t MAGIC and FLAGS><uint64_t ROWS><uint64_t COLS><basso_elem_t DATA1>...
 * MAGIC should be read as eight char's. First six of them have ASCII values of
 * b, a, s, s, o, and '\0', next is reserved for future use and must be zero, and the LSB of the
 * last byte is 1 if the matrix is in row-major format, and 0 otherwise, while other
 * bits are resrved for future use and must be 0. 
 * ROWS and COLS are read as-is, and after them, comes the data. The data is exactly as in 
 * memory, with the padding.
 */


static inline basso_bbm_header *
init_bbm_header(basso_majority_t majority, uint64_t rows, uint64_t cols)
{
  static basso_bbm_header header = {"basso", 0, 0, 0, 0};
  if (majority == BASSO_ROW_MAJ) header.flags = 1;
  header.rows = rows;
  header.cols = cols;
  return &header;
}

/*
 * Validates if the header is valid. Returns BASSO_RETURN_INVALID_INPUT if not.
 */
static inline int
validate_bbm_header(const basso_bbm_header *header)
{
  /* magic bytes */
  if (strcmp(header->magic, "basso") != 0) {
    fprintf(stderr, "Invalid binary file: the magic byte is wrong\n");
    return BASSO_RETURN_INVALID_INPUT;
  }
  
  /* reserved must be 0 */
  if (header->reserved != 0) {
    fprintf(stderr, "Invalid binary file: the reserved byte must be zero\n");
    return BASSO_RETURN_INVALID_INPUT;
  }
  
  /* except the LSB, the flags must be all-zero */
  if ((header->flags & 0xFE) != 0) {
    fprintf(stderr, "Invalid binary file: the reserved flags must be zero\n");
    return BASSO_RETURN_INVALID_INPUT;
  }
  
  /* All values of rows and cols are valid, hence the header is valid */
  
  return BASSO_RETURN_SUCCESS;
}

static inline int
write_bbm_header(const basso_bbm_header *header, FILE *fp)
{
  if (fwrite(header->magic, 1, 6, fp)                    != 6) return 0;
  if (fwrite(&(header->reserved), 1, 1, fp)              != 1) return 0;
  if (fwrite(&(header->flags), 1, 1, fp)                 != 1) return 0;
  if (fwrite(&(header->rows), sizeof(uint64_t), 1, fp)   != 1) return 0;
  if (fwrite(&(header->cols), sizeof(uint64_t), 1, fp)   != 1) return 0;
  return 1;
}

/*
 * Reads the binary header and returns a pointer. 
 * Requires the stream to be at the begin.
 * Non-reentrant, do not call from different threads.
 * Does not quarantee that the resulting header is valid.
 * Returns NULL if it cannot read enough bytes. 
 * Leaves the stream at the first byte after the header.
 */

static inline basso_bbm_header *
read_bbm_header(FILE *fp) {
  static basso_bbm_header header = {"basso", 0, 0, 0, 0};
  char magic[6];
  char reserved;
  char flags;
  uint64_t dims[2];


  if (fread(magic, 1, 6, fp) != 6) {
    return NULL;
  }

  strncpy(header.magic, magic, 6);

  /* Get the reserved char */
  if (fread(&reserved, 1, 1, fp) != 1) return NULL;
  header.reserved = reserved;

  /* Read flags */
  if (fread(&flags, 1, 1, fp) != 1) return NULL;
  header.flags = flags;

  /* Read the dimensions */
  if (fread(dims, sizeof(uint64_t), 2, fp) != 2) return NULL;
  header.rows = dims[0];
  header.cols = dims[1];

  return &header;
}

int
write_bbm_matrix(const char           *restrict filename,
                 const basso_matrix_t *restrict M)
{
  FILE *fp;
  int retcode;
  basso_bbm_header *header;
  size_t elements;
  


  if (strcmp(filename, "-") == 0) {
    fp = stdout;
  } else {
    fp = fopen(filename, "w");
    if (fp == NULL) {
      fprintf(stderr, "Error when opening file %s: %s\n", filename, strerror(errno));
      retcode = BASSO_RETURN_IOFAIL;
      goto cleanup;
    }
  }
 
  errno = 0;
  /* Write header */
  header = init_bbm_header(M->majority, M->rows, M->cols);
  if (!write_bbm_header(header, fp)) {
    fprintf(stderr, "Error when writing the binary header to file %s: %s\n", filename, strerror(errno));
    retcode = BASSO_RETURN_IOFAIL;
    goto cleanup;
  }
  
  
  /* Write data... */
  /* Expects size_t to be big enough, but this must be the case because we could allocate it... */
  if (M->majority == BASSO_ROW_MAJ) {
    elements = M->rows * M->elem_per_vect;
  } else {
    elements = M->cols * M->elem_per_vect;
  }
  if (fwrite(M->data, sizeof(basso_elem_t), elements, fp) != elements) {
    fprintf(stderr, "Error when writing the binary data to file %s: %s\n", filename, strerror(errno));
    retcode = BASSO_RETURN_IOFAIL;
    goto cleanup;
  }

  retcode = BASSO_RETURN_SUCCESS;
  
cleanup:
  if (fp != NULL && fp != stdout) fclose(fp);
  return retcode;
}

basso_matrix_t *
read_bbm_matrix(const char *filename)
{
  basso_matrix_t *M = NULL;
  basso_bbm_header *header;
  int is_rm, retcode;
  FILE *fp;
  
  if (strcmp(filename, "-") == 0) {
    fp = stdin;
  } else {
    fp = fopen(filename, "rb");
    if (fp == NULL) {
      fprintf(stderr, "Error when opening file %s: %s\n", filename, strerror(errno));
      goto cleanup;
    }
  }
  
  /* Read the header and validate it */
  header = read_bbm_header(fp);
  if (header == NULL || validate_bbm_header(header) != BASSO_RETURN_SUCCESS) {
    fprintf(stderr, "Cannot read the binary header from file %s\n", filename);
    goto cleanup;
  }
  
  /* Check the majority and allocate the memory */
  is_rm = header->flags;
  
  errno = 0;
  if (is_rm) {
    M = basso_m_alloc(header->rows, header->cols, BASSO_ROW_MAJ);
  } else {
    M = basso_m_alloc(header->rows, header->cols, BASSO_COL_MAJ);
  }
  if (M == NULL) {
    fprintf(stderr, "Cannot allocate memory for the binary matrix in file %s: %s\n",
            filename, strerror(errno));
    goto cleanup;
  }

  /* Read the data... */
  size_t elem_to_read;
  size_t r;
  errno = 0;
  if (is_rm) {
    elem_to_read = M->rows * M->elem_per_vect;
  } else {
    elem_to_read = M->cols * M->elem_per_vect;
  }
  r = fread(M->data, sizeof(basso_elem_t), elem_to_read, fp);
  if (r < elem_to_read) {
    if (feof(fp))
      fprintf(stderr, "End of file met before reading file %s was complete\n", filename);
    else
      fprintf(stderr, "Error when reading file %s: %s\n", filename, strerror(errno));
    basso_m_free(M);
    M = NULL;
    goto cleanup;
  }

cleanup:
  if (fp != NULL && fp != stdin) fclose(fp);
  return M;
}


char *
b_strdup(const char *restrict str)
{
  size_t n = strlen(str) + 1;
  char *dup = malloc(n);
  if (dup == NULL) {
    fprintf(stderr, "Error when allocating memory to duplicate string: %s", strerror(errno));
    exit(BASSO_EXIT_MEMORY);
  }
  memcpy(dup, str, n);
  return dup;
}



char *
get_file_suffix(const char *restrict filename)
{
  char *str, *token, *newtoken;
  const char delimiters[] = ".";
  
  /* We need a writable copy */
  str = b_strdup(filename);
  /* First, remove anything before the first delimiter (if any) */
  strtok(str, delimiters);
  newtoken = strtok(NULL, delimiters);
  do {
    token = newtoken;
  } while ((newtoken = strtok(NULL, delimiters)) != NULL);
  
  if (token != NULL) {
    /* We need to allocate new memory that we return to make sure it can be freed */
    char *out = b_strdup(token);
    token = out;
  }
  free(str);
  
  return token;
}


char *
strip_file_suffix(const char *restrict filename)
{
  char *suffix = get_file_suffix(filename);
  char *out = b_strdup(filename);
  
  if (suffix != NULL) {
    size_t n = strlen(suffix);
    size_t m = strlen(filename);
    out[m-n-1] = '\0'; // -1 to overwrite the dot
  }
  
  free(suffix);
  
  return out;
}

int
infer_format(const char *filename)
{
  char *suffix = NULL;
  int format = 0;
  if (!strcmp(filename, "-")) goto fail;
  suffix = get_file_suffix(filename);
  if (suffix == NULL) goto fail;
  if (is_suffix_matrixmarket(suffix)) format = 'm';
  else if (is_suffix_bassobinary(suffix)) format = 'b';
  else goto fail;
  
  free(suffix);
  return format;
  
fail:
  free(suffix);
  /*
  fprintf(stderr, "Cannot infer the file format from the filename %s\n"
          "You must give the format explicitly (-f)\n", filename);
   */
  return -1;
}

/* 
 * basso_strto.c
 *
 * Helper functions to convert strings to number or exit in failure
 *
 */
#ifdef HAVE_COFIG_H
#  include "config.h"
#endif
#include "basso_strto.h"
#include <stdlib.h>
#include <stdio.h>
#include <errno.h>
#include <string.h>
#include <ctype.h> // needed for isdigit and isspace for strtod_r
#include <math.h>  // needed for HUGE_VAL

#ifndef HUGE_VAL
#  define HUGE_VAL 9999999999.0
#endif

/* Naive replacement for strtod for systems with no or broken strtod.
 * Will not work well for very large or very small numbers -- should only be used when this is not a problem.
 * Cannot handle infinity or NAN input
 */
double
strtod_r(const char *str, char **endptr)
{
  int i = 0;
  double val = 0.0;
  int negative = 0;
  int digits_read = 0;
  int exponent = 0;
  int tmp_exp = 0;
  const double d10 = 10.0;
  
  // Get rid of starting whitespace
  while (isspace(str[i])) i++;
  
  // Check for sign
  switch (*str) {
    case '-': negative = 1; // fall-through to case '+'
    case '+': i++;
  }
  
  // Read until the decimal or end
  while (isdigit(str[i])) {
    val = val*d10 + (str[i] - '0');
    i++;
    digits_read++;
  }
  
  if (str[i] == '.') {
    // Deal with decimal part
    i++;
    while (isdigit(str[i])) {
      val = val*d10 + (str[i] - '0');
      i++;
      exponent--;
      digits_read++;
    }
  }
  
  // If we haven't yet read any digits, the input is invalid
  if (digits_read == 0) {
    fprintf(stderr, "STRTOD_R: Did not read any digits!\n");
    errno = ERANGE;
    if (endptr) *endptr = (char *)(str + i);
    return 0.0;
  }
  
  // Get the sign correct
  if (negative) val = -val;
  
  // Get the potential exponent
  if (str[i] == 'e' || str[i] == 'E') {
    // Deal with the sign
    negative = 0;
    i++;
    switch (str[i]) {
      case '-': negative = 1; // fall-through
      case '+': i++;
    }
    // Read the numbers
    while (isdigit(str[i])) {
      tmp_exp = tmp_exp*10 + (str[i] - '0');
      i++;
    }
    if (negative) exponent -= tmp_exp;
    else          exponent += tmp_exp;
  }
  
  if (exponent < -15 || 15 < exponent ) {
    fprintf(stderr, "STRTOD_R: exponent %d is too large!\n", exponent);
    errno = ERANGE;
    if (endptr) *endptr = (char *)(str + i);
    return HUGE_VAL;
  }
  
  // Scale the value properly
  // At most one of these while-loops will ever run
  while (exponent < 0) {
    val /= d10;
    exponent++;
  }
  while (exponent > 0) {
    val *= d10;
    exponent--;
  }
  
  if (val == HUGE_VAL) errno = ERANGE;
  if (endptr) *endptr = (char *)(str + i);
  
  return val;
}

/* See if we have to use strtod_r
 * Notice that we use atof if it's present but strtod is not
 * unless USE_STRTOD_R is defined (via --disable-std_strtod configure option)
 */
#if !(defined HAVE_STRTOD || defined HAVE_ATOF) || defined USE_STRTOD_R
#  define strtod strtod_r
#  define HAVE_STRTOD_R
#  warning "Using replacement strtod"
#endif

uint64_t
strtoullOrExit(const char *restrict str, const char *restrict what)
{
      char *tailptr;
      int64_t out; // We use signed integers to catch negative values
      errno = 0;

#ifdef HAVE_STRTOLL
      out = strtoll(str, &tailptr, 10);
      if (tailptr[0] != '\0') {
	fprintf(stderr, "Error when setting the %s: Cannot convert string \"%s\" to an unsigned integer\n", what, tailptr);
	exit(BASSO_EXIT_INVALID_PARAMETER);
      }
#else
#  ifdef HAVE_ATOLL
      out = atoll(str);
#  else
#    error "Your system does not support conversions from strings to 64-bit integers"
#  endif /* HAVE_ATOLL */
#endif /* HAVE_STRTOULL */
      if (errno != 0) {
	fprintf(stderr, "Error when setting the %s: %s\n", what, strerror(errno));
	exit(BASSO_EXIT_INVALID_PARAMETER);
      }

      if (out < 0) {
	fprintf(stderr, "Error when setting the %s: %s is a negative number\n",
		what, str);
	exit(BASSO_EXIT_INVALID_PARAMETER);
      }

      return out;
}

int
strtolOrExit(const char *restrict str, const char *restrict what)
{
      char *tailptr;
      int out;
      errno = 0;

#ifdef HAVE_STRTOL
      out = strtol(str, &tailptr, 10);
      if (tailptr[0] != '\0') {
	fprintf(stderr, "Error when setting the %s: Cannot convert string \"%s\" to an integer\n", what, tailptr);
	exit(BASSO_EXIT_INVALID_PARAMETER);
      }
#else
#  ifdef HAVE_ATOI
      out = atoi(str);
#  else
#    error "Your system does not support conversions from strings to integers"
#  endif /* HAVE_ATOI */
#endif /* HAVE_STRTOL */

      if (errno != 0) {
	fprintf(stderr, "Error when setting the %s: %s\n", what, strerror(errno));
	exit(BASSO_EXIT_INVALID_PARAMETER);
      }
      return out;
}

double
strtodOrExit(const char *restrict str, const char *restrict what)
{
      char *tailptr;
      double out;
      errno = 0;

#if defined HAVE_STRTOD || defined HAVE_STRTOD_R
      out = strtod(str, &tailptr);
      if (tailptr[0] != '\0') {
	fprintf(stderr, "Error when setting the %s: Cannot convert string \"%s\" to double\n", what, tailptr);
	exit(BASSO_EXIT_INVALID_PARAMETER);
      }
#else
#  ifdef HAVE_ATOF
      out = atof(str);
#  else
#    error "Your system does not support conversion of strings to floats"
#  endif /* HAVE_ATOF */
#endif /* HAVE_STRTOD*/

      if (errno != 0) {
	fprintf(stderr, "Error when setting the %s: %s\n", what, strerror(errno));
	exit(BASSO_EXIT_INVALID_PARAMETER);
      }
      return out;
}


//Fixme: Add a config for strtok fucntion
int
strToDblListOrExit(const char *restrict str, const char *restrict what, const char * delimiter, double *list,uint64_t *list_len)
{
	if(list == NULL || list_len == NULL) {
		errno = EINVAL;
		return 1;
	}

	char *pch,*tailptr;
	double *out;

	/* Make a copy of str as strtok modifies it */
	char *str_cpy = malloc(strlen(str)+1);
	if (str_cpy == NULL) {
	  exit(BASSO_EXIT_MEMORY);
	}
	strcpy(str_cpy, str);
	
	
	*list_len = 0;
	pch = strtok(str_cpy,delimiter);
	while (pch != NULL) {
		double value = strtod(pch, &tailptr);

		if (tailptr[0] != '\0') {
			fprintf(stderr, "Error when setting the %s: Cannot convert string \"%s\" to double\n", what, tailptr);
			exit(BASSO_EXIT_INVALID_PARAMETER);
		}
		list[*list_len] = value;
		(*list_len)++;

		pch = strtok(NULL, delimiter);

	}

	return 0;
}

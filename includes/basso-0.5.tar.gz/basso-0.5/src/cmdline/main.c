#ifdef HAVE_CONFIG_H
#  include "config.h"
#endif

#include <stdio.h>
#include <stdlib.h>
#include <getopt.h>
#include <errno.h>
#include <string.h>
#include <signal.h>
#ifdef HAVE_CLOCK_GETTIME
#  include <time.h>
#else
#  ifdef __MACH__
#    include <sys/time.h>
#    define CLOCK_REALTIME 0 
#    define CLOCK_MONOTONIC 0
#  endif /* __MACH__ */
#endif /* HAVE_CLOCK_GETTIME */
#ifdef _OPENMP /*We might want to avoid OpenMP */
#  include <omp.h>
#else
#  define omp_set_num_threads(a) fprintf(stderr, "Warning: Basso was compiled on a system with no OpenMP support. Setting the number of threads has no effect.\n")
#endif /* _OPENMP */

#include "cmdline.h"
#include "basso_strto.h"
#include "basso.h"

#ifdef HAVE_CUDA
#  include "basso_cu.h"
#endif

/*
 * Global variables to store the command-line arguments.
 * All parameters set by command-line arguments are here for consistency.
 */

static int        output_flag                 = 1;    // should we print the factors (--no-output)
static char      *outfile                     = NULL; // filename template for output data (-o)
static char       informat                    = 0;    // the format is either 'm' for MatrixMarket of 'b' for binary
static char       outformat                   = 0;    // or 0 for unknown (-f and -F)
static size_t     n_infiles                   = 0;    // number of input files
static char     **infile_list                 = NULL; // A list of input file names
static char      *infile                      = NULL; // filename for current input data, set in main()

static uint64_t   rank                        = 0;    // The rank of the decomposition (-k)
static uint64_t   weight                      = 1;    // The bias weight (-w)
static int        processes                   = -1;   // Number of threads (-j);
// non-positive numbers mean default behavior of OpenMP
static int        cuda_flag                   = 0;    // should we use CUDA
static uint64_t   update_step                 = 0;    // Updating founded factors after update_step of finding factors out of k factors
static int        ext_cand_flag 	            = 0;    // add columns of original matrix as candidates for basis-selection phase
static double    *thresholds                  = NULL; // List of thresholds (-t)
static uint64_t   thresholds_len              = 0;    // Length of thresholds_list
static char      *thresholds_str              = NULL; // The thresholds in string format
static uint64_t   zero_cover_weight           = 1;    // The weight that penalizes the score of covering 0s (-z)
static double     zcw_modify_step             = 1.0;  // The weight which modifies the zero_cover_weight
static uint64_t   iterative_update            = 0;    // The number of iterative update of factor matrices.
static int        print_mid_error 	          = 0;	  // The flag to print reconstruction error between finding each factor
static uint64_t   update_candidates_step      = 0;    //The step to update association matrix (update candidates)
static int        symmetrical_decompose       = 0;    // The flag to decompose the original matrix symmetrically.
static int        optimized_computation       = 1;    // The flag to run optimized algorithm to find factors efficiently
static int        remove_duplicates_cand      = 1;    //The flag to remove duplicate candidates from association matrix
static int        use_candidates_overlap_alg  = 1;    //The flag to use candidates_overlap_algorithm and boost the performance

static int        version_flag                = 0;    // should we print the version string
static int        verbosity_flag              = 0;    // should we print output (--verbose)
static int        clock_flag                  = 0;    // should timing information be printed (-c)
static char      *clock_outfile               = NULL; // file for storing the timing information
static int        err_flag                    = 0;    // should reconstruction error be computed and printed (-e)
static char      *err_outfile                 = NULL; // file for storing the reconstruction error

/* The maximum number of different threshold values */
#define MAX_THRESHOLDS_LEN 256

/* Global variable for checking if we've received SIGTERM or SIGINT */
static volatile sig_atomic_t terminate_signal_received = 0;

enum {
  TIME_INPUT_START = 0,
  TIME_INPUT_DONE,
  TIME_ASSOC_START,
  TIME_ASSOC_DONE,
  TIME_BASIS_START,
  TIME_BASIS_DONE,
  TIME_OUTPUT_START,
  TIME_OUTPUT_DONE
};

/*
 * Static functions
 */

static void
print_help(const char *programName)
{
  fprintf(stdout,
          "Decompose Boolean matrix INPUT using the Asso algorithm.\n"
          "\n"
          "Usage: %s -k RANK -t THR [OPTIONS] [-o OUTPUT] [INPUT]\n"
          "\n",
          programName);
  puts("Options:\n"
       "  -k, --rank=RANK      		  set the rank of the factorization\n"
       "  -t, --thresholds=TRH   	  set the rounding threshold(s) from [0, 1]. Separate thresholds with ','\n"
       "  -w, --weight=WEIGHT  		  set the bias weight\n"
       "  -f, --format=FMT     		  set the file format; \"m\" means MatrixMarket and \"b\" binary format.\n"
       "                       		  This is used for input and output unless \"-F\" is also given.\n"
       "  -F, --outformat=FMT  		  set the output file format to FMT\n"
       "  -j, --processes[=N]  		  set the number of parallel processes;\n"
       "                       		  if no parameter is given, forces using OpenMP's default behaviour\n"
       "      --use-gpu        		  use the GPU instead of CPU (has to be	compiled with --with-cuda)\n"
       "  -I, --iterative-update     perform iterative update on both left and right matrices\n"
       "                             after finding all factors\n"
       "  -U, --update-step=US 		  set the step to update the factors\n"
       "  -E  --ext-candidates 		  add columns of original matrix as candidates\n"
       "  -z, --zero-cover-weight=ZC	set the weight to penalize the score of covering 0s\n"
       "  -Z, --zcw-modify-step=ZMS	set the weight to modify zero-cover-weight which\n"
       "  -R, --update-candidates=UC set the step size to schedule an update for association matrix (update candidates)"
       "                             based on the residual of original matrix"
       "  -S, --symmetric            symmetrical decomposition\n"
       "  -O, --optimized=1/0		    running optimized algorithm (Default is 1(active))\n"
       "  -D, --remove-duplicate=1/0 removing duplicate candidates from candidates (Default is 1 (active))\n"
       "  -C, --use-cand-overlap=1/0 using candidates overlap to boost the performance (Default is 1 (active))\n"
       "  -c, --clock[=FILE]   		  print timing information to FILE, if given, or to standard output\n"
       "  -e, --error[=FILE]   		  print reconstruction error to FILE or to\n"
       "      --print-mid-error      print reconstruction error after finding each factor standard output\n"
       "\n");
  puts("  -o, --output=FILE    		  set the output filename template\n"
       "      --no-output      		  do not print the factors\n"
       "\n");
  puts("      --verbose        		  print information to stderr\n"
       "      --quiet          		  suppress printing of information (default)\n"
       "\n");
  puts("  -h, --help           		  show this help and exit\n"
       "      --version        		  show the version information and exit\n"
       "\n"
       "\n");
  puts("Input:"
       "  The input file must in either sparse MatrixMarket format or\n"
       "  in binary format. If \"-f\" option is not given, the format\n"
       "  is guessed from the file extension such that \".mtx\"\n"
       "  denotes MatrixMarket files and \".bbm\" denotes binary files.\n"
       "  If no INPUT is given, or it is \"-\", the input is read from\n"
       "  standard input. In that case, \"-f\" option must be given.\n"
       "Output:\n"
       "  The \"-o\" option sets the output template. The final output files\n"
       "  are called <file>_L.<ext> and <file>_R.<ext> for left and right\n"
       "  factor matrix, respectively. Here, <file> is the argument for \"-o\",\n"
       "  and <ext> is either \"bbm\" or \"mtx\", depending on the output\n"
       "  format. The output format is the same as the input format unless\n"
       "  the \"-F\" option is used to override it. If \"-o\" is not given or\n"
       "  is \"-\", both factor matrices are written to the standard output.\n"
       "  Option \"-O\" surpresses any output of the factors.\n"
       "Timing:\n"
       "  If the \"-c\" option is given, the program prints timing results.\n"
       "  If no file is given in the argument, standard output is used.\n"
       "  Output is a row of 8 TAB separated numbers giving the start and\n"
       "  stop times in seconds starting from 0 for reading the input file,\n"
       "  computing the association matrix, building the factorization, and\n"
       "  writing the output. The times are wall-clock times.\n"
       "  N.B. The ouput is always appended to the file, not overwritten.\n"
       "Reconstruction error:\n"
       "  If the \"-e\" option is given, the program computes and prints\n"
       "  the reconstruction error. The error is the sum of disagreements,\n"
       "  that is, the Hamming distance betweeen the original and reconstructed\n"
       "  matrix. If file is given, the error is appended to that file.\n"
       "\n");
  fprintf(stdout,
          "Examples:\n"
          "  %s -k10 -t0.8 -o factor matrix.mtx\n"
          "                        decomposes MatrixMarket matrix to\n"
          "                        rank-10 decomposition and prints the\n"
          "                        output to factor_L.mtx and factor_R.mtx\n"
          "  %s -k10 -t0.8 -w2 -j10 -fm -Fb -o factor matrix.txt\n"
          "                        like above, but decomposition values\n"
          "                        covering 1s twice as much as not covering\n"
          "                        0s, 10 parallel threads are used, and the\n"
          "                        input is in MatrixMarket format, but the\n"
          "                        output is written in binary format\n"
          "  %s -k10 -t0.8 --no-output -ctimes.txt -eerror.txt matrix.mtx\n"
          "                        Stores the timing information to times.txt,\n"
          "                        the error on error.txt, and discards the output.\n"
          ,
          programName, // For example 1
          programName, // For example 2
          programName  // For example 3
          );
}

static void
print_version()
{
  fprintf(stdout,
          "%s command line interface %s\n"
          "Copyright (C) 2015--18 Ehsan Nadjaran Toosi, Stefan Neumann & Pauli Miettinen\n"
          "This software is licensed under the MIT license.\n"
          "This is free software: you are free to change and redistribute it.\n"
          "There is no warranty.\n"
          ,
          PACKAGE_NAME, PACKAGE_VERSION);
}



/*
 * Parses the command-line arguments and stores the results to global variables
 */

static int
parse_commandline_arguments(int argc, char *argv[])
{
  int c;
  
  /*
   * Parse command-line arguments
   */
  
  while (1) {
    // Arguments
    static struct option long_options[] =
    {
      {"output", required_argument, 0, 'o'},
      {"no-output", no_argument, &output_flag, 0},
      {"format", required_argument, 0, 'f'},
      {"outformat", required_argument, 0, 'F'},
      {"rank", required_argument, 0, 'k'},
      {"thresholds", required_argument, 0, 't'},
      {"weight", required_argument, 0, 'w'},
      {"processes", optional_argument, 0, 'j'},
      {"use-gpu", no_argument, &cuda_flag, 1},
      {"iterative-update", required_argument,0, 'I'},
      {"print-mid-error", no_argument, &print_mid_error, 1},
      {"update-step", required_argument, 0 , 'U'},
      {"update-candidates-step", required_argument, 0 , 'R'},
      {"zero-cover-weight", required_argument, 0,'z'},
      {"zcw-modify-step", required_argument, 0,'Z'},
      {"ext-candidates", no_argument, &ext_cand_flag, 1},
      {"symmetric", no_argument, &symmetrical_decompose, 1},
      {"optimized", required_argument, 0, 'O'},
      {"remove-duplicate", required_argument, 0, 'D'},
      {"use-cand-overlap", required_argument, 0, 'C'},
      {"clock", optional_argument, 0, 'c'},
      {"error", optional_argument, 0, 'e'},
      {"verbose", no_argument, &verbosity_flag, 1},
      {"quiet", no_argument, &verbosity_flag, 0},
      {"help", no_argument, 0, 'h'},
      {"version", no_argument, &version_flag, 1},
      {0, 0, 0, 0}
    };
    const char optionstring[] = "o:f:F:k:t:w:j:U:R:z:Z:c::e::h:E::O:D:C:I:S";
    int option_index = 0;
    
    c = getopt_long(argc, argv, optionstring, long_options, &option_index);
    
    if (c == -1) {
      // The end of options
      break;
    }
    
    switch (c) {
      case 0:
        /* Check if this is version option */
        if (!strcmp(long_options[option_index].name, "version")) {
          print_version();
          exit(BASSO_EXIT_SUCCESS);
        }
        /* No need to do anything for the verbosity flag */
        break;
      case 'h':
        print_help(argv[0]);
        exit(BASSO_EXIT_SUCCESS);
        
      case 'o':
        outfile = optarg;
        break;
        
      case 'f':
        informat = optarg[0];
        break;
        
      case 'F':
        outformat = optarg[0];
        break;
        
      case 'k':
        rank = strtoullOrExit(optarg, "rank");
        break;
        
      case 't':
        thresholds = (double *) malloc ( MAX_THRESHOLDS_LEN * sizeof(double));
        thresholds_str = (char *) malloc(strlen(optarg) * sizeof(char));
        strcpy(thresholds_str,optarg);
        if(thresholds == NULL)
        {
          fprintf(stderr, "Error when allocating memory for thresholds\n");
          exit(BASSO_EXIT_MEMORY);
        }
        strToDblListOrExit(optarg, "thresholds",",",thresholds,&thresholds_len);
        break;
        
      case 'w':
        weight = strtoullOrExit(optarg, "weight");
        break;
        
      case 'j':
        if (optarg != NULL) processes = strtolOrExit(optarg, "processes");
        else processes = -1;
        break;
        
      case 'c':
        clock_flag = 1;
        if (optarg != NULL) clock_outfile = optarg;
        break;
        
      case 'e':
        err_flag = 1;
        if (optarg != NULL) err_outfile = optarg;
        break;
        
      case 'U':
        if (optarg != NULL) {
          update_step = strtoullOrExit(optarg, "update-step");
        }
        else update_step = 0;
        break;
      case 'z':
        zero_cover_weight = strtoullOrExit(optarg, "zero-cover-weight");
        break;
      case 'Z':
        zcw_modify_step = strtodOrExit(optarg,"zcw-modify-step");
        break;
      case 'E':
        ext_cand_flag = 1;
        break;
      case 'O':
        if (optarg != NULL)
          optimized_computation = strtoullOrExit(optarg, "optimized");
        break;
      case 'D':
        if (optarg != NULL)
          remove_duplicates_cand = strtoullOrExit(optarg, "remove-duplicate");
        break;
      case 'C':
        if (optarg != NULL)
          use_candidates_overlap_alg = strtoullOrExit(optarg, "use-cand-overlap");
        break;
      case 'R':
        if (optarg != NULL) {
          update_candidates_step = strtoullOrExit(optarg, "update-candidates-step");
        }
        else update_candidates_step = 0;
        break;
      case 'S':
        symmetrical_decompose = 1;
        break;
      case 'I':
        if (optarg != NULL) {
          iterative_update = strtoullOrExit(optarg, "iterative-update");
        }
        else iterative_update = 0;
        break;
      case '?':
        
      default:
        //print_help(argv[0]);
        exit(BASSO_EXIT_INVALID_PARAMETER);
    }
  }
  
  if (optind == argc) {
    /* Set the infile_list to contain one element, "-" */
    char *str = malloc(2);
    if (str == NULL) {
      fprintf(stderr, "Error when allocating memory for \"-\": %s", strerror(errno));
      exit(BASSO_EXIT_MEMORY);
    }
    strcpy(str, "-");
    infile_list = &str;
    n_infiles = 1;
  } else if (optind < argc) {
    n_infiles = argc - optind;
    infile_list = argv + optind;
  }
  
  /* Check that rank and threshold are set */
  if (rank == 0) {
    fprintf(stderr, "Error: The rank of the decomposition is not set or is 0.\n"
            "Use %s -h to get help.\n", argv[0]);
    exit(BASSO_EXIT_INVALID_PARAMETER);
  }
  
  for(uint64_t i = 0 ; i < thresholds_len ; i++) {
    if (thresholds[i] < 0 || thresholds[i] > 1) {
      fprintf(stderr, "Error: The rounding threshold is not set or is invalid.\n"
              "The rounding threshold must be between 0 and 1.\n"
              "Use %s -h to get help.\n", argv[0]);
      exit(BASSO_EXIT_INVALID_PARAMETER);
    }
  }
  
  /* update_step is unsigned */
  /*
  if(update_step  < 0) {
    fprintf(stderr, "Error: The update step is not set or is invalid.\n"
            "The update step must be greater than 0.\n"
            "Use %s -h to get help.\n", argv[0]);
    exit(BASSO_EXIT_INVALID_PARAMETER);
  }
   */
  
  if(zcw_modify_step < 0) {
    fprintf(stderr, "Error: The zero cover weight modifier is not set or is invalid.\n"
            "The zero cover weight modifier must be non-negative value.\n"
            "Use %s -h to get help.\n", argv[0]);
    exit(BASSO_EXIT_INVALID_PARAMETER);
  }
  
  return BASSO_RETURN_SUCCESS;
}

/*
 * Copies the appropriate global variables to an option struct
 */
static basso_option_t *
set_algo_options()
{
  basso_option_t *opt = basso_opt_init();
  if (opt == NULL) return NULL;
  basso_opt_set_rank(opt, rank);
  basso_opt_set_thresholds_list(opt, thresholds,thresholds_len);
  basso_opt_set_weight(opt, weight);
  basso_opt_set_update_step(opt,update_step);
  basso_opt_set_ext_candidates(opt,ext_cand_flag);
  basso_opt_set_zero_cover_weight(opt,zero_cover_weight);
  basso_opt_set_zcw_modify_step(opt,zcw_modify_step);
  basso_opt_set_print_mid_error(opt,print_mid_error);
  basso_opt_set_iterative_update(opt,iterative_update);
  basso_opt_set_update_candidates_step(opt,update_candidates_step);
  basso_opt_set_symmetrical_decompose(opt,symmetrical_decompose);
  basso_opt_set_optimized_computation(opt,optimized_computation);
  basso_opt_set_remove_duplicate_candidates(opt,remove_duplicates_cand);
  basso_opt_set_use_candidates_overlap_alg(opt,use_candidates_overlap_alg);
  return opt;
}

/*
 * Replacement of clock_gettime for OS X
 * This is really computed in microseconds, not in nanoseconds
 */
#ifndef HAVE_CLOCK_GETTIME
int
clock_gettime(int clk_id, struct timespec* t)
{
  struct timeval now;
  int rv = gettimeofday(&now, NULL);
  if (rv) return rv;
  t->tv_sec = now.tv_sec;
  t->tv_nsec = now.tv_usec * 1000;
  return 0;
}
#endif /* undefined HAVE_CLOCK_GETTIME */


/*
 * Signal handler for SIGTERM and SIGINT that kindly asks selectBasis to stop.
 */
void
stop_select_basis(int signum)
{
  basso_stop_select_basis = 1; // This is defined in basso.h
  terminate_signal_received = 1;
}


/*
 * Builds an output file name of style
 * <prefix><midfix><side><suffix>
 * where <side> is either "_L" or "_R".
 *
 * If <prefix> is NULL, returns "-"; if <midfix> is NULL, it's omitted
 *
 * The output must be free'd.
 */
static char *
get_outfilename(const char *restrict prefix, 
                const char *restrict midfix,
                const enum factor_side fside,
                const char *restrict suffix)
{
  char *out;
  char *side;
  size_t prefix_len, midfix_len, side_len, suffix_len, out_len;
  
  if (prefix == NULL) {
    /* We must allocate this so it can be free'd */
    out = malloc(2);
    if (out == NULL) {
      fprintf(stderr, "Error when allocating memory for output file name: %s", strerror(errno));
      exit(BASSO_EXIT_MEMORY);
    }
    strcpy(out, "-");
    return out;
  }
  
  if (fside == RIGHT) side = "_R";
  else side = "_L";
  
  prefix_len = strlen(prefix);
  if (midfix != NULL) midfix_len = strlen(midfix);
  else midfix_len = 0;
  side_len = strlen(side);
  suffix_len = strlen(suffix);
  out_len = prefix_len + midfix_len + side_len + 1 + suffix_len + 1; /* space for '.' and '\0' */
  out = malloc(out_len);
  if (out == NULL) {
    fprintf(stderr, "Error when allocating memory for output file name: %s", strerror(errno));
    exit(BASSO_EXIT_MEMORY);
  }
  
  strcpy(  out,                                          prefix);
  if (midfix != NULL) {
    strcpy(out + prefix_len,                             midfix);
  }
  strcpy(  out + prefix_len + midfix_len,                side);
  strcpy(  out + prefix_len + midfix_len + side_len,     ".");
  strcpy(  out + prefix_len + midfix_len + side_len + 1, suffix);
  
  return out;
}

/*
 * Returns a string to be included into the MatrixMarket format header.
 * The output must be free'd
 */
static char *
get_comments_string(const enum factor_side fside)
{
  char *out;
  char *side;
  time_t t;
  struct tm *tm;
  char date[128];
  const size_t out_len=1024; // Maximum lenght of a comment string
  int nchars;
  
  t = time(NULL);
  tm = localtime(&t);
  
  if(strftime(date, sizeof(date), "%Y-%m-%d %H:%M:%S %z", tm) == 0) {
    fprintf(stderr, "Error when formatting time for comments\n");
    return NULL;
  }
  
  if (fside == RIGHT) side = "Right";
  else side = "Left";
  
  
  out = malloc(out_len);
  if (out == NULL) {
    fprintf(stderr, "Error when allocating memory for comments: %s", strerror(errno));
    return NULL;
  }
  
  nchars = snprintf(out, out_len,
                    "%% %s factor matrix returned by basso on %s\n"
                    "%% Parameters:\n"
                    "%%   Input:     %s\n"
                    "%%   Rank:      %llu\n"
                    "%%   Threshold: %s\n"
                    "%%   Weight:    %llu\n"
                    "%%   Processes: %d"
                    , side,  date, infile, rank, thresholds_str, weight, processes);
  if (nchars >= out_len) {
    free(out);
    return NULL;
  }
  
  return out;
}

static int
print_outfiles(const basso_matrix_t *restrict B, const basso_matrix_t *restrict C)
{
  char *suffix, *midfix, *outfilename, *comments;
  int out;
  
  /* Outfile names */
  
  switch(outformat) {
    case 'm':
      suffix = BASSO_MM_SUFFIX;
      break;
    case 'b':
      suffix = BASSO_BINARY_SUFFIX;
      break;
    default:
      if (outformat) fprintf(stderr, "Unknown output file format %c\n", informat);
      else fprintf(stderr, "Output file format not given and could not be guessed\n");
      exit(BASSO_EXIT_INVALID_PARAMETER);
  }
  
  if (n_infiles == 1) {
    midfix = NULL;
  } else {
    midfix = strip_file_suffix(infile);
  }
  
  /* Print left file */
  outfilename = get_outfilename(outfile, midfix, LEFT, suffix);
  comments = get_comments_string(LEFT);
  
  if (verbosity_flag) fprintf(stderr, "  Writing to %s... ", outfilename);
  
  switch(outformat) {
    case 'm':
      out = write_mm_matrix(outfilename, B, comments);
      break;
    case 'b':
      out = write_bbm_matrix(outfilename, B);
  }
  if (out != BASSO_RETURN_SUCCESS) goto cleanup;
  
  free(outfilename);
  free(comments);
  
  /* Print right file */
  outfilename = get_outfilename(outfile, midfix, RIGHT, suffix);
  comments = get_comments_string(RIGHT);
  
  if (verbosity_flag) fprintf(stderr, "and to %s... ", outfilename);
  
  switch(outformat) {
    case 'm':
      out = write_mm_matrix(outfilename, C, comments);
      break;
    case 'b':
      out = write_bbm_matrix(outfilename, C);
  }
  if (out != BASSO_RETURN_SUCCESS) goto cleanup;
  
  if (verbosity_flag) fprintf(stderr, "done\n");
  
cleanup:
  free(midfix);
  free(outfilename);
  free(comments);
  
  switch(out) {
    case BASSO_RETURN_IOFAIL:
      exit(BASSO_EXIT_IOERROR);
    case BASSO_RETURN_IOPERM:
      exit(BASSO_EXIT_INVALID_OUTPUT);
    case BASSO_RETURN_INVALID_INPUT:
      exit(BASSO_EXIT_INVALID_INPUT);
    case BASSO_RETURN_SUCCESS:
      return BASSO_RETURN_SUCCESS;
    default:
      exit(BASSO_EXIT_UNKNOWN_ERROR);
  }
  
  // We should never reach this one
  return BASSO_RETURN_SUCCESS;
}

static int
print_timing_results(const struct timespec *timings)
{
  FILE *fp;
  int i, retval;
  
  if (clock_outfile == NULL || !strcmp(clock_outfile, "-")) {
    fp = stdout;
  } else {
    errno = 0;
    fp = fopen(clock_outfile, "a");
    if (fp == NULL) {
      fprintf(stderr, "Error when opening file %s for writing timing output: %s\n",
              clock_outfile, strerror(errno));
      retval = BASSO_RETURN_IOPERM;
      goto cleanup;
    }
  }
  
  if (fp == stdout || fp == stderr) {
    fprintf(fp,
            "Read start           \t"
            "Read stop            \t"
            "Assoc start          \t"
            "Assoc stop           \t"
            "Basis start          \t"
            "Basis stop           \t"
            "Write start          \t"
            "Write stop           \n");
  }
  for (i=0; i < 8; i++) {
    double diff;
    int r;
    diff = timings[i].tv_sec - timings[0].tv_sec;
    diff += (timings[i].tv_nsec - timings[0].tv_nsec) / 1000000000.0;
    errno = 0;
    r = fprintf(fp, "%.15e%c", diff, (i < 7)?'\t':'\n');
    if (r < 0) {
      fprintf(stderr, "Error when printing timing output to %s: %s\n",
              clock_outfile, strerror(errno));
      retval = BASSO_RETURN_IOFAIL;
      goto cleanup;
    }
  }
  retval = BASSO_RETURN_SUCCESS;
  
cleanup:
  if (fp != NULL && fp != stdout && fp != stderr) fclose(fp);
  return retval;
}

static int
print_reconstruction_error(const basso_matrix_t *restrict A,
                           const basso_matrix_t *restrict B,
                           const basso_matrix_t *restrict C)
{
  FILE *fp = NULL;
  int retval = BASSO_RETURN_SUCCESS;
  uint64_t err;
  int r;
  
  if (err_outfile == NULL || !strcmp(err_outfile, "-")) {
    fp = stdout;
  } else {
    errno = 0;
    fp = fopen(err_outfile, "a");
    if (fp == NULL) {
      fprintf(stderr, "Cannot open file %s for writing standard error: %s\n",
              err_outfile, strerror(errno));
      retval = BASSO_RETURN_IOPERM;
      goto cleanup;
    }
  }
  
  errno = 0;
  err = basso_m_bnorm(A, B, C);
  if (err == ULLONG_MAX && errno != 0) {
    fprintf(stderr, "Error when computing the reconstruction error: %s\n",
            strerror(errno));
    retval = BASSO_RETURN_MEMORY;
    goto cleanup;
  }
  
  if (fp == stdout || fp == stderr) fprintf(fp, "Reconstruction error:\t");
  r = fprintf(fp, "%llu\n", err);
  if (r < 0) {
    fprintf(stderr, "Cannot write reconstruction error to file %s: %s\n",
            err_outfile, strerror(errno));
    retval = BASSO_RETURN_IOFAIL;
    goto cleanup;
  }
  
cleanup:
  if (fp != NULL && fp != stdout && fp != stderr) fclose(fp);
  return retval;
  
}

static int
print_symmetric_reconstruction_error(const basso_matrix_t *restrict A,
                                     const basso_matrix_t *restrict B,
                                     const basso_matrix_t *restrict C)
{
  FILE *fp = NULL;
  int retval = BASSO_RETURN_SUCCESS;
  uint64_t err;
  int r;
  
  if (err_outfile == NULL || !strcmp(err_outfile, "-")) {
    fp = stdout;
  } else {
    errno = 0;
    fp = fopen(err_outfile, "a");
    if (fp == NULL) {
      fprintf(stderr, "Cannot open file %s for writing standard error: %s\n",
              err_outfile, strerror(errno));
      retval = BASSO_RETURN_IOPERM;
      goto cleanup;
    }
  }
  
  errno = 0;
  
  basso_matrix_t *prod = basso_m_alloc(B->rows,C->cols,A->majority);
  basso_m_bprod(B,C,prod);
  err = basso_m_diff_ignore_diagonal(A,prod);
  basso_m_free(prod);
  
  if (err == ULLONG_MAX && errno != 0) {
    fprintf(stderr, "Error when computing the reconstruction error: %s\n",
            strerror(errno));
    retval = BASSO_RETURN_MEMORY;
    goto cleanup;
  }
  
  if (fp == stdout || fp == stderr) fprintf(fp, "Reconstruction error:\t");
  r = fprintf(fp, "%llu\n", err);
  if (r < 0) {
    fprintf(stderr, "Cannot write reconstruction error to file %s: %s\n",
            err_outfile, strerror(errno));
    retval = BASSO_RETURN_IOFAIL;
    goto cleanup;
  }
  
cleanup:
  if (fp != NULL && fp != stdout && fp != stderr) fclose(fp);
  return retval;
  
}

int
main(int argc, char *argv[])
{
  size_t i;
  
  basso_matrix_t *Mr; /* input data in row major */
  basso_matrix_t *Mc; /* input data in col major */
  basso_matrix_t *Ar; /* association matrix in row major */
  basso_matrix_t *Ac; /* association matrix in col major */
  basso_matrix_t *B;  /* left factor matrix (col-major) */
  basso_matrix_t *C;  /* right factor matrix (row-major) */
  basso_option_t *opt; /* options for the algorithms */
  
  struct timespec timings[8];
  
  struct sigaction term_action;
  struct sigaction default_action;
  
  /* If there's no command-line arguments, we just print version and exit */
  if (argc == 1) {
    print_version();
    return BASSO_EXIT_SUCCESS;
  }
  
  /* Parse command-line arguments to populate global variables */
  parse_commandline_arguments(argc, argv);
  
  /* Test that we don't try to run CUDA if it's not compiled */
#ifndef HAVE_CUDA
  if (cuda_flag == 1) {
    fprintf(stderr, "Warning: You must compile the package with \"--with-cuda\" in order to have\n"
            "CUDA support. Reverting back to CPU computation.\n");
    cuda_flag = 0;
  }
#endif
  
  
  /* Copy the necessary parameters to options structure */
  opt = set_algo_options();
  if (opt == NULL) return BASSO_EXIT_MEMORY;
  
  /* Set the number of threads if the user has specifically asked for it */
  if (processes > 0) {
    omp_set_num_threads(processes);
  }
  
  
  /* For-loop over the input files */
  for (i = 0; i < n_infiles && !terminate_signal_received; i++) {
    infile = infile_list[i];
    
    /* FIXME: re-infer per file if necessary */
    
    if (!informat) {
      if (outformat) {
        /* Invalid arguments */
        fprintf(stderr, "Error: Output format cannot be set if input format is not set\n");
        return BASSO_EXIT_INVALID_PARAMETER;
      }
      informat = infer_format(infile);
      if (informat == -1) {
        fprintf(stderr, "Error: failed to infer the input file format (set with -f)\n");
        return BASSO_EXIT_INVALID_PARAMETER; // failed the inference
      }
    }
    
    if (informat && !outformat) outformat = informat;
    
    /* Notice that it is still possible that informat is unset */
    
    if (verbosity_flag) fprintf(stderr, "BASSO: decomposing %s with %d processes and "
                                "rank = %llu, threshold = %s, and weight = %llu\n",
                                infile, processes, rank, thresholds_str, weight);
    // DEBUG
    /*
     printf("Input: %s\n", (infile != NULL)?infile:"NULL");
     printf("Output: %s\n", (outfile != NULL)?outfile:"NULL");
     printf("Format: %c\n", (informat != 0)?informat:' ');
     printf("Outformat: %c\n", (outformat != 0)?outformat:' ');
     printf("Rank: %llu\n", rank);
     printf("Weight: %llu\n", weight);
     printf("Processes: %d\n", processes);
     */
    
    if (verbosity_flag) fprintf(stderr, "  Reading input from file %s...\t", infile);
    clock_gettime(CLOCK_REALTIME, timings + TIME_INPUT_START); // Time when it all started
    errno = 0;
    switch (informat) {
      case 'm':
        if(cuda_flag) {
#ifdef HAVE_CUDA
          size_t R,C;
          read_mm_matrix_header(infile,&R,&C);
          basso_cu_m_alloc(R,C,BASSO_ROW_MAJ,BASSO_CU_ON_HOST,&Mr);
          fill_mm_matrix(infile,Mr);
#endif
        } else {
          Mr = read_mm_matrix(infile, BASSO_ROW_MAJ);
        }
        break;
      case 'b':
        Mr = read_bbm_matrix(infile);
        if (Mr != NULL && Mr->majority == BASSO_COL_MAJ) {
          basso_matrix_t *T = basso_m_swap_duplicate(Mr);
          basso_m_free(Mr);
          Mr = T;
        }
        break;
      default:
        if (informat) fprintf(stderr, "Unknown input file format %c\n", informat);
        else fprintf(stderr, "Input file format not given and could not be guessed\n");
        return BASSO_EXIT_INVALID_PARAMETER;
    }
    
    if (Mr == NULL) return BASSO_EXIT_IOERROR;
    
    clock_gettime(CLOCK_REALTIME, timings+TIME_INPUT_DONE);
    
    if (verbosity_flag) fprintf(stderr, "done ! Input is %llu-by-%llu.\n", Mr->rows, Mr->cols);
    if (verbosity_flag) fprintf(stderr, "  Building association matrix...\t");
    /* Compute association matrix */
    
    
    clock_gettime(CLOCK_REALTIME, timings+TIME_ASSOC_START); // Time when computing associatin matr started
    if (cuda_flag) {
#ifdef HAVE_CUDA
      Ac = basso_cu_association_matrix(Mr, opt);
#endif
    } else {
      Ac = basso_association_matrix(Mr, NULL, opt);
    }
    clock_gettime(CLOCK_REALTIME, timings+TIME_ASSOC_DONE); // This is time for ending association_matrix
    
    if (Ac == NULL) return BASSO_EXIT_UNKNOWN_ERROR;
    
    if (verbosity_flag) fprintf(stderr, "done!\n");
    
    /* Transpose Ar and Mr and free the unused ones */
    if(cuda_flag)
    {
#ifdef HAVE_CUDA
      basso_cu_m_alloc(Mr->rows,Mr->cols,BASSO_COL_MAJ,BASSO_CU_ON_HOST,&Mc);
      if(basso_m_copy(Mc,Mr))
        return BASSO_EXIT_MEMORY;
      basso_cu_m_free(Mr,BASSO_CU_ON_HOST);
#endif
    } else {
      Mc = basso_m_swap_duplicate(Mr);
      if (Mc == NULL) return BASSO_EXIT_MEMORY;
      basso_m_free(Mr);
    }
    
    /* Set signal handler to allow aborting gracefully from SelectBasis */
    /* The handler stop_select_basis handles both SIGTERM and SIGINT,
     * so block both and set flags to SA_RESTART
     */
    term_action.sa_handler = stop_select_basis;
    sigemptyset(&(term_action.sa_mask));
    sigaddset(&(term_action.sa_mask), SIGTERM);
    sigaddset(&(term_action.sa_mask), SIGINT);
    term_action.sa_flags = SA_RESTART;
    
    sigaction(SIGTERM, &term_action, &default_action);
    sigaction(SIGINT,  &term_action, &default_action);
    
    /* Select basis */
    if (verbosity_flag) fprintf(stderr, "  Finding basis vectors...\t");
    
    clock_gettime(CLOCK_REALTIME, timings+TIME_BASIS_START); // This is time for starting selectBasis
    
    if(cuda_flag){
#ifdef HAVE_CUDA
      uint64_t k = basso_opt_get_rank(opt);
      basso_cu_m_alloc(Mc->rows, k, BASSO_COL_MAJ, BASSO_CU_ON_HOST, &B);
      basso_cu_m_alloc(k, Mc->cols, BASSO_ROW_MAJ, BASSO_CU_ON_HOST, &C);
      basso_cu_select_basis(Mc, Ac, opt, B, C);
#endif
    } else {
      basso_select_basis(Mc, Ac, opt, &B, &C);
    }
    
    clock_gettime(CLOCK_REALTIME, timings+TIME_BASIS_DONE); // This is time for ending selectBasis
    
    if (B == NULL || C == NULL) return BASSO_EXIT_MEMORY;
    
    if(cuda_flag){
#ifdef HAVE_CUDA
      basso_cu_m_free(Ac,BASSO_CU_ON_HOST);
#endif
    } else{
      basso_m_free(Ac);
    }
    
    if (verbosity_flag) fprintf(stderr, "done!\n");
    
    /* Print output and reconstruction error if asked */
    clock_gettime(CLOCK_REALTIME, timings+TIME_OUTPUT_START); // Time when writing output starts
    if (output_flag) print_outfiles(B, C);
    if (err_flag) {
      if (symmetrical_decompose) print_symmetric_reconstruction_error(Mc,B,C);
      else print_reconstruction_error(Mc, B, C);
    }
    clock_gettime(CLOCK_REALTIME, timings+TIME_OUTPUT_DONE); // Time when writing output ends
    
    if(cuda_flag){
#ifdef HAVE_CUDA
      basso_cu_m_free(Mc,BASSO_CU_ON_HOST);
      basso_cu_m_free(B,BASSO_CU_ON_HOST);
      basso_cu_m_free(C,BASSO_CU_ON_HOST);
#endif
    } else{
      basso_m_free(Mc);
      basso_m_free(B);
      basso_m_free(C);
    }
    
    /* Print timing results -- This might fail, but we don't care*/
    if (clock_flag) print_timing_results(timings);
    
    /* Revert the signal handler back to default for the begin of the next iteration */
    sigaction(SIGTERM, &default_action, &term_action);
    sigaction(SIGINT,  &default_action, &term_action);
    
    if(thresholds_str != NULL) free(thresholds_str);
    if(thresholds != NULL) free(thresholds);
    
  } /* END FOR over the input files */
  
  return BASSO_EXIT_SUCCESS;
}

